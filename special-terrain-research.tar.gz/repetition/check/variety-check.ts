// 반복·단조로움 자동 검사 시제품 (스크래치, 저장소 밖) — 생성기 출력(PlanetFields + 부가 정보)과 격자만 쓴다.
// 실행: node variety-check.ts [면 레벨=7] [시드 목록=pack,1,42] [--root 생성기 루트] [--json 출력]
// 지표마다 v1 값과 문턱(제안)을 비교해 PASS/FAIL을 찍는다. 문턱은 기획·디자인 확인 전 임시값이다.
import { pathToFileURL } from "node:url";
import { readFileSync, writeFileSync } from "node:fs";
const args = process.argv.slice(2);
const flag = (name: string) => { const k = args.indexOf(name); return k >= 0 ? args.splice(k, 2)[1] : undefined; };
const ROOT = flag("--root") ?? "/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/inventory-harness/snapshot-f59a8a7";
const jsonOut = flag("--json");
const F = Number(args[0] ?? 7);
const G = `${ROOT}/packages/planet/src/generator`;
const gen = await import(pathToFileURL(`${G}/index.ts`).href);
const { buildGrid, neighbors8, areaOf } = await import(pathToFileURL(`${G}/grid.ts`).href);
const { distanceField } = await import(pathToFileURL(`${G}/queues.ts`).href);
const climate = await import(pathToFileURL(`${G}/climate.ts`).href);
const noise = await import(pathToFileURL(`${G}/noise.ts`).href);
const platesMod = await import(pathToFileURL(`${G}/plates.ts`).href);
const hot = await import(pathToFileURL(`${G}/hotspots.ts`).href);
const rnd = await import(pathToFileURL(`${G}/random.ts`).href);
const planets = JSON.parse(readFileSync(`${ROOT}/content/core/planets.json`, "utf8")).entries;
const biomeEntries = JSON.parse(readFileSync(`${ROOT}/content/core/biomes.json`, "utf8")).entries;
const base = gen.planetInputFromDefinition(planets[0], biomeEntries, F);
const seeds = (args[1] ?? "pack,1,42").split(",").map((s) => (s === "pack" ? base.seed : Number(s)));
const R_KM = 6371.0088, SCALE = 12;
const grid = buildGrid(F);
const N: number = grid.cellCount, n: number = grid.n;
const cellKm = grid.meanCellAngle * R_KM;
const NB = new Int32Array(N * 8);
{ const o = new Int32Array(8); for (let c = 0; c < N; c++) { neighbors8(grid, c, o); NB.set(o, c * 8); } }
const area = new Float64Array(N); for (let c = 0; c < N; c++) area[c] = areaOf(grid, c);
const latDeg = new Float64Array(N); for (let c = 0; c < N; c++) latDeg[c] = (Math.asin(Math.max(-1, Math.min(1, grid.z[c]))) * 180) / Math.PI;
const biomeIds: string[] = base.biomes.map((b: any) => b.id);
const B = (id: string) => biomeIds.indexOf(id);

// ── 공용 ──
function components(member: (c: number) => boolean, same: (a: number, b: number) => boolean): { label: Int32Array; sizes: number[]; areas: number[] } {
  const label = new Int32Array(N).fill(-1); const q = new Int32Array(N); const sizes: number[] = []; const areas: number[] = [];
  for (let s = 0; s < N; s++) {
    if (label[s] !== -1 || !member(s)) continue;
    const id = sizes.length; let h = 0, t = 0; q[t++] = s; label[s] = id; let a = 0;
    while (h < t) {
      const c = q[h++]; a += area[c];
      for (let k = 0; k < 8; k++) { const o = NB[c * 8 + k]; if (o >= 0 && label[o] === -1 && member(o) && same(c, o)) { label[o] = id; q[t++] = o; } }
    }
    sizes.push(t); areas.push(a);
  }
  return { label, sizes, areas };
}
function r2ByLat(values: ArrayLike<number>, mask: (c: number) => boolean): number {
  const bins = 180; const sw = new Float64Array(bins), sv = new Float64Array(bins);
  let W = 0, M = 0;
  for (let c = 0; c < N; c++) if (mask(c)) { const b = Math.min(bins - 1, Math.floor(latDeg[c] + 90)); sw[b] += area[c]; sv[b] += area[c] * values[c]; W += area[c]; M += area[c] * values[c]; }
  M /= W; let sst = 0, ssw = 0;
  for (let c = 0; c < N; c++) if (mask(c)) { const b = Math.min(bins - 1, Math.floor(latDeg[c] + 90)); const v = values[c]; sst += area[c] * (v - M) ** 2; ssw += area[c] * (v - sv[b] / sw[b]) ** 2; }
  return 1 - ssw / sst;
}
function biomeByLatTable(fields: any): Float64Array { // [1° 띠 90][바이옴] 육지 넓이
  const nb = biomeIds.length; const t = new Float64Array(90 * nb);
  for (let c = 0; c < N; c++) if (!(fields.water[c] & 3)) t[Math.min(89, Math.floor(Math.abs(latDeg[c]))) * nb + fields.biome[c]] += area[c];
  return t;
}
function js(p: number[], q: number[]): number {
  const sp = p.reduce((a, b) => a + b, 0), sq = q.reduce((a, b) => a + b, 0); let d = 0;
  for (let k = 0; k < p.length; k++) {
    const a = p[k] / sp, b = q[k] / sq, m = (a + b) / 2;
    if (a > 0) d += 0.5 * a * Math.log2(a / m); if (b > 0) d += 0.5 * b * Math.log2(b / m);
  }
  return d;
}
const fiOf = (c: number) => Math.floor(c / (n * n)), iOf = (c: number) => (c % (n * n)) % n, jOf = (c: number) => Math.floor((c % (n * n)) / n);

interface Result { name: string; value: number; threshold: string; pass: boolean; note: string }
function metric(name: string, value: number, op: "<=" | ">=", limit: number, note: string): Result {
  return { name, value: Math.round(value * 1000) / 1000, threshold: `${op} ${limit}`, pass: op === "<=" ? value <= limit : value >= limit, note };
}

const perSeed: Record<string, Result[]> = {};
const latTables: Float64Array[] = [];
for (const seed of seeds) {
  const t0 = performance.now();
  const details = gen.runPlanetGenerator({ ...base, seed });
  const fields = details.fields; const genMs = performance.now() - t0;
  const isLand = (c: number) => (fields.water[c] & 3) === 0;
  const isOcean = (c: number) => (fields.water[c] & 1) === 1;
  const res: Result[] = [];
  // 1 위도 띠 설명력: 바이옴 정보량 중 위도(1°)가 설명하는 몫
  const table = biomeByLatTable(fields); latTables.push(table);
  {
    const nb = biomeIds.length; let tot = 0; const pb = new Float64Array(nb), pl = new Float64Array(90);
    for (let b = 0; b < 90; b++) for (let k = 0; k < nb; k++) { const v = table[b * nb + k]; tot += v; pb[k] += v; pl[b] += v; }
    let I = 0, H = 0;
    for (let k = 0; k < nb; k++) if (pb[k] > 0) H -= (pb[k] / tot) * Math.log2(pb[k] / tot);
    for (let b = 0; b < 90; b++) for (let k = 0; k < nb; k++) { const v = table[b * nb + k] / tot; if (v > 0) I += v * Math.log2(v / ((pb[k] / tot) * (pl[b] / tot))); }
    res.push(metric("zonal.biomeInfoExplainedByAbsLat", I / H, "<=", 0.5, "land biome entropy share explained by |latitude| 1° bands"));
    let dom = 0; for (let b = 0; b < 90; b++) { let mx = 0; for (let k = 0; k < nb; k++) mx = Math.max(mx, table[b * nb + k]); dom += mx; }
    res.push(metric("zonal.dominantBiomeShare", dom / tot, "<=", 0.55, "land-weighted share of the most common biome per 1° band"));
  }
  // 2 바다: 기온·강수가 위도만의 함수인지
  {
    const far = distanceField(grid, (c: number) => !isOcean(c), 1000 / R_KM + grid.meanCellAngle);
    const openOcean = (c: number) => isOcean(c) && far.angle[c] >= 1000 / R_KM;
    res.push(metric("zonal.openOceanPrecipR2", r2ByLat(fields.precipitationMm, openOcean), "<=", 0.9, "R² of precipitation on 1° latitude bins, ocean >1000 km from land"));
    res.push(metric("zonal.oceanTempR2", r2ByLat(fields.temperatureC, isOcean), "<=", 0.97, "R² of stored temperature on 1° bins, all ocean"));
  }
  // 3 습도 계단: 반올림 기온이 다른 이웃 쌍의 습도 차 ÷ 같은 쌍 (강·호수 가산이 없는 땅)
  {
    let sx = 0, nx = 0, ss = 0, ns = 0;
    const plain = (c: number) => isLand(c) && !(fields.water[c] & 12) && fields.river[c] === 0;
    for (let c = 0; c < N; c++) {
      if (!plain(c)) continue;
      for (const k of [1, 3, 4, 6]) {
        const o = NB[c * 8 + k]; if (o < 0 || !plain(o)) continue;
        let nearWater = false; for (let e = 0; e < 8; e++) { const q = NB[o * 8 + e]; if (q >= 0 && (fields.river[q] > 0 || (fields.water[q] & 2))) nearWater = true; }
        for (let e = 0; e < 8 && !nearWater; e++) { const q = NB[c * 8 + e]; if (q >= 0 && (fields.river[q] > 0 || (fields.water[q] & 2))) nearWater = true; }
        if (nearWater) continue;
        const d = Math.abs(fields.humidity[o] - fields.humidity[c]);
        if (fields.temperatureC[o] !== fields.temperatureC[c]) { sx += d; nx++; } else { ss += d; ns++; }
      }
    }
    res.push(metric("lines.humidityStepAtIntegerIsotherms", sx / nx / (ss / ns), "<=", 1.5, "mean |Δhumidity| across rounded-temperature change ÷ within same rounded temperature"));
  }
  // 4 바람 방향 줄무늬(필드만): 위도 띠 평균을 뺀 log 강수의 바람 가로/세로 차이 비 ÷ 같은 비의 지면 고도(등방 기준)
  {
    const k = Math.max(2, Math.round(54 / cellKm)); // 약 54km(실제 환산) 떨어진 이웃 쌍
    const L = new Float64Array(N), sw = new Float64Array(360), sv = new Float64Array(360);
    for (let c = 0; c < N; c++) if (isLand(c)) { const b = Math.min(359, Math.floor((latDeg[c] + 90) * 2)); const v = Math.log(fields.precipitationMm[c] + 1); L[c] = v; sw[b] += area[c]; sv[b] += area[c] * v; }
    for (let c = 0; c < N; c++) if (isLand(c)) { const b = Math.min(359, Math.floor((latDeg[c] + 90) * 2)); L[c] -= sv[b] / sw[b]; }
    const ratio = (vals: ArrayLike<number>) => {
      let cr = 0, al = 0, m = 0;
      for (let c = 0; c < N; c++) {
        if (!isLand(c)) continue;
        const f = fiOf(c), i = iOf(c), j = jOf(c);
        if (i < k + 1 || j < k + 1 || i > n - k - 2 || j > n - k - 2) continue;
        // 바람 방향(생성기 windAt): 동·북 단위 벡터를 면 격자 이웃 방향으로 고른다
        const { u, v } = climate.windAt(latDeg[c]); const sp = Math.hypot(u, v); if (sp < 0.05) continue;
        const x = grid.x[c], y = grid.y[c], z = grid.z[c]; const hz = Math.hypot(x, y) || 1;
        const ex = -y / hz, ey = x / hz, nx_ = -z * ey, ny_ = z * ex, nz_ = x * ey - y * ex;
        const wx = u * ex + v * nx_, wy = u * ey + v * ny_, wz = v * nz_;
        let best = -1, bs = -2;
        for (let e = 0; e < 8; e++) { const o = NB[c * 8 + e]; const dx = grid.x[o] - x, dy = grid.y[o] - y, dz = grid.z[o] - z; const s = (dx * wx + dy * wy + dz * wz) / Math.hypot(dx, dy, dz); if (s > bs) { bs = s; best = o; } }
        const di = iOf(best) - i, dj = jOf(best) - j;
        const at = (a: number, b: number) => f * n * n + (j + b) * n + (i + a);
        const c1 = at(-k * dj, k * di), c2 = at(k * dj, -k * di), a1 = at(k * di, k * dj), a2 = at(-k * di, -k * dj);
        if (!isLand(c1) || !isLand(c2) || !isLand(a1) || !isLand(a2)) continue;
        cr += Math.abs(vals[c1] - vals[c2]); al += Math.abs(vals[a1] - vals[a2]); m++;
      }
      return cr / al;
    };
    const elev = Float64Array.from(fields.elevationM);
    const r = ratio(L), ref = ratio(elev);
    res.push(metric("lines.windStreakAnisotropyExcess", r - ref, "<=", 0.05, `(cross/along of zonal-residual log P) − (same for elevation); raw ${r.toFixed(2)} vs ref ${ref.toFixed(2)}`));
  }
  // 5 해안선 상자 세기: 가장 작은 두 크기의 국소 차원(면 안쪽)
  {
    const count = (s: number) => { const m = Math.floor(n / s); let cnt = 0; const seen = new Uint8Array(6 * m * m);
      for (let c = 0; c < N; c++) if (fields.water[c] & 8) { const f = fiOf(c), i = Math.floor(iOf(c) / s), j = Math.floor(jOf(c) / s); if (i < m && j < m) { const id = (f * m + j) * m + i; if (!seen[id]) { seen[id] = 1; cnt++; } } }
      return cnt; };
    const s1 = 1, s2 = 4;
    const d = -Math.log(count(s2) / count(s1)) / Math.log(s2 / s1);
    res.push(metric("coast.boxDimension(1-4 cells)", d, ">=", 1.12, `local coastline dimension at ${Math.round(cellKm)}–${Math.round(4 * cellKm)} km (real-eq)`));
  }
  // 6 큰 덩어리: 가장 큰 바이옴 덩어리 10개가 덮는 육지 몫, 약 24 게임 km 창의 단일 바이옴 비율
  {
    const comp = components(isLand, (a, b) => fields.biome[a] === fields.biome[b]);
    const sorted = [...comp.areas].sort((a, b) => b - a); const totLand = comp.areas.reduce((a, b) => a + b, 0);
    res.push(metric("patches.top10ShareOfLand", sorted.slice(0, 10).reduce((a, b) => a + b, 0) / totLand, "<=", 0.35, `of ${comp.sizes.length} land biome patches`));
    const win = Math.max(1, Math.round((24 * SCALE) / cellKm)); // 24 게임 km
    const m = Math.floor(n / win); let full = 0, single = 0;
    for (let f = 0; f < 6; f++) for (let bj = 0; bj < m; bj++) for (let bi = 0; bi < m; bi++) {
      let landCells = 0; const seen = new Set<number>();
      for (let j = bj * win; j < (bj + 1) * win; j++) for (let i = bi * win; i < (bi + 1) * win; i++) { const c = f * n * n + j * n + i; if (isLand(c)) { landCells++; seen.add(fields.biome[c]); } }
      if (landCells >= 0.9 * win * win) { full++; if (seen.size === 1) single++; }
    }
    res.push(metric("patches.singleBiomeWindowShare(24 game km)", single / Math.max(1, full), "<=", 0.35, `${win}×${win} cells, ${full} land windows`));
  }
  // 7 특징까지 거리(게임 km): 바이옴 경계·강·해안·호수·가파른 곳(이웃 고도차/거리 > 20m/km 실제)·마른 분지
  {
    const isFeature = (c: number) => {
      if (!isLand(c)) return (fields.water[c] & 2) !== 0;
      if (fields.river[c] > 0 || (fields.water[c] & 8) || details.basinKind[c] === 3) return true;
      for (let e = 0; e < 8; e++) { const o = NB[c * 8 + e]; if (o < 0) continue;
        if (isLand(o) && fields.biome[o] !== fields.biome[c]) return true;
        const dkm = Math.hypot(grid.x[o] - grid.x[c], grid.y[o] - grid.y[c], grid.z[o] - grid.z[c]) * R_KM;
        if ((Math.abs(fields.elevationM[o] - fields.elevationM[c]) * SCALE) / dkm > 20) return true; }
      return false; };
    const d = distanceField(grid, isFeature, 3000 / R_KM);
    const vals: number[] = []; for (let c = 0; c < N; c++) if (isLand(c)) vals.push((d.angle[c] * R_KM) / SCALE);
    vals.sort((a, b) => a - b);
    res.push(metric("features.gapP90GameKm", vals[Math.floor(0.9 * (vals.length - 1))], "<=", 8, "p90 distance from a land cell to the nearest 1st-map feature (game km)"));
  }
  perSeed[String(seed)] = res;
  console.log(`seed ${seed} F${F}: generated in ${Math.round(genMs)} ms, hash ${fields.meta.hash}, metrics ${Math.round(performance.now() - t0 - genMs)} ms`);
}
// 8 시드끼리 구별: 같은 5° 띠 바이옴 분포 JS(시드 사이) ÷ 이웃 5° 띠 JS(같은 시드)
const cross: Result[] = [];
if (latTables.length >= 2) {
  const nb = biomeIds.length;
  const band5 = (t: Float64Array, b: number) => { const row = new Array(nb).fill(0); for (let d = b * 5; d < b * 5 + 5; d++) for (let k = 0; k < nb; k++) row[k] += t[d * nb + k]; return row; };
  const wjs = (pairs: [number[], number[]][]) => { let s = 0, w = 0; for (const [p, q] of pairs) { const wt = p.reduce((a, b) => a + b, 0) + q.reduce((a, b) => a + b, 0); if (p.some((x) => x > 0) && q.some((x) => x > 0)) { s += js(p, q) * wt; w += wt; } } return s / w; };
  let between = 0, cnt = 0;
  for (let a = 0; a < latTables.length; a++) for (let b = a + 1; b < latTables.length; b++) { const pairs: [number[], number[]][] = []; for (let k = 0; k < 18; k++) pairs.push([band5(latTables[a], k), band5(latTables[b], k)]); between += wjs(pairs); cnt++; }
  between /= cnt;
  let adj = 0; for (const t of latTables) { const pairs: [number[], number[]][] = []; for (let k = 0; k < 17; k++) pairs.push([band5(t, k), band5(t, k + 1)]); adj += wjs(pairs); }
  adj /= latTables.length;
  cross.push(metric("seeds.sameBandJS÷adjacentBandJS", between / adj, ">=", 0.5, `between seeds ${between.toFixed(3)} bits, adjacent 5° bands ${adj.toFixed(3)} bits`));
}
// 9 생성기 단위 검사(출력 무관): 무풍 위도, 노이즈 격자점 영점, 열점 사슬 간격 다양성
{
  let minSpeed = Infinity; for (let l = -89.9; l <= 89.9; l += 0.05) { const { u, v } = climate.windAt(l); minSpeed = Math.min(minSpeed, Math.hypot(u, v)); }
  cross.push(metric("unit.windMinSpeed(|lat|<89.9)", minSpeed, ">=", 0.2, "no calm latitudes (calm → upwind = self → moisture reset)"));
  let all = 0, alln = 0, near = 0, nearn = 0;
  for (let k = 0; k < 200000; k++) { // 결정적 표본: 정수 해시로 점을 고른다
    const h1 = rnd.mix32(k * 3 + 1), h2 = rnd.mix32(k * 3 + 2), h3 = rnd.mix32(k * 3 + 3);
    const x = (h1 / 4294967296) * 40, y = (h2 / 4294967296) * 40, z = (h3 / 4294967296) * 40;
    const v = noise.fbm3(777, x, y, z, 1, 6, 0.52); all += v * v; alln++;
    const d = Math.hypot(x - Math.round(x), y - Math.round(y), z - Math.round(z)); if (d < 0.1) { near += v * v; nearn++; }
  }
  cross.push(metric("unit.fbmRmsNearLatticeVertices÷global", Math.sqrt(near / nearn) / Math.sqrt(all / alln), ">=", 0.8, "octave lattices nested exactly → all octaves 0 at base vertices"));
  const plates = platesMod.createPlates(base.seed, base.settings.plateCount, 0.38);
  const vols = hot.hotspotVolcanoes(base.seed, plates, rnd.streamSeed(base.seed, rnd.STREAM_PLATE_WARP), 5, 1, () => false);
  const gaps: number[] = []; for (let k = 0; k < vols.length; k++) if (k % 6 !== 0) { const a = vols[k - 1], b = vols[k]; gaps.push(Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z) * R_KM); }
  const mean = gaps.reduce((a, b) => a + b, 0) / gaps.length; const sd = Math.sqrt(gaps.reduce((a, b) => a + (b - mean) ** 2, 0) / gaps.length);
  cross.push(metric("unit.hotspotSpacingCV", sd / mean, ">=", 0.15, `${vols.length / 6} chains × 6 cones, mean gap ${mean.toFixed(0)} km`));
}
const rows: Result[][] = seeds.map((s) => perSeed[String(s)]!);
const names = rows[0]!.map((r) => r.name);
console.log(`\nmetric | threshold | ${seeds.join(" | ")}`);
for (const [k, name] of names.entries()) console.log(`${name} | ${rows[0]![k]!.threshold} | ${rows.map((r) => `${r[k]!.value} ${r[k]!.pass ? "PASS" : "FAIL"}`).join(" | ")}`);
for (const r of cross) console.log(`${r.name} | ${r.threshold} | ${r.value} ${r.pass ? "PASS" : "FAIL"} (${r.note})`);
const failed = rows.flat().filter((r) => !r.pass).length + cross.filter((r) => !r.pass).length;
console.log(`\n${failed} failing checks`);
if (jsonOut) writeFileSync(jsonOut, JSON.stringify({ F, seeds, perSeed, cross }, null, 1));
