// 그라디언트 노이즈 방향 치우침: 평면 조각에서 기울기 방향의 4겹 고조파 |mean e^{4iθ}| (등방이면 ≈ 0)
import { pathToFileURL } from "node:url";
const SNAP = "/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/inventory-harness/snapshot-f59a8a7";
const { gradientNoise3, fbm3, ridged3 } = await import(pathToFileURL(`${SNAP}/packages/planet/src/generator/noise.ts`).href);
function test(name: string, fn: (x: number, y: number, z: number) => number, zc: number, step = 1 / 16, size = 48) {
  let c4 = 0, s4 = 0, c2 = 0, s2 = 0, wsum = 0;
  const h = 1e-4;
  const hist = new Float64Array(9);
  for (let a = 0; a < size / step; a++) for (let b = 0; b < size / step; b++) {
    const x = a * step + 0.013, y = b * step + 0.029;
    const gx = (fn(x + h, y, zc) - fn(x - h, y, zc)) / (2 * h);
    const gy = (fn(x, y + h, zc) - fn(x, y - h, zc)) / (2 * h);
    const m = Math.hypot(gx, gy); if (m < 1e-9) continue;
    const th = Math.atan2(gy, gx);
    c4 += m * Math.cos(4 * th); s4 += m * Math.sin(4 * th); c2 += m * Math.cos(2 * th); s2 += m * Math.sin(2 * th); wsum += m;
    const fold = ((th * 180 / Math.PI) % 90 + 90) % 90; hist[Math.min(8, Math.floor(fold / 10))] += m;
  }
  const tot = hist.reduce((p, q) => p + q, 0);
  console.log(`${name} (z=${zc}): A4=${(Math.hypot(c4, s4) / wsum).toFixed(3)} A2=${(Math.hypot(c2, s2) / wsum).toFixed(3)} hist(mod90, 10deg)=${Array.from(hist, (v) => (v / tot).toFixed(3)).join(",")}`);
}
const S = 12345;
for (const z of [0.0, 0.31, 0.5]) test("single octave gradientNoise3", (x, y, zz) => gradientNoise3(S, x, y, zz), z);
test("fbm3 6 oct gain .52", (x, y, z) => fbm3(S, x, y, z, 1, 6, 0.52), 0.31, 1 / 16, 48);
test("ridged3 5 oct", (x, y, z) => ridged3(S, x, y, z, 1, 5, 0.55), 0.31, 1 / 16, 48);
// 비교: 축을 비스듬히 자른 평면(법선 (1,1,1)/√3)
test("single octave on tilted plane", (x, y, zz) => { const u = x, v = y; const X = 0.7071 * u - 0.4082 * v + 0.577 * 0.31, Y = -0.7071 * u - 0.4082 * v + 0.577 * 0.31, Z = 0.8165 * v + 0.577 * 0.31; return gradientNoise3(S, X, Y, Z); }, 0);
