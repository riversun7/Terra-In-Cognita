# 바람 방향 줄무늬 정도: 바람을 가로지르는 변화 ÷ 바람을 따르는 변화 (면 안쪽, 육지). 등방이면 약 1
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import *
def run(F, SEED, ks=(3, 8)):
    P = load(F, SEED); n = P.n
    fi = P["face"].astype(np.int64); ii = P["i"].astype(np.int64); jj = P["j"].astype(np.int64)
    up = P["upwindCell"].astype(np.int64)
    land = P["land"] == 1
    di = ii[up] - ii; dj = jj[up] - jj
    ok = (up != np.arange(P.N)) & (fi[up] == fi) & (np.abs(di) <= 1) & (np.abs(dj) <= 1) & land
    fields = {"moistureArriving": P["moistureArriving"].astype(float), "precipitation": P["precipitationExactMm"].astype(float),
              "humidity": P["humidity"].astype(float), "groundElev(reference)": P["groundElevRealM"].astype(float),
              "temperature": P["temperatureExactC"].astype(float), "forest": P["forest"].astype(float)}
    res = {"F": F, "seed": SEED}
    for k in ks:
        pi_, pj_ = -dj, di
        def at(a, b):
            ia = ii + a; jb = jj + b
            inside = (ia >= 0) & (ia < n) & (jb >= 0) & (jb < n)
            idx = fi * n * n + np.clip(jb, 0, n - 1) * n + np.clip(ia, 0, n - 1)
            return idx, inside
        c1, o1 = at(k * pi_, k * pj_); c2, o2 = at(-k * pi_, -k * pj_)
        a1, o3 = at(k * di, k * dj); a2, o4 = at(-k * di, -k * dj)
        sel = ok & o1 & o2 & o3 & o4
        sel &= land[c1] & land[c2] & land[a1] & land[a2]
        r = {}
        for name, v in fields.items():
            cross = np.abs(v[c1] - v[c2])[sel]; along = np.abs(v[a1] - v[a2])[sel]
            r[name] = {"cross/along": round(float(cross.mean() / max(1e-12, along.mean())), 2),
                       "p90cross/p90along": round(float(np.percentile(cross, 90) / max(1e-12, np.percentile(along, 90))), 2)}
        r["cells"] = int(sel.sum()); r["kmBetween"] = round(2 * k * P.cell_km)
        res[f"k={k}"] = r
    return res
out = [run(9, 20261029), run(7, 20261029), run(9, 1), run(9, 42)]
for r in out: print(json.dumps(r))
json.dump(out, open(os.path.join(BASE, "metrics", "anisotropy.json"), "w"), indent=1)
