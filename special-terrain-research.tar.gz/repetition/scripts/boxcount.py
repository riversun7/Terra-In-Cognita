# 해안선 상자 세기(면마다, 면 안쪽만): 크기 s칸 상자 중 해안(육지↔바다 경계)이 든 상자 수 N(s) ∝ s^-D
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import *
res = {}
for F in (7, 9):
    for seed in (20261029, 1, 42):
        P = load(F, seed); n = P.n
        coast = (P["coast"] == 1).reshape(6, n, n)
        sizes = [s for s in (1, 2, 4, 8, 16, 32, 64) if s <= n // 4]
        counts = []
        for s in sizes:
            m = n // s
            c = coast[:, :m * s, :m * s].reshape(6, m, s, m, s).any(axis=(2, 4)).sum()
            counts.append(int(c))
        ls, lc = np.log(np.array(sizes, float)), np.log(np.array(counts, float))
        local = [round(float(-(lc[k + 1] - lc[k]) / (ls[k + 1] - ls[k])), 3) for k in range(len(sizes) - 1)]
        res[f"F{F}-s{seed}"] = {"sizesCells": sizes, "boxSizeKm": [round(s * P.cell_km) for s in sizes], "N": counts, "localD": local,
                                "fitD_all": round(float(-np.polyfit(ls, lc, 1)[0]), 3)}
        print(f"F{F} seed {seed}: localD by scale {list(zip([round(s * P.cell_km) for s in sizes[:-1]], local))} fit {res[f'F{F}-s{seed}']['fitD_all']}")
json.dump(res, open(os.path.join(BASE, "metrics", "boxcount.json"), "w"), indent=1)
