# 기후 바람길 시제품(스크래치, 생성기 아님): v1 재현(이웃 1칸) vs v2(바람 방향을 끼는 이웃 2칸 보간 + 띠 경계를 경도에 따라 흔들고
# 무풍을 없앰). 같은 지형(덤프의 침식 전 고도·바다)으로 습기·강수·습도·바이옴을 다시 계산해 지표를 비교한다.
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import *
F = int(sys.argv[1]) if len(sys.argv) > 1 else 9
SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 20261029
P = load(F, SEED); N = P.N
xyz = P.xyz; nb = P.nb; nbv = np.where(nb >= 0, nb, 0)
lat = P["latitudeDeg"].astype(np.float64); lon = P["longitudeDeg"].astype(np.float64)
ocean = P["ocean"] == 1
h = P["preErosionElevRealM"].astype(np.float64)  # 해수면 0 기준
R_M = R_KM * 1000
def km(v): return v / R_KM
OCEAN_RECHARGE = km(350); LAND_DEPLETION = km(3000); ORO = 1.1; GAIN = 45; OMAX = 2.5; COASTAL = km(450)
e, nvec = tangent_frame(xyz)

def wind_v1(latd):
    a = np.abs(latd); toward = np.where(latd < 0, -1.0, 1.0)
    u = np.zeros_like(a); v = np.zeros_like(a)
    t = a < 30; s1 = np.radians(3 * a); s6 = np.radians(6 * a)
    u = np.where(t, -np.cos(s1), u); v = np.where(t, -toward * 0.35 * np.sin(s6), v)
    m = (a >= 30) & (a < 60); s = np.sin(np.radians(6 * (a - 30)))
    u = np.where(m, s, u); v = np.where(m, toward * 0.3 * s, v)
    p = a >= 60; s = np.sin(np.radians(6 * (a - 60)))
    u = np.where(p, -0.6 * s, u); v = np.where(p, -toward * 0.2 * s, v)
    return u, v

def wind_v2(latd, lond, seed=7):
    # 띠 경계(30°, 60°)를 경도에 따라 ±6°·±5° 흔들고(낮은 주파수 사인 합: 시제품), 바람 세기 하한 0.25를 둔다(무풍 없음).
    rng = np.random.default_rng(seed)
    ph = rng.uniform(0, 2 * np.pi, 6)
    L = np.radians(lond)
    shift30 = 6 * (0.6 * np.sin(2 * L + ph[0]) + 0.4 * np.sin(3 * L + ph[1]))
    shift60 = 5 * (0.6 * np.sin(2 * L + ph[2]) + 0.4 * np.sin(5 * L + ph[3]))
    a = np.abs(latd)
    # 흔든 위도: 30 → 30+shift30, 60 → 60+shift60 를 잇는 구간별 선형 사상
    b30 = 30 + shift30; b60 = 60 + shift60
    am = np.where(a < b30, a * 30 / b30, np.where(a < b60, 30 + (a - b30) * 30 / (b60 - b30), 60 + (a - b60) * 30 / (90 - b60)))
    u, v = wind_v1(np.sign(latd) * am)
    # 세기 하한: 띠 경계에서 바람 방향은 양쪽 평균 방향(동서 성분 0, 남북 성분 유지)으로 이어진다
    sp = np.hypot(u, v)
    toward = np.where(latd < 0, -1.0, 1.0)
    # 경계 근처 남북 성분: 30° 띠에서는 적도 쪽(무역풍 쪽)으로, 60°에서는 극 쪽 공기와 섞임 — 시제품은 세기만 보정
    k = np.where(sp < 0.25, 0.25 / np.maximum(sp, 1e-6), 1.0)
    # 아주 작을 때는 방향이 불안정하므로 남북 바람(적도 쪽)을 섞는다
    small = sp < 0.05
    u = np.where(small, 0.0, u * k); v = np.where(small, -toward * 0.25, v * k)
    return u, v

def upwind_weights(u, v, two=True):
    # 바람이 오는 쪽 방향 = -(u e + v n)
    w = -(u[:, None] * e + v[:, None] * nvec)
    ws = np.linalg.norm(w, axis=1); ok = ws > 0.05
    d = xyz[nbv] - xyz[:, None, :]                      # (N,8,3)
    dl = np.linalg.norm(d, axis=2); dl = np.where(dl > 0, dl, 1)
    # 이웃 방향의 접평면 각
    de = (d * e[:, None, :]).sum(2); dn = (d * nvec[:, None, :]).sum(2)
    ang = np.arctan2(dn, de); ang = np.where(nb >= 0, ang, np.nan)
    wa = np.arctan2((w * nvec).sum(1), (w * e).sum(1))
    diff = (ang - wa[:, None] + np.pi) % (2 * np.pi) - np.pi
    diff = np.where(nb >= 0, diff, np.nan)
    if not two:
        score = np.where(nb >= 0, (d * w[:, None, :]).sum(2) / (dl * np.maximum(ws, 1e-12)[:, None]), -9)
        k1 = score.argmax(1); best = score[np.arange(N), k1]
        use = ok & (best > 0.3)
        i1 = np.where(use, nbv[np.arange(N), k1], np.arange(N))
        return i1, i1, np.ones(N), np.zeros(N), use
    # 시계·반시계 쪽에서 가장 가까운 이웃 둘
    pos = np.where(diff >= 0, diff, np.inf); neg = np.where(diff < 0, -diff, np.inf)
    kp = pos.argmin(1); kn = neg.argmin(1)
    ap = pos[np.arange(N), kp]; an = neg[np.arange(N), kn]
    good = ok & np.isfinite(ap) & np.isfinite(an) & (ap + an < np.radians(100))
    wp = an / np.maximum(ap + an, 1e-12); wn = 1 - wp
    ip = nbv[np.arange(N), kp]; inn = nbv[np.arange(N), kn]
    ip = np.where(good, ip, np.arange(N)); inn = np.where(good, inn, np.arange(N))
    return ip, inn, np.where(good, wp, 1.0), np.where(good, wn, 0.0), good

def transport(ip, inn, wp, wn, use, iters=None):
    if iters is None:
        cov = P.cell_km / R_KM; iters = 1
        while cov < km(4500): cov *= 2; iters *= 2
    step = wp * chord_km(P, np.arange(N), ip) / R_KM + wn * chord_km(P, np.arange(N), inn) / R_KM
    here = np.maximum(0.0, h); there = wp * np.maximum(0.0, h[ip]) + wn * np.maximum(0.0, h[inn])
    climb = np.maximum(0.0, here - there)
    rise = np.where(ocean | ~use, 0.0, climb / np.maximum(step * R_M, 1e-9))
    reach = LAND_DEPLETION * (1 + 1.5 * np.exp(-(lat / 14) ** 2))
    a = np.where(ocean, np.exp(-step / OCEAN_RECHARGE), np.exp(-step / reach - ORO * climb / 1000))
    b = np.where(ocean, 1 - np.exp(-step / OCEAN_RECHARGE), 0.0)
    a = np.where(use, a, 0.0); b = np.where(use, b, np.where(ocean, 1.0, 0.2))
    mout = np.zeros(N)
    for _ in range(iters):
        min_ = wp * mout[ip] + wn * mout[inn]
        mout = a * min_ + b
    arriving = np.where(use, wp * mout[ip] + wn * mout[inn], mout)
    return arriving, rise

def blur(field, passes):
    cur = field.copy()
    for _ in range(passes):
        s = cur.copy(); c = np.ones(N)
        for k in range(8):
            okk = nb[:, k] >= 0
            s += np.where(okk, cur[nbv[:, k]], 0); c += okk
        cur = s / c
    return cur

def finish(arriving, rise, blur_passes):
    arr = blur(arriving, blur_passes) if blur_passes else arriving
    coast = P["distToOceanKm"].astype(np.float64) / R_KM
    coastal = 0.55 * np.exp(-coast / COASTAL)
    moisture = np.maximum(arr, coastal)
    lift = np.where(ocean, 0, np.minimum(OMAX, GAIN * rise))
    base = 0.12 + 0.3 * np.exp(-(lat / 12) ** 2)
    aa = np.abs(lat)
    zonal = 120 + 2300 * np.exp(-(aa / 18) ** 2) + 900 * np.exp(-((aa - 50) / 13) ** 2)
    return np.clip(zonal * (base + (1 - base) * moisture) * (1 + lift), 0, 12000), arr

res = {"F": F, "seed": SEED}
t0 = time.time()
u1, v1 = wind_v1(lat)
i1, _, w1, _, use1 = upwind_weights(u1, v1, two=False)
arr1, rise1 = transport(i1, i1, w1, np.zeros(N), use1)
P1, A1 = finish(arr1, rise1, max(1, 2 * (F - 5)))
ref = P["moistureArriving"].astype(np.float64)
res["v1_replica_vs_generator_moisture_maxAbsDiff"] = round(float(np.abs(A1 - ref).max()), 5)
res["v1_replica_vs_generator_precip_maxAbsDiff_mm"] = round(float(np.abs(P1 - P["precipitationExactMm"]).max()), 2)
u2, v2 = wind_v2(lat, lon)
ip, inn, wp, wn, use2 = upwind_weights(u2, v2, two=True)
arr2, rise2 = transport(ip, inn, wp, wn, use2)
P2, A2 = finish(arr2, rise2, 0)
res["seconds"] = round(time.time() - t0, 1)
np.save(os.path.join(BASE, f"proto-F{F}-s{SEED}-A1.npy"), A1.astype(np.float32)); np.save(os.path.join(BASE, f"proto-F{F}-s{SEED}-A2.npy"), A2.astype(np.float32))
np.save(os.path.join(BASE, f"proto-F{F}-s{SEED}-P1.npy"), P1.astype(np.float32)); np.save(os.path.join(BASE, f"proto-F{F}-s{SEED}-P2.npy"), P2.astype(np.float32))
res["v2_calmCells"] = int((~use2).sum()); res["v1_calmCells"] = int((~use1).sum())
print(json.dumps(res))
