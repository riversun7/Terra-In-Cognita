# 시제품 v3 = v2 + (가) 습기 손실은 넓게 흐린 지형(σ≈150km)의 오르막으로(좁은 봉우리는 바람이 돌아간다)
#                + (나) 땅 위 습기의 기억을 유한하게(증발산 재순환: 1200km에 걸쳐 m_eq로 되돌아감)
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import importlib.util
spec = importlib.util.spec_from_file_location("cp", os.path.join(os.path.dirname(__file__), "climate_proto.py"))
# climate_proto.py는 실행 스크립트라 함수만 다시 쓴다
from plib import *
F = int(sys.argv[1]) if len(sys.argv) > 1 else 9
SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 20261029
src = open(os.path.join(os.path.dirname(__file__), "climate_proto.py")).read()
head = src.split("res = {\"F\": F, \"seed\": SEED}")[0]
g = {"__file__": os.path.join(os.path.dirname(__file__), "climate_proto.py")}
sys.argv = [sys.argv[0], str(F), str(SEED)]
exec(compile(head, "climate_proto_head", "exec"), g)
P = g["P"]; N = P.N; h = g["h"]; ocean = g["ocean"]; lat = g["lat"]; lon = g["lon"]
L_REC = float(os.environ.get("L_REC", 1200)); SIG_PASSES = int(os.environ.get("SIG_PASSES", 96)); M_EQ = float(os.environ.get("M_EQ", 0.45))
t0 = time.time()
hs = g["blur"](np.maximum(0.0, h), SIG_PASSES)
def transport3(ip, inn, wp, wn, use):
    cov = P.cell_km / R_KM; iters = 1
    while cov < g["km"](4500): cov *= 2; iters *= 2
    step = wp * chord_km(P, np.arange(N), ip) / R_KM + wn * chord_km(P, np.arange(N), inn) / R_KM
    here = np.maximum(0.0, h); there = wp * np.maximum(0.0, h[ip]) + wn * np.maximum(0.0, h[inn])
    rise = np.where(ocean | ~use, 0.0, np.maximum(0.0, here - there) / np.maximum(step * R_KM * 1000, 1e-9))
    climb_eff = np.maximum(0.0, hs - (wp * hs[ip] + wn * hs[inn]))
    reach = g["LAND_DEPLETION"] * (1 + 1.5 * np.exp(-(lat / 14) ** 2))
    rec = np.exp(-step / g["km"](L_REC))
    a_land = np.exp(-step / reach - g["ORO"] * climb_eff / 1000) * rec
    b_land = (1 - rec) * M_EQ
    a = np.where(ocean, np.exp(-step / g["OCEAN_RECHARGE"]), a_land)
    b = np.where(ocean, 1 - np.exp(-step / g["OCEAN_RECHARGE"]), b_land)
    a = np.where(use, a, 0.0); b = np.where(use, b, np.where(ocean, 1.0, 0.2))
    mout = np.zeros(N)
    for _ in range(iters):
        mout = a * (wp * mout[ip] + wn * mout[inn]) + b
    return np.where(use, wp * mout[ip] + wn * mout[inn], mout), rise
u2, v2 = g["wind_v2"](lat, lon)
ip, inn, wp, wn, use2 = g["upwind_weights"](u2, v2, two=True)
arr3, rise3 = transport3(ip, inn, wp, wn, use2)
P3, A3 = g["finish"](arr3, rise3, 0)
np.save(os.path.join(BASE, f"proto-F{F}-s{SEED}-A3.npy"), A3.astype(np.float32)); np.save(os.path.join(BASE, f"proto-F{F}-s{SEED}-P3.npy"), P3.astype(np.float32))
print(json.dumps({"seconds": round(time.time() - t0, 1), "L_REC": L_REC, "SIG_PASSES": SIG_PASSES, "M_EQ": M_EQ}))
