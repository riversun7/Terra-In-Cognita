# 시제품 v4 = v3 + (다) 증발 가능량을 정확한 기온으로(습도 계단 없음) + (라) 기후 띠를 경도에 따라 흔든다:
# 위도 대신 "유효 위도" = 위도 + 7°·W(p) (W = 파장 2500~6000km 무작위 파동 합, 시제품용)로 띠 강수·해수면 기온을 낸다.
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from PIL import Image
from plib import *
F = int(sys.argv[1]) if len(sys.argv) > 1 else 9
SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 20261029
AMP = float(os.environ.get("AMP", 7.0))
src = open(os.path.join(os.path.dirname(__file__), "climate_proto.py")).read()
head = src.split("res = {\"F\": F, \"seed\": SEED}")[0]
g = {"__file__": os.path.join(os.path.dirname(__file__), "climate_proto.py")}
sys.argv = [sys.argv[0], str(F), str(SEED)]
exec(compile(head, "climate_proto_head", "exec"), g)
P = g["P"]; N = P.N; h = g["h"]; ocean = g["ocean"]; lat = g["lat"]; lon = g["lon"]; xyz = P.xyz
rng = np.random.default_rng(SEED % 100000)
W = np.zeros(N)
for k in range(12):
    d = rng.normal(size=3); d /= np.linalg.norm(d)
    wl = rng.uniform(2500, 6000) / R_KM  # 라디안 파장
    W += np.sin((xyz @ d) * 2 * np.pi / wl + rng.uniform(0, 2 * np.pi))
W /= np.sqrt(12 / 2)  # 대략 표준편차 1
lat_eff = np.clip(lat + AMP * W, -90, 90)
t0 = time.time()
# 기온: 해수면 기온(유효 위도) − 고도 감률(침식 전 고도)
t = np.abs(lat_eff) / 90
Tsea = 27 - 51 * t * np.sqrt(t)
W2 = np.zeros(N)
for k in range(16):
    d = rng.normal(size=3); d /= np.linalg.norm(d)
    wl = rng.uniform(600, 1500) / R_KM
    W2 += np.sin((xyz @ d) * 2 * np.pi / wl + rng.uniform(0, 2 * np.pi))
W2 /= np.sqrt(16 / 2)
Texact = Tsea - 0.0065 * np.maximum(0.0, h) + float(os.environ.get("T2", 1.5)) * W2
Tr4 = np.clip(np.round(Texact), -128, 127)
# 바람·습기: v3와 같되 바람 띠도 유효 위도로
L_REC = 1200.0; M_EQ = 0.45
hs = g["blur"](np.maximum(0.0, h), 96)
u4, v4 = g["wind_v2"](lat_eff, lon)
ip, inn, wp, wn, use = g["upwind_weights"](u4, v4, two=True)
cov = P.cell_km / R_KM; iters = 1
while cov < g["km"](4500): cov *= 2; iters *= 2
step = wp * chord_km(P, np.arange(N), ip) / R_KM + wn * chord_km(P, np.arange(N), inn) / R_KM
here = np.maximum(0.0, h); there = wp * np.maximum(0.0, h[ip]) + wn * np.maximum(0.0, h[inn])
rise = np.where(ocean | ~use, 0.0, np.maximum(0.0, here - there) / np.maximum(step * R_KM * 1000, 1e-9))
climb_eff = np.maximum(0.0, hs - (wp * hs[ip] + wn * hs[inn]))
reach = g["LAND_DEPLETION"] * (1 + 1.5 * np.exp(-(lat_eff / 14) ** 2))
rec = np.exp(-step / g["km"](L_REC))
a = np.where(ocean, np.exp(-step / g["OCEAN_RECHARGE"]), np.exp(-step / reach - 1.1 * climb_eff / 1000) * rec)
b = np.where(ocean, 1 - np.exp(-step / g["OCEAN_RECHARGE"]), (1 - rec) * M_EQ)
a = np.where(use, a, 0.0); b = np.where(use, b, np.where(ocean, 1.0, 0.2))
mout = np.zeros(N)
for _ in range(iters): mout = a * (wp * mout[ip] + wn * mout[inn]) + b
arr = np.where(use, wp * mout[ip] + wn * mout[inn], mout)
coast = P["distToOceanKm"].astype(np.float64) / R_KM
moisture = np.maximum(arr, 0.55 * np.exp(-coast / g["COASTAL"]))
lift = np.where(ocean, 0, np.minimum(2.5, 45 * rise))
base = 0.12 + 0.3 * np.exp(-(lat_eff / 12) ** 2)
aa = np.abs(lat_eff)
zonal = 120 + 2300 * np.exp(-(aa / 18) ** 2) + 900 * np.exp(-((aa - 50) / 13) ** 2)
P4 = np.clip(zonal * (base + (1 - base) * moisture) * (1 + lift), 0, 12000)
# 습도: 정확한 기온으로 증발 가능량(계단 없음), 바이옴 판정은 반올림 기온
nw = P["nearWaterBonus"].astype(float)
pet = np.maximum(80, 45 * (Texact + 6)); ai = np.round(P4) / pet
hum4 = np.clip(np.round(255 * ai / (ai + 0.75) + nw), 0, 255)
rules = {r["id"]: r["rule"] for r in json.load(open("/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/inventory-harness/snapshot-f59a8a7/content/core/biomes.json"))["entries"]}
land_list = [(P.biomes.index(bb), rules[bb]) for bb in P.biomes if rules[bb]["kind"] == "land"]
land = P["land"] == 1
def classify(tt, hh, ee):
    outb = np.full(len(tt), land_list[-1][0]); done = np.zeros(len(tt), bool)
    for idx, r in land_list:
        m = ~done
        for key, val in (("temperatureC", tt), ("humidity", hh), ("realElevationM", ee)):
            rg = r.get(key)
            if rg is None: continue
            if "min" in rg: m &= val >= rg["min"]
            if "max" in rg: m &= val < rg["max"]
        outb[m] = idx; done |= m
    return outb
b4 = P["biome"].astype(np.int64).copy(); L = np.nonzero(land)[0]
b4[L] = classify(Tr4[L], hum4[L], P["realElevationM"][L].astype(float))
np.save(os.path.join(BASE, f"proto-F{F}-s{SEED}-b5.npy"), b4.astype(np.uint8)); np.save(os.path.join(BASE, f"proto-F{F}-s{SEED}-P5.npy"), P4.astype(np.float32))
np.save(os.path.join(BASE, f"proto-F{F}-s{SEED}-A5.npy"), arr.astype(np.float32)); np.save(os.path.join(BASE, f"proto-F{F}-s{SEED}-h5.npy"), hum4.astype(np.uint8))
w = P["cellAreaKm2"].astype(float)
latbin = np.clip(np.floor(lat + 90).astype(np.int64), 0, 179)
I, H = mutual_info(b4[land], latbin[land], w[land])
elevband = np.clip((P["realElevationM"][land] // 500).astype(np.int64), 0, 30)
I2, _ = mutual_info(b4[land], latbin[land] * 31 + elevband, w[land])
r2o, _ = area_weighted_r2(P4, latbin, w, ocean & (P["distToLandKm"] > 1000))
r2l, _ = area_weighted_r2(P4, latbin, w, land)
r2t, _ = area_weighted_r2(Texact, latbin, w, ocean)
alat = np.abs(lat)
b1d = np.minimum(89, alat.astype(int)); dom = np.zeros((90, len(P.biomes))); np.add.at(dom, (b1d[land], b4[land]), w[land]); tot = dom.sum(1)
dominance = float(np.nansum(np.where(tot > 0, dom.max(1) / np.maximum(tot, 1e-9), 0) * tot / tot.sum()))
shares = {P.biomes[k]: round(float(w[land & (b4 == k)].sum() / w[land].sum()), 3) for k in range(len(P.biomes)) if (land & (b4 == k)).any()}
res = {"AMP": AMP, "biomeInfoExplainedByLat": round(I / H, 3), "byLatAndElev": round(I2 / H, 3), "openOceanPrecipR2": round(r2o, 4),
       "landPrecipR2": round(r2l, 3), "oceanTempR2": round(r2t, 4), "zonalDominance": round(dominance, 3), "shares": shares, "seconds": round(time.time() - t0, 1)}
json.dump(res, open(os.path.join(BASE, "metrics", f"proto5-F{F}-s{SEED}.json"), "w"), indent=1)
print(json.dumps(res))
cols = np.array([[int(c[1:3], 16), int(c[3:5], 16), int(c[5:7], 16)] for c in P.colors], dtype=np.uint8)
Image.fromarray(cols[b4[P.pix]]).save(os.path.join(BASE, "..", "img", "proto-full-v5-biome.png"))
cells = P.pix[260:620, 960:1300]
Image.fromarray(cols[b4[cells]]).resize((680, 720), Image.NEAREST).save(os.path.join(BASE, "..", "img", "proto-desert-v5-biome.png"))
