// 해안선 프랙털 차원: 면 레벨 F5~F9에서 해안 칸 수(= 해안선 길이 ÷ 칸 크기)를 세어 Richardson 기울기로 D를 잰다. 읽기 전용.
import { pathToFileURL } from "node:url";
const ROOT = process.env.GEN_ROOT ?? "/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/inventory-harness/snapshot-f59a8a7";
const gen = await import(pathToFileURL(`${ROOT}/packages/planet/src/generator/index.ts`).href);
const { readFileSync } = await import("node:fs");
const planets = JSON.parse(readFileSync(`${ROOT}/content/core/planets.json`, "utf8")).entries;
const biomes = JSON.parse(readFileSync(`${ROOT}/content/core/biomes.json`, "utf8")).entries;
const seeds = (process.argv[2] ?? "20261029").split(",").map(Number);
const levels = (process.argv[3] ?? "5,6,7,8,9").split(",").map(Number);
for (const seed of seeds) {
  const rows: { F: number; coast: number; land: number; cellKm: number; lengthKm: number }[] = [];
  for (const F of levels) {
    const input = { ...gen.planetInputFromDefinition(planets[0], biomes, F), seed };
    const t0 = performance.now();
    const { fields } = gen.runPlanetGenerator(input);
    let coast = 0, land = 0;
    for (let c = 0; c < fields.water.length; c++) {
      const w = fields.water[c];
      if (!(w & 1)) land++;
      if (w & 8) coast++;
    }
    const cellKm = 6371.0088 * Math.sqrt((4 * Math.PI) / fields.water.length);
    rows.push({ F, coast, land, cellKm, lengthKm: coast * cellKm });
    console.log(JSON.stringify({ seed, F, coast, land, cellKm: +cellKm.toFixed(2), lengthKm: Math.round(coast * cellKm), ms: Math.round(performance.now() - t0), hash: fields.meta.hash }));
  }
  for (let k = 1; k < rows.length; k++) {
    const a = rows[k - 1]!, b = rows[k]!;
    const slope = Math.log(b.lengthKm / a.lengthKm) / Math.log(b.cellKm / a.cellKm);
    console.log(`seed ${seed} F${a.F}->F${b.F}: D = 1 - slope = ${(1 - slope).toFixed(3)}`);
  }
  const a = rows[0]!, b = rows[rows.length - 1]!;
  console.log(`seed ${seed} F${a.F}->F${b.F}: D = ${(1 - Math.log(b.lengthKm / a.lengthKm) / Math.log(b.cellKm / a.cellKm)).toFixed(3)}`);
}
