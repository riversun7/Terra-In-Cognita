// 비용 측정: F9 격자 전체에 fbm3(옥타브 1·4·6) 한 번, 8이웃 상자 흐림 1회, 바람길 야코비 1회(이웃 2칸 보간) 시간
import { pathToFileURL } from "node:url";
const SNAP = "/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/inventory-harness/snapshot-f59a8a7/packages/planet/src/generator";
const { fbm3 } = await import(pathToFileURL(`${SNAP}/noise.ts`).href);
const { buildGrid, neighbors8 } = await import(pathToFileURL(`${SNAP}/grid.ts`).href);
const grid = buildGrid(9);
const N = grid.cellCount;
const out = new Float32Array(N);
for (const oct of [1, 4, 6]) {
  const t0 = performance.now();
  for (let c = 0; c < N; c++) out[c] = fbm3(12345, grid.x[c], grid.y[c], grid.z[c], 5, oct, 0.5);
  const ms = performance.now() - t0;
  console.log(`fbm3 ${oct} octaves over F9 (${N} cells): ${ms.toFixed(0)} ms = ${(ms * 1e6 / N / oct).toFixed(0)} ns per octave-cell`);
}
// 이웃 표를 한 번 만들어 두고(생성기의 흐림·거리장은 neighbors8을 매번 부름) 야코비 한 번
const nb = new Int32Array(N * 8); const tmp = new Int32Array(8);
let t0 = performance.now();
for (let c = 0; c < N; c++) { neighbors8(grid, c, tmp); nb.set(tmp, c * 8); }
console.log(`neighbour table F9: ${(performance.now() - t0).toFixed(0)} ms`);
const ip = new Int32Array(N), inn = new Int32Array(N); const wp = new Float32Array(N), a = new Float32Array(N), b = new Float32Array(N);
for (let c = 0; c < N; c++) { ip[c] = nb[c * 8 + 4] >= 0 ? nb[c * 8 + 4] : c; inn[c] = nb[c * 8 + 7] >= 0 ? nb[c * 8 + 7] : c; wp[c] = 0.6; a[c] = 0.99; b[c] = 0.01; }
let m = new Float32Array(N), m2 = new Float32Array(N);
t0 = performance.now();
for (let it = 0; it < 256; it++) {
  for (let c = 0; c < N; c++) { const w = wp[c]; m2[c] = a[c] * (w * m[ip[c]] + (1 - w) * m[inn[c]]) + b[c]; }
  [m, m2] = [m2, m];
}
console.log(`two-neighbour Jacobi transport, 256 sweeps over F9: ${(performance.now() - t0).toFixed(0)} ms`);
