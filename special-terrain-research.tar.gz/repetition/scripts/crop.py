# 확대 잘라내기: 원본 PNG 영역을 nearest로 키워 저장
import sys
from PIL import Image
src, out, x0, y0, x1, y1, scale = sys.argv[1], sys.argv[2], *map(int, sys.argv[3:8])
im = Image.open(src).crop((x0, y0, x1, y1))
im = im.resize(((x1-x0)*scale, (y1-y0)*scale), Image.NEAREST)
im.save(out)
print(out, im.size)
