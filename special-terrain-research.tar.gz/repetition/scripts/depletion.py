# 오르막 습기 결손이 큰 산맥 하나 때문인지, 바람길 내내 잔 기복이 쌓인 것인지 + 해상도에 따라 달라지는지
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import *
def run(F, SEED):
    P = load(F, SEED); N = P.N
    up = P["upwindCell"].astype(np.int64); ocean = P["ocean"] == 1; land = P["land"] == 1
    h = np.maximum(0.0, P["preErosionElevRealM"].astype(np.float64))
    climb = np.where(ocean, 0.0, np.maximum(0.0, h - h[up]))
    # 큰 오르막(한 칸에서 100m 넘게 오름)과 잔 오르막을 나눠 바람길(첫 바다까지, 4500km)에서 더한다
    step = chord_km(P, np.arange(N), up)
    big_thr = 100.0 * (P.cell_km / 18.0)  # 칸 크기에 비례(18km 칸에서 100m)
    cur = np.arange(N); dist = np.zeros(N); cum = np.zeros(N); cum_small = np.zeros(N); maxh = np.zeros(N)
    alive = land.copy()
    while alive.any():
        a = np.nonzero(alive)[0]; c = cur[a]
        stop = ocean[c] | (up[c] == c) | (dist[a] > 4500)
        go = a[~stop]; cg = cur[go]
        cl = climb[cg]
        cum[go] += cl; cum_small[go] += np.where(cl < big_thr, cl, 0.0)
        maxh[go] = np.maximum(maxh[go], h[cg])
        dist[go] += step[cg]; cur[go] = up[cg]
        alive[a[stop]] = False
    L = land
    m = P["moistureArriving"].astype(np.float64); m0 = P["moistureArrivingNoOro"].astype(np.float64)
    with np.errstate(invalid="ignore", divide="ignore"):
        deficit = np.where(m0 > 0.02, 1 - m / m0, 0.0)
    # 길 위 최고점보다 누적 오르막이 얼마나 큰가(= 같은 높이를 몇 번 다시 올랐나)
    with np.errstate(invalid="ignore", divide="ignore"):
        ratio = np.where(maxh > 50, cum / maxh, np.nan)
    res = {"F": F, "seed": SEED, "cellKm": round(P.cell_km, 1),
           "landDeficit>0.5": round(float((deficit[L] > 0.5).mean()), 3),
           "landDeficit_median": round(float(np.median(deficit[L])), 3),
           "cumClimbM_median": round(float(np.median(cum[L]))), "cumClimbM_p90": round(float(np.percentile(cum[L], 90))),
           "smallClimbShare_median": round(float(np.nanmedian(np.where(cum[L] > 0, cum_small[L] / cum[L], np.nan))), 3),
           "cumOverPathMax_median": round(float(np.nanmedian(ratio[L])), 2),
           "landPrecip_median": round(float(np.median(P["precipitationExactMm"][L]))),
           "landHumidity_median": float(np.median(P["humidity"][L])),
           "desertShareOfLand": round(float((P["biome"][L] == P.B("desert")).mean()), 4)}
    return res
out = [run(7, 20261029), run(9, 20261029), run(7, 1), run(9, 1), run(7, 42), run(9, 42)]
for r in out: print(json.dumps(r))
json.dump(out, open(os.path.join(BASE, "metrics", "depletion.json"), "w"), indent=1)
