// 하네스로 행성 하나를 만들어 이 폴더(out/dump-…)에 칸별 배열을 남긴다(하네스 캐시는 쓰지 않는다). 읽기 전용.
import { loadPlanet, writePlanetDump } from "../../inventory-harness/lib/planet.ts";
import path from "node:path";
const faceLevel = Number(process.argv[2] ?? 9);
const seedArg = process.argv[3];
const t0 = performance.now();
const planet = await loadPlanet({ faceLevel, seed: seedArg ? Number(seedArg) : undefined, cache: false, verify: true, log: (l) => console.log(l) });
const v = planet.meta.verification;
console.log(`F${faceLevel} seed ${planet.meta.seed} hash ${planet.meta.hash} official ${v.officialHash} known ${v.knownHash} ${Math.round(performance.now() - t0)} ms`);
console.log(JSON.stringify(v));
const dir = path.resolve(import.meta.dirname, "..", "out", `dump-F${faceLevel}-s${planet.meta.seed}`);
writePlanetDump(dir, planet);
console.log("dump", dir, `rss ${Math.round(process.memoryUsage().rss / 2 ** 20)} MiB`);
