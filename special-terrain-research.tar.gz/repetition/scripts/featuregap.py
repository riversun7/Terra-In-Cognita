# 1차맵 수준에서 "무언가 다른 것"까지 거리: 바이옴 경계·강·해안·호수·가파른 곳(경사 > 20 m/km 실제)·열점·마른 분지 중 가장 가까운 것
# + 바이옴 덩어리 크기 분포(꼬리 기울기)
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import *
def dist_cells(P, src, max_iter=2000):
    N = P.N; nb = P.nb; nbv = np.where(nb >= 0, nb, 0)
    wts = np.array([1.4142, 1, 1.4142, 1, 1, 1.4142, 1, 1.4142])
    d = np.where(src, 0.0, np.inf)
    for it in range(max_iter):
        best = d.copy()
        for k in range(8):
            cand = np.where(nb[:, k] >= 0, d[nbv[:, k]] + wts[k], np.inf)
            np.minimum(best, cand, out=best)
        if np.array_equal(best, d): break
        d = best
    return d
out = {}
for seed in (20261029, 1, 42):
    P = load(9, seed); N = P.N
    land = P["land"] == 1; biome = P["biome"].astype(np.int64)
    nb = P.nb; nbv = np.where(nb >= 0, nb, 0)
    edge = np.zeros(N, bool)
    for k in range(8):
        o = nbv[:, k]; edge |= (nb[:, k] >= 0) & land[o] & (biome[o] != biome)
    feat = (edge & land) | (P["riverCell"] == 1) | (P["coast"] == 1) | (P["lake"] == 1) | (land & (P["slopeMPerKm"] > 20)) \
        | (P["hotspotRealM"] > 300) | (P["basinKind"] == 3)
    d = dist_cells(P, feat)
    dl = d[land] * P.cell_km
    r = {"featureShareOfLand": round(float(feat[land].mean()), 3),
         "distToNearestFeature_realKm": {"median": round(float(np.median(dl)), 1), "p90": round(float(np.percentile(dl, 90)), 1), "max": round(float(dl.max()), 1)},
         "distToNearestFeature_gameKm": {"median": round(float(np.median(dl)) / 12, 2), "p90": round(float(np.percentile(dl, 90)) / 12, 2), "max": round(float(dl.max()) / 12, 2)},
         "landShareFarther_than_10_2ndMaps": round(float((d[land] > 10).mean()), 3)}
    # 바이옴 덩어리 크기 꼬리: 칸 수 a 이상 덩어리 수 N(≥a) ∝ a^-b, a ∈ [10, 3000]
    lab = components(P, land, biome.astype(np.int32))
    ids, counts, _ = comp_sizes(lab)
    a = np.unique(np.round(np.logspace(1, np.log10(3000), 12)).astype(int))
    Ns = np.array([(counts >= x).sum() for x in a])
    ok = Ns > 0
    b = -np.polyfit(np.log(a[ok]), np.log(Ns[ok]), 1)[0]
    r["biomePatchCCDFslope_b(10..3000 cells)"] = round(float(b), 2)
    out[str(seed)] = r
    print(seed, json.dumps(r))
json.dump(out, open(os.path.join(BASE, "metrics", "featuregap-F9.json"), "w"), indent=1)
