// 격자 내보내기: 8이웃 표(Int32, 칸 × 8), 칸 중심(Float64 x,y,z), 등장방형 화소 → 칸(render.ts와 같은 식). 읽기 전용.
import { writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
const ROOT = "/home/user/terra-in-cognita/.claude/worktrees/wf_855dd1b7-352-1/packages/planet/src";
const { buildGrid, neighbors8 } = await import(pathToFileURL(`${ROOT}/generator/grid.ts`).href);
const { xyzToCell } = await import(pathToFileURL(`${ROOT}/projection.ts`).href);
const { decodeCellKey } = await import(pathToFileURL(`${ROOT}/cellKey.ts`).href);
const F = Number(process.argv[2] ?? 9);
const grid = buildGrid(F);
const out = new Int32Array(8);
const nb = new Int32Array(grid.cellCount * 8);
for (let c = 0; c < grid.cellCount; c++) {
  neighbors8(grid, c, out);
  nb.set(out, c * 8);
}
const dir = path.resolve(import.meta.dirname, "..", "out", `grid-F${F}`);
mkdirSync(dir, { recursive: true });
writeFileSync(path.join(dir, "nbr8.bin"), new Uint8Array(nb.buffer));
const xyz = new Float64Array(grid.cellCount * 3);
for (let c = 0; c < grid.cellCount; c++) { xyz[3 * c] = grid.x[c]; xyz[3 * c + 1] = grid.y[c]; xyz[3 * c + 2] = grid.z[c]; }
writeFileSync(path.join(dir, "xyz.bin"), new Uint8Array(xyz.buffer));
const n = grid.n;
const width = Math.max(1024, 4 * n);
const height = width / 2;
const cellAt = new Int32Array(width * height);
for (let py = 0; py < height; py++) {
  const lat = Math.PI / 2 - ((py + 0.5) / height) * Math.PI;
  for (let px = 0; px < width; px++) {
    const lon = ((px + 0.5) / width) * 2 * Math.PI - Math.PI;
    const key = xyzToCell([Math.cos(lat) * Math.cos(lon), Math.cos(lat) * Math.sin(lon), Math.sin(lat)], F);
    const { face, i, j } = decodeCellKey(key);
    cellAt[py * width + px] = face * n * n + j * n + i;
  }
}
writeFileSync(path.join(dir, "equirect-cell.bin"), new Uint8Array(cellAt.buffer));
writeFileSync(path.join(dir, "info.json"), JSON.stringify({ F, n, cellCount: grid.cellCount, width, height, meanCellAngle: grid.meanCellAngle }));
console.log(dir, grid.cellCount, width, height);
