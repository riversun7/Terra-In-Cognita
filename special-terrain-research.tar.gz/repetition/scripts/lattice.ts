// 노이즈 격자 흔적: 옥타브가 정확히 2배라 기본 격자점에서 모든 옥타브가 0이 된다 → 격자점 근처 RMS가 얼마나 줄어드나.
// 생성기 noise.ts(고정 사본 f59a8a7)를 그대로 부르고, 무늬 공간 회전은 하네스 덤프 메타에서 읽는다. 읽기 전용.
import { pathToFileURL } from "node:url";
import { readFileSync } from "node:fs";
const SNAP = "/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/inventory-harness/snapshot-f59a8a7";
const G = `${SNAP}/packages/planet/src/generator`;
const { fbm3, ridged3, octavesFor } = await import(pathToFileURL(`${G}/noise.ts`).href);
const { buildGrid } = await import(pathToFileURL(`${G}/grid.ts`).href);
const { streamSeed, STREAM_RELIEF, STREAM_MOUNTAINS, STREAM_CONTINENTS, STREAM_FOREST } = await import(pathToFileURL(`${G}/random.ts`).href);
const F = Number(process.argv[2] ?? 9);
const seed = Number(process.argv[3] ?? 20261029);
const meta = JSON.parse(readFileSync(new URL(`../out/dump-F${F}-s${seed}/manifest.json`, import.meta.url), "utf8")).meta;
const r: number[] = meta.rotation;
const grid = buildGrid(F);
const cases = [
  { name: "relief fBm (tectonics.ts:225, f=5, gain 0.52)", seed: streamSeed(seed, STREAM_RELIEF), f: 5, oct: octavesFor(5, grid.meanCellAngle, 8), gain: 0.52, ridged: false, rotated: true },
  { name: "ridge texture (tectonics.ts:239, f=7)", seed: streamSeed(seed, STREAM_MOUNTAINS), f: 7, oct: octavesFor(7, grid.meanCellAngle, 6), gain: 0.55, ridged: true, rotated: true },
  { name: "continent fBm (tectonics.ts:115, f=1.1)", seed: streamSeed(seed, STREAM_CONTINENTS), f: 1.1, oct: Math.min(6, octavesFor(1.1, grid.meanCellAngle, 6)), gain: 0.55, ridged: false, rotated: true },
  { name: "forest variation (surface.ts:196, f=14, UNROTATED)", seed: streamSeed(seed, STREAM_FOREST), f: 14, oct: 3, gain: 0.5, ridged: false, rotated: false },
];
for (const k of cases) {
  // 격자점까지 거리(격자 단위) 구간별 RMS(fBm) 또는 평균(능선)
  const bins = 10;
  const sum = new Float64Array(bins), sum2 = new Float64Array(bins), cnt = new Float64Array(bins);
  let all = 0, all2 = 0, alln = 0;
  for (let c = 0; c < grid.cellCount; c += 3) {
    let x = grid.x[c], y = grid.y[c], z = grid.z[c];
    if (k.rotated) { const X = r[0] * x + r[1] * y + r[2] * z, Y = r[3] * x + r[4] * y + r[5] * z, Z = r[6] * x + r[7] * y + r[8] * z; x = X; y = Y; z = Z; }
    const v = k.ridged ? ridged3(k.seed, x, y, z, k.f, k.oct, k.gain) : fbm3(k.seed, x, y, z, k.f, k.oct, k.gain);
    const qx = x * k.f, qy = y * k.f, qz = z * k.f;
    const d = Math.hypot(qx - Math.round(qx), qy - Math.round(qy), qz - Math.round(qz)); // 0 ~ 0.866
    const b = Math.min(bins - 1, Math.floor((d / 0.866) * bins));
    const val = k.ridged ? v : v;
    sum[b] += val; sum2[b] += val * val; cnt[b]++;
    all += val; all2 += val * val; alln++;
  }
  const rmsAll = Math.sqrt(all2 / alln);
  const rows = [];
  for (let b = 0; b < bins; b++) {
    if (!cnt[b]) continue;
    const mean = sum[b] / cnt[b];
    const rms = Math.sqrt(sum2[b] / cnt[b]);
    const sd = Math.sqrt(Math.max(0, sum2[b] / cnt[b] - mean * mean));
    rows.push(`${((b + 0.5) * 0.866 / bins).toFixed(2)}:${k.ridged ? `mean ${mean.toFixed(3)} sd ${sd.toFixed(3)}` : `rms/all ${(rms / rmsAll).toFixed(2)}`} (${(cnt[b] / alln * 100).toFixed(1)}%)`);
  }
  console.log(`${k.name}: octaves ${k.oct}, lattice spacing ${(6371 / k.f).toFixed(0)} km real (${(1 / k.f / grid.meanCellAngle).toFixed(1)} F${F} cells)`);
  console.log("   distance to nearest base-lattice vertex (lattice units) -> " + rows.join(" | "));
}
