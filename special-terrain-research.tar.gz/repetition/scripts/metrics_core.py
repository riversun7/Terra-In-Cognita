# 반복·단조로움 측정 (읽기 전용): 위도 띠 설명력, 바람 띠 경계선, 바람길 방향 양자화, 바이옴 덩어리, 2차맵 입력 균일성,
# 경계 방향, 면 이음매, 지형 단조로움, 바다 단조로움, 강이 만든 바이옴
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import *

F = int(sys.argv[1]) if len(sys.argv) > 1 else 9
SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 20261029
P = load(F, SEED)
N, n = P.N, P.n
out = {"F": F, "seed": SEED, "cellKm": P.cell_km}
t0 = time.time()
lat = P["latitudeDeg"].astype(np.float64); alat = np.abs(lat)
w = P["cellAreaKm2"].astype(np.float64)
land = P["land"] == 1; ocean = P["ocean"] == 1; lake = P["lake"] == 1
biome = P["biome"].astype(np.int32)
T = P["temperatureExactC"].astype(np.float64); Pm = P["precipitationExactMm"].astype(np.float64)
hum = P["humidity"].astype(np.float64)
B = {b: i for i, b in enumerate(P.biomes)}
nb = P.nb

# ── A. 위도 띠 설명력 ──
latbin = np.clip(np.floor(lat + 90).astype(np.int64), 0, 179)
A = {}
for name, vals in [("temperature", T), ("precipitation", Pm), ("humidity", hum), ("logPrecip", np.log(Pm + 1))]:
    for mname, m in [("land", land), ("ocean", ocean)]:
        if name == "humidity" and mname == "ocean": continue
        r2, rmse = area_weighted_r2(vals, latbin, w, m)
        A[f"{name}.{mname}"] = {"R2_lat1deg": round(r2, 4), "withinBandRms": round(rmse, 2)}
I, H = mutual_info(biome[land], latbin[land], w[land])
elevband = np.clip((P["realElevationM"][land] // 500).astype(np.int64), 0, 30)
I2, _ = mutual_info(biome[land], latbin[land] * 31 + elevband, w[land])
A["biome.land"] = {"H_bits": round(H, 3), "I_lat_bits": round(I, 3), "share_explained_by_lat": round(I / H, 3),
                   "share_explained_by_lat_and_elev500m": round(I2 / H, 3)}
out["A_zonal"] = A

# ── B. 바람 띠 경계(무풍대) ──
up = P["upwindCell"]
calm = up == np.arange(N)
bins = np.arange(-90, 90.01, 0.25)
bi = np.clip(np.digitize(lat, bins) - 1, 0, len(bins) - 2)
def band_mean(vals, m):
    s = np.bincount(bi[m], weights=(vals * w)[m], minlength=len(bins) - 1)
    c = np.bincount(bi[m], weights=w[m], minlength=len(bins) - 1)
    return np.where(c > 0, s / np.where(c > 0, c, 1), np.nan), c
calm_share, _ = band_mean(calm.astype(float), np.ones(N, bool))
m_land, c_land = band_mean(P["moistureArriving"].astype(float), land)
h_land, _ = band_mean(hum, land)
# 바이옴 경계 칸: 8이웃 중 다른 육지 바이옴이 있는 육지 칸
nbv = np.where(nb >= 0, nb, 0)
diff = np.zeros(N, bool)
for k in range(8):
    o = nbv[:, k]
    diff |= (nb[:, k] >= 0) & land[o] & (biome[o] != biome)
edge_share, _ = band_mean((diff & land).astype(float), land)
centers = (bins[:-1] + bins[1:]) / 2
Bres = {"calmBands": [], "landHumidityJumps": []}
calm_rows = [(round(float(c), 2), round(float(s), 3)) for c, s in zip(centers, calm_share) if s > 0.5]
Bres["calmBands"] = calm_rows
# 위도 띠 평균 습도의 0.25° 단위 변화가 큰 곳(육지 충분한 띠만)
ok = c_land > 0.002 * c_land.sum()
dh = np.abs(np.diff(h_land))
okd = ok[1:] & ok[:-1]
order = np.argsort(np.where(okd, -dh, 0))[:8]
Bres["landHumidityJumps"] = [{"lat": round(float(bins[k + 1]), 2), "dHumidityPer0.25deg": round(float(dh[k]), 1)} for k in order if okd[k]]
Bres["landHumidityStepMedian"] = round(float(np.nanmedian(dh[okd])), 2)
# 경계 밀도: 무풍대 근처(±0.75°) vs 나머지
def edge_density(lo, hi):
    m = land & (alat >= lo) & (alat < hi)
    return float((diff & m).sum() / max(1, m.sum()))
Bres["edgeDensity"] = {"28.0-29.0": round(edge_density(28.0, 29.0), 4), "29.0-31.0": round(edge_density(29.0, 31.0), 4),
                       "31.0-32.0": round(edge_density(31.0, 32.0), 4), "59.0-61.0": round(edge_density(59.0, 61.0), 4),
                       "allLand": round(float((diff & land).sum() / land.sum()), 4)}
Bres["calmCellsShareOfLand"] = round(float((calm & land).sum() / land.sum()), 4)
out["B_calmBelts"] = Bres

# ── C. 바람길 방향 양자화 ──
e, nvec = tangent_frame(P.xyz)
has = ~calm
d = P.xyz[up] - P.xyz
az = np.degrees(np.arctan2((d * nvec).sum(1), (d * e).sum(1)))
u = P["windU"].astype(np.float64); v = P["windV"].astype(np.float64)
true_az = np.degrees(np.arctan2(-v, -u))
err = (az - true_az + 180) % 360 - 180
C = {"absErrDeg_mean": round(float(np.abs(err[has]).mean()), 2), "absErrDeg_p90": round(float(np.percentile(np.abs(err[has]), 90)), 2),
     "absErrDeg_max": round(float(np.abs(err[has]).max()), 2)}
# 바람길이 곧은 정도: 바람이 오는 칸도 같은 이웃 방향을 고른 비율(칸 번호 차이가 같은지로: 면 안쪽만)
fi = P["face"].astype(np.int64); ii = P["i"].astype(np.int64); jj = P["j"].astype(np.int64)
di = ii[up] - ii; dj = jj[up] - jj
same_face = fi[up] == fi
inner = has & same_face & (ii > 1) & (ii < n - 2) & (jj > 1) & (jj < n - 2)
up2 = up[up]
same_dir = inner & (fi[up2] == fi) & ((ii[up2] - ii[up]) == di) & ((jj[up2] - jj[up]) == dj)
C["sameDirectionAsUpwindCell"] = round(float(same_dir.sum() / inner.sum()), 4)
# 바람길(다음 칸들) 방향이 같은 채로 몇 칸 이어지나: 표본 2만 칸
rng = np.random.default_rng(1)
sample = rng.choice(np.nonzero(inner & land)[0], size=min(20000, int((inner & land).sum())), replace=False)
runs = []
for c in sample:
    k = 0; cur = c; dd = (ii[up[c]] - ii[c], jj[up[c]] - jj[c], fi[c])
    while k < 2000:
        nx = up[cur]
        if nx == cur or fi[nx] != dd[2] or (ii[nx] - ii[cur], jj[nx] - jj[cur]) != dd[:2]: break
        cur = nx; k += 1
    runs.append(k)
runs = np.array(runs)
C["straightRunCells_median"] = float(np.median(runs)); C["straightRunCells_p90"] = float(np.percentile(runs, 90))
C["straightRunKm_median"] = round(float(np.median(runs)) * P.cell_km, 0); C["straightRunKm_p90"] = round(float(np.percentile(runs, 90)) * P.cell_km, 0)
out["C_windQuantization"] = C

# ── E. 바이옴 덩어리 ──
lab = components(P, land, biome)
ids, counts, area = comp_sizes(lab, w)
cb = biome[ids]
E = {"landPatches": int(len(ids)), "landCells": int(land.sum())}
per = {}
for name in P.biomes:
    k = B[name]
    sel = cb == k
    if not sel.any(): continue
    a = area[sel]; cnt = counts[sel]
    per[name] = {"patches": int(sel.sum()), "singletons": int((cnt == 1).sum()), "largestShareOfBiome": round(float(a.max() / a.sum()), 3),
                 "largestCells": int(cnt.max()), "medianCells": float(np.median(cnt)), "shareOfLand": round(float(a.sum() / w[land].sum()), 4)}
E["perBiome"] = per
# 큰 덩어리 몇 개가 육지를 얼마나 덮나
srt = np.sort(area)[::-1]
E["top10PatchesShareOfLand"] = round(float(srt[:10].sum() / w[land].sum()), 3)
E["top50PatchesShareOfLand"] = round(float(srt[:50].sum() / w[land].sum()), 3)
# 바다 바이옴
olab = components(P, ocean, biome)
oids, ocounts, oarea = comp_sizes(olab, w)
deep = biome[oids] == B["ocean_deep"]
E["oceanDeep"] = {"shareOfAllArea": round(float(w[biome == B["ocean_deep"]].sum() / w.sum()), 4), "patches": int(deep.sum()),
                  "largestShareOfDeep": round(float(oarea[deep].max() / oarea[deep].sum()), 3)}
# 창(면 격자 k×k 칸) 안 육지 바이옴 수
win = {}
for kwin in [4, 8, 16, 32]:
    if kwin > n: continue
    f = (fi * (n // kwin) + jj // kwin) * (n // kwin) + ii // kwin
    nwin = 6 * (n // kwin) ** 2
    landcnt = np.bincount(f, weights=land.astype(float), minlength=nwin)
    present = np.zeros((nwin, len(P.biomes)), bool)
    present[f[land], biome[land]] = True
    distinct = present.sum(1)
    full = landcnt >= 0.9 * kwin * kwin
    win[f"{kwin}x{kwin}"] = {"windowKm": round(kwin * P.cell_km, 1), "landWindows": int(full.sum()),
                             "singleBiomeShare": round(float((distinct[full] == 1).mean()), 3) if full.any() else None,
                             "meanDistinct": round(float(distinct[full].mean()), 2) if full.any() else None}
E["windows"] = win
out["E_biomePatches"] = E

# ── F. 2차맵 입력 균일성 ──
Fres = {}
elev = P["elevationM"].astype(np.int64)
forest = P["forest"].astype(np.int64)
flags = (P["riverCell"].astype(np.int64) << 0) | (P["coast"].astype(np.int64) << 1) | (P["lake"].astype(np.int64) << 2)
for qname, q in {
    "coarse": biome.astype(np.int64) * 10_000_000 + (P["temperatureC"].astype(np.int64) + 128) // 3 * 100_000 + (hum.astype(np.int64) // 16) * 1000 + np.clip(elev + 1000, 0, 4000) // 25 * 10 + flags,
    "fine": biome.astype(np.int64) * 10_000_000 + (P["temperatureC"].astype(np.int64) + 128) * 30_000 + (hum.astype(np.int64) // 4) * 400 + np.clip(elev + 1000, 0, 4000) // 10 + 0 * forest + flags * 0,
}.items():
    same_all = land.copy()
    for k in range(8):
        o = nbv[:, k]
        same_all &= (nb[:, k] < 0) | (q[o] == q)
    qlab = components(P, land, q)
    qids, qcounts, qarea = comp_sizes(qlab, w)
    Fres[qname] = {"landCellsWithAllNeighboursIdentical": round(float(same_all.sum() / land.sum()), 3),
                   "regions": int(len(qids)), "medianRegionCells": float(np.median(qcounts)),
                   "landInRegions>=100cells": round(float(qarea[qcounts >= 100].sum() / w[land].sum()), 3),
                   "landInRegions>=1000cells": round(float(qarea[qcounts >= 1000].sum() / w[land].sum()), 3),
                   "largestRegionCells": int(qcounts.max())}
# 행 따라 걸을 때 같은 바이옴이 이어지는 칸 수(면 안, 육지만)
bimg = np.where(land, biome, -1).reshape(6, n, n)
runs = []
for f_ in range(6):
    row = bimg[f_]
    for r in range(0, n, max(1, n // 64)):
        line = row[r]
        k = 0
        while k < n:
            if line[k] < 0: k += 1; continue
            s = k
            while k < n and line[k] == line[s]: k += 1
            runs.append(k - s)
runs = np.array(runs)
wr = runs.astype(float)
Fres["biomeRunAlongRows"] = {"meanCellsWeightedByCell": round(float((wr * wr).sum() / wr.sum()), 1), "medianRun": float(np.median(runs)),
                             "p90Run": float(np.percentile(runs, 90)), "meanRunKmWeighted": round(float((wr * wr).sum() / wr.sum()) * P.cell_km, 0)}
# 이웃과의 차이: 기온·습도·고도
dT = np.zeros(N); dH = np.zeros(N); dE = np.zeros(N); cnt = np.zeros(N)
for k in range(8):
    o = nbv[:, k]; okk = (nb[:, k] >= 0) & land & land[o]
    dT += np.where(okk, np.abs(T[o] - T), 0); dH += np.where(okk, np.abs(hum[o] - hum), 0)
    dE += np.where(okk, np.abs(P["groundElevRealM"][o].astype(float) - P["groundElevRealM"].astype(float)), 0); cnt += okk
m = land & (cnt > 0)
Fres["neighbourDiffMedian"] = {"temperatureC": round(float(np.median(dT[m] / cnt[m])), 3), "humidity": round(float(np.median(dH[m] / cnt[m])), 2),
                               "groundRealM": round(float(np.median(dE[m] / cnt[m])), 1), "groundGameM": round(float(np.median(dE[m] / cnt[m])) / 12, 2)}
out["F_secondMapInputs"] = Fres

# ── G. 바이옴 경계 방향(위도선과 나란한가) ──
bnd = diff & land
normal = np.zeros((N, 3))
for k in range(8):
    o = nbv[:, k]; okk = (nb[:, k] >= 0) & land[o] & (biome[o] != biome) & bnd
    normal += np.where(okk[:, None], P.xyz[o] - P.xyz, 0)
ne = (normal * e).sum(1); nn = (normal * nvec).sum(1)
mag = np.hypot(ne, nn)
okb = bnd & (mag > 0)
ang = np.degrees(np.arctan2(np.abs(ne[okb]), np.abs(nn[okb])))  # 0 = 경계 법선이 남북(경계선은 동서 = 위도선과 나란)
hist, _ = np.histogram(ang, bins=[0, 10, 20, 30, 40, 50, 60, 70, 80, 90.0001])
G = {"normalFromNorthHist10deg": [round(float(x), 3) for x in hist / hist.sum()], "isotropicExpect": round(1 / 9, 3)}
# 바이옴 쌍별: 기온 문턱 경계(툰드라|타이가, 타이가|온대림, 초지|사바나, 온대림|열대우림)
pairs = {}
for a_, b_ in [("tundra", "taiga"), ("taiga", "temperate_forest"), ("grassland", "savanna"), ("temperate_forest", "tropical_rainforest"),
               ("desert", "savanna"), ("desert", "grassland"), ("ice_sheet", "tundra")]:
    ka, kb = B[a_], B[b_]
    sel = np.zeros(N, bool)
    for k in range(8):
        o = nbv[:, k]
        sel |= (nb[:, k] >= 0) & (biome == ka) & (biome[o] == kb)
    sel &= okb
    if sel.sum() < 20: continue
    aa = np.degrees(np.arctan2(np.abs(ne[sel]), np.abs(nn[sel])))
    pairs[f"{a_}|{b_}"] = {"cells": int(sel.sum()), "within10degOfLatitudeLine": round(float((aa < 10).mean()), 3),
                            "within20deg": round(float((aa < 20).mean()), 3)}
G["pairs"] = pairs
out["G_boundaryOrientation"] = G

# ── H. 면 이음매 ──
Hres = {}
edge_cells = ((ii == 0) | (ii == n - 1) | (jj == 0) | (jj == n - 1)) & ~(((ii == 0) | (ii == n - 1)) & ((jj == 0) | (jj == n - 1)))
# 이음매 건너 이웃: 다른 면인 이웃(4방향 중), 비교: 같은 방향 반대쪽(면 안) 이웃
opp = {1: 6, 6: 1, 3: 4, 4: 3}
fields = {"precipitation": Pm, "temperature": T, "humidity": hum, "moistureArriving": P["moistureArriving"].astype(float),
          "groundRealM": P["groundElevRealM"].astype(float), "forest": forest.astype(float)}
for name, vals in fields.items():
    cross = []; inside = []
    for k in (1, 3, 4, 6):
        o = nbv[:, k]; q_ = nbv[:, opp[k]]
        sel = edge_cells & (nb[:, k] >= 0) & (fi[o] != fi) & (nb[:, opp[k]] >= 0) & (fi[q_] == fi)
        if name in ("humidity", "forest"): sel &= land & land[o] & land[q_]
        cross.append(np.abs(vals[o][sel] - vals[sel])); inside.append(np.abs(vals[q_][sel] - vals[sel]))
    cross = np.concatenate(cross); inside = np.concatenate(inside)
    Hres[name] = {"meanAbsAcrossSeam": round(float(cross.mean()), 4), "meanAbsInsideFace": round(float(inside.mean()), 4),
                  "ratio": round(float(cross.mean() / max(1e-12, inside.mean())), 3), "pairs": int(len(cross))}
# 이음매 칸의 바이옴 경계 비율 vs 면 안쪽 2~3칸 째
ring1 = edge_cells & land
ring3 = (((ii == 2) | (ii == n - 3)) & (jj > 2) & (jj < n - 3) | ((jj == 2) | (jj == n - 3)) & (ii > 2) & (ii < n - 3)) & land
Hres["biomeEdgeShare"] = {"seamCells": round(float(diff[ring1].mean()), 4), "ring3Cells": round(float(diff[ring3].mean()), 4)}
out["H_faceSeams"] = Hres

# ── K. 지형 단조로움 ──
ge = P["groundElevRealM"].astype(float)
K = {"landElevRealM_pct": {str(p): round(float(np.percentile(ge[land], p)), 0) for p in (10, 25, 50, 75, 90, 99)},
     "landShareAbove1000m": round(float(w[land & (ge > 1000)].sum() / w[land].sum()), 3),
     "landShareAbove2000m": round(float(w[land & (ge > 2000)].sum() / w[land].sum()), 3)}
sl = P["slopeMPerKm"].astype(float); rel = P["reliefRealM"].astype(float)
K["slopeMPerKm_pct"] = {str(p): round(float(np.percentile(sl[land], p)), 2) for p in (10, 50, 90, 99)}
K["relief3x3RealM_pct"] = {str(p): round(float(np.percentile(rel[land], p)), 0) for p in (10, 50, 90, 99)}
# 아무 특징 없는 칸: 강·호수·해안 없음, 5칸 안 같은 바이옴, 3×3 기복 < 100m(실제), 경사 < 5 m/km
same5 = land.copy()
ring = np.arange(N)
for step in range(2):
    nxt = np.zeros(N, bool)
for k in range(8):
    o = nbv[:, k]
    same5 &= (nb[:, k] < 0) | (biome[o] == biome)
plain = land & (P["riverCell"] == 0) & (P["coast"] == 0) & same5 & (rel < 100) & (sl < 5) & (P["distToRiverKm"] > 3 * P.cell_km)
K["featurelessLandShare"] = round(float(w[plain].sum() / w[land].sum()), 3)
out["K_terrain"] = K

# ── L. 바다 ──
L = {"oceanShare": round(float(w[ocean].sum() / w.sum()), 4)}
L["oceanPrecipR2"] = A["precipitation.ocean"]["R2_lat1deg"]; L["oceanTempR2"] = A["temperature.ocean"]["R2_lat1deg"]
# 같은 위도에서 바다 칸 값이 하나뿐인 비율(0.25° 띠 안 강수 표준편차)
s = np.bincount(bi[ocean], weights=Pm[ocean], minlength=len(bins) - 1); c = np.bincount(bi[ocean], minlength=len(bins) - 1)
s2 = np.bincount(bi[ocean], weights=Pm[ocean] ** 2, minlength=len(bins) - 1)
sd = np.sqrt(np.maximum(0, s2 / np.maximum(1, c) - (s / np.maximum(1, c)) ** 2))
L["oceanPrecipWithinBandSd_median_mm"] = round(float(np.median(sd[c > 100])), 1)
openocean = ocean & (P["distToLandKm"] > 1000)
r2o, rmo = area_weighted_r2(Pm, latbin, w, openocean)
L["openOcean(>1000km from land)PrecipR2"] = round(r2o, 5)
out["L_ocean"] = L

# ── M. 강이 만든 바이옴 ──
nw = P["nearWaterBonus"].astype(float)
base_h = np.clip(hum - nw, 0, 255)
Mres = {}
for name, minh in [("tropical_rainforest", 160), ("wetland", 205), ("temperate_forest", 135), ("taiga", 70), ("grassland", 55), ("savanna", 55)]:
    sel = land & (biome == B[name])
    if not sel.any(): continue
    dep = sel & (base_h < minh) & (nw > 0)
    Mres[name] = {"cells": int(sel.sum()), "shareOnlyBecauseOfRiverBonus": round(float(dep.sum() / sel.sum()), 3)}
out["M_riverMadeBiomes"] = Mres
out["seconds"] = round(time.time() - t0, 1)
os.makedirs(os.path.join(BASE, "metrics"), exist_ok=True)
with open(os.path.join(BASE, "metrics", f"core-F{F}-s{SEED}.json"), "w") as fh: json.dump(out, fh, indent=1)
print(json.dumps(out, indent=1))
