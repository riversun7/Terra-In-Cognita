# 경계 방향과 곧음: 면 영상에서 지시 함수를 흐린 뒤 기울기 방향(경계 법선)을 구한다.
# (1) 경계가 위도선과 나란한 비율, (2) 큰 창(33칸)에서 방향 일관성(구조 텐서) — 해안선(노이즈가 만든 경계)과 비교
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import *
F = int(sys.argv[1]) if len(sys.argv) > 1 else 9
SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 20261029
P = load(F, SEED); n = P.n; N = P.N
land = P["land"] == 1; ocean = P["ocean"] == 1
biome = P["biome"].astype(np.int64)
xyz = P.xyz.reshape(6, n, n, 3)
e, nv = tangent_frame(P.xyz); e = e.reshape(6, n, n, 3); nv = nv.reshape(6, n, n, 3)
def box(img, r):
    # 면 하나 안에서 (2r+1)² 상자 평균(가장자리는 있는 칸만)
    pad = np.pad(img, r, mode="constant"); one = np.pad(np.ones_like(img), r, mode="constant")
    cs = pad.cumsum(0).cumsum(1); co = one.cumsum(0).cumsum(1)
    def rect(c):
        c = np.pad(c, ((1, 0), (1, 0)))
        k = 2 * r + 1
        return c[k:, k:] - c[:-k, k:] - c[k:, :-k] + c[:-k, :-k]
    return rect(cs) / np.maximum(1e-9, rect(co))
def grad_dir(img_s, f):
    # 면 f의 흐린 영상 기울기 → 접평면 3차원 벡터 → (동, 북) 성분
    gi = np.zeros_like(img_s); gj = np.zeros_like(img_s)
    gi[:, 1:-1] = (img_s[:, 2:] - img_s[:, :-2]) / 2; gj[1:-1, :] = (img_s[2:, :] - img_s[:-2, :]) / 2
    X = xyz[f]
    a = np.zeros_like(X); b = np.zeros_like(X)
    a[:, 1:-1] = (X[:, 2:] - X[:, :-2]) / 2; b[1:-1, :] = (X[2:, :] - X[:-2, :]) / 2
    aa = (a * a).sum(-1); ab = (a * b).sum(-1); bb = (b * b).sum(-1)
    det = aa * bb - ab * ab; det = np.where(np.abs(det) < 1e-30, 1e-30, det)
    al = (bb * gi - ab * gj) / det; be = (aa * gj - ab * gi) / det
    G = al[..., None] * a + be[..., None] * b
    return (G * e[f]).sum(-1), (G * nv[f]).sum(-1)
R = 3
angles = {}; coh = {}
landimg = land.reshape(6, n, n); bimg = biome.reshape(6, n, n); oimg = ocean.reshape(6, n, n)
def boundary_cells(f, kind):
    if kind == "coast":
        m = landimg[f] & ~np.zeros_like(landimg[f])
        other = oimg[f]
    nbm = np.zeros((n, n), bool)
    return nbm
res = {"F": F, "seed": SEED, "blurRadiusCells": R}
collect = {"coast": [], "biome": [], "temperatureEdges": []}
cohw = {"coast": [], "biome": []}
W = 16
for f in range(6):
    L = landimg[f]; Bm = bimg[f]
    # 해안선: 육지 지시를 흐린 기울기, 해안 칸(바다 이웃이 있는 육지 칸)
    s = box(L.astype(float), R)
    ge, gn = grad_dir(s, f)
    coastc = np.zeros((n, n), bool)
    for dj in (-1, 0, 1):
        for di in (-1, 0, 1):
            if di == 0 and dj == 0: continue
            sh = np.zeros((n, n), bool)
            sh[max(0, -dj):n - max(0, dj), max(0, -di):n - max(0, di)] = oimg[f][max(0, dj):n - max(0, -dj), max(0, di):n - max(0, -di)]
            coastc |= sh
    coastc &= L
    inner = np.zeros((n, n), bool); inner[R + 2:n - R - 2, R + 2:n - R - 2] = True
    sel = coastc & inner & (np.hypot(ge, gn) > 1e-9)
    collect["coast"].append(np.degrees(np.arctan2(np.abs(ge[sel]), np.abs(gn[sel]))))
    th = np.arctan2(gn, ge)
    c2 = np.where(sel, np.cos(2 * th), 0.0); s2 = np.where(sel, np.sin(2 * th), 0.0); wgt = sel.astype(float)
    C = box(c2, W) ; S = box(s2, W); Wt = box(wgt, W)
    cval = np.hypot(C, S) / np.maximum(1e-9, Wt)
    cohw["coast"].append(cval[sel & (Wt * (2 * W + 1) ** 2 > 20)])
    # 바이옴 경계: 자기 바이옴 지시를 흐린 기울기
    bsel_all = np.zeros((n, n), bool); GE = np.zeros((n, n)); GN = np.zeros((n, n))
    for k in np.unique(Bm[L]):
        ind = (Bm == k) & L
        s = box(ind.astype(float), R)
        ge, gn = grad_dir(s, f)
        edge = np.zeros((n, n), bool)
        for dj in (-1, 0, 1):
            for di in (-1, 0, 1):
                if di == 0 and dj == 0: continue
                sh = np.zeros((n, n), bool)
                src = L & (Bm != k)
                sh[max(0, -dj):n - max(0, dj), max(0, -di):n - max(0, di)] = src[max(0, dj):n - max(0, -dj), max(0, di):n - max(0, -di)]
                edge |= sh
        edge &= ind & inner
        GE = np.where(edge, ge, GE); GN = np.where(edge, gn, GN); bsel_all |= edge
    sel = bsel_all & (np.hypot(GE, GN) > 1e-9)
    collect["biome"].append(np.degrees(np.arctan2(np.abs(GE[sel]), np.abs(GN[sel]))))
    th = np.arctan2(GN, GE)
    c2 = np.where(sel, np.cos(2 * th), 0.0); s2 = np.where(sel, np.sin(2 * th), 0.0); wgt = sel.astype(float)
    C = box(c2, W); S = box(s2, W); Wt = box(wgt, W)
    cval = np.hypot(C, S) / np.maximum(1e-9, Wt)
    cohw["biome"].append(cval[sel & (Wt * (2 * W + 1) ** 2 > 20)])
for kname in ("coast", "biome"):
    a = np.concatenate(collect[kname])
    h, _ = np.histogram(a, bins=[0, 10, 20, 30, 40, 50, 60, 70, 80, 90.0001])
    c = np.concatenate(cohw[kname])
    res[kname] = {"cells": int(len(a)), "normalWithin10degOfNS(latitudeParallel)": round(float((a < 10).mean()), 3),
                  "hist10deg": [round(float(x), 3) for x in h / h.sum()],
                  f"coherenceW{2*W+1}_median": round(float(np.median(c)), 3), f"coherenceW{2*W+1}_share>0.8": round(float((c > 0.8).mean()), 3),
                  f"coherenceW{2*W+1}_share>0.9": round(float((c > 0.9).mean()), 3)}
res["isotropicWithin10deg"] = 0.111
json.dump(res, open(os.path.join(BASE, "metrics", f"orientation-F{F}-s{SEED}.json"), "w"), indent=1)
print(json.dumps(res, indent=1))
