# 분석 도우미: 하네스 덤프(.bin)와 격자 내보내기를 numpy로 읽는다(읽기 전용)
import json, os
import numpy as np
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")
R_KM = 6371.0088

class Planet:
    def __init__(self, dump_dir, F):
        self.dir = dump_dir
        m = json.load(open(os.path.join(dump_dir, "manifest.json")))
        self.meta = m["meta"]
        self.specs = {f["name"]: f for f in m["fields"]}
        self._cache = {}
        g = os.path.join(BASE, f"grid-F{F}")
        info = json.load(open(os.path.join(g, "info.json")))
        self.F, self.n, self.N = F, info["n"], info["cellCount"]
        self.W, self.H = info["width"], info["height"]
        self.nb = np.fromfile(os.path.join(g, "nbr8.bin"), dtype="<i4").reshape(-1, 8)
        self.xyz = np.fromfile(os.path.join(g, "xyz.bin"), dtype="<f8").reshape(-1, 3)
        self.pix = np.fromfile(os.path.join(g, "equirect-cell.bin"), dtype="<i4").reshape(self.H, self.W)
        self.biomes = self.meta["biomeIds"]
        self.colors = self.meta["biomeColors"]
        self.cell_km = info["meanCellAngle"] * R_KM
    def __getitem__(self, name):
        if name not in self._cache:
            s = self.specs[name]
            dt = {"uint8": "u1", "int8": "i1", "uint16": "<u2", "int16": "<i2", "int32": "<i4", "uint32": "<u4",
                  "float32": "<f4", "float64": "<f8"}[s["dtype"]]
            self._cache[name] = np.fromfile(os.path.join(self.dir, s["file"]), dtype=dt)
        return self._cache[name]
    def B(self, bid):
        return self.biomes.index(bid)

def load(F=9, seed=20261029):
    return Planet(os.path.join(BASE, f"dump-F{F}-s{seed}"), F)

def chord_km(P, a, b):
    d = P.xyz[a] - P.xyz[b]
    return np.sqrt((d * d).sum(-1)) * R_KM

# ── 공용 계산 ──
def components(P, mask, key=None, max_iter=5000):
    """8이웃(면 넘어감) 연결 성분. mask인 칸만, key가 같은 이웃끼리 잇는다. 반환: 칸마다 성분 대표(가장 작은 칸 번호), 아니면 -1"""
    N = P.N
    nb = P.nb
    if key is None: key = np.zeros(N, dtype=np.int32)
    lab = np.where(mask, np.arange(N, dtype=np.int64), -1)
    edges = []
    for k in range(8):
        o = nb[:, k]
        ok = mask & (o >= 0)
        oo = np.where(ok, o, 0)
        ok &= mask[oo] & (key[oo] == key)
        edges.append((np.nonzero(ok)[0], o[ok]))
    for it in range(max_iter):
        new = lab.copy()
        for a, b in edges:
            np.minimum.at(new, a, lab[b]) if False else None
            cand = lab[b]
            cur = new[a]
            better = cand < cur
            if better.any():
                # 같은 a가 여러 번 나오지 않는다(방향마다 한 번)
                new[a[better]] = cand[better]
        m = new >= 0
        new[m] = new[new[m]]
        new[m] = new[new[m]]
        if np.array_equal(new, lab): break
        lab = new
    return lab

def comp_sizes(lab, weights=None):
    m = lab >= 0
    ids, inv, counts = np.unique(lab[m], return_inverse=True, return_counts=True)
    if weights is not None:
        w = np.bincount(inv, weights=weights[m])
        return ids, counts, w
    return ids, counts, counts.astype(float)

def tangent_frame(xyz):
    """칸마다 동쪽·북쪽 단위 벡터"""
    x, y, z = xyz[:, 0], xyz[:, 1], xyz[:, 2]
    h = np.sqrt(x * x + y * y); h = np.where(h < 1e-12, 1e-12, h)
    e = np.stack([-y / h, x / h, np.zeros_like(x)], -1)
    nvec = np.cross(xyz, e)
    return e, nvec

def area_weighted_r2(values, groups, weights, mask):
    v = values[mask].astype(np.float64); g = groups[mask]; w = weights[mask].astype(np.float64)
    mean = (v * w).sum() / w.sum()
    sst = (w * (v - mean) ** 2).sum()
    gs = np.bincount(g, weights=w); gm = np.bincount(g, weights=w * v) / np.where(gs > 0, gs, 1)
    ssw = (w * (v - gm[g]) ** 2).sum()
    return 1 - ssw / sst if sst > 0 else float("nan"), float(np.sqrt(ssw / w.sum()))

def mutual_info(a, b, w):
    """가중 상호정보량 I(a;b)와 H(a) (비트)"""
    a = a.astype(np.int64); b = b.astype(np.int64)
    na, nbins = a.max() + 1, b.max() + 1
    joint = np.bincount(a * nbins + b, weights=w, minlength=na * nbins).reshape(na, nbins)
    joint /= joint.sum()
    pa = joint.sum(1); pb = joint.sum(0)
    nz = joint > 0
    I = (joint[nz] * np.log2(joint[nz] / (pa[:, None] * pb[None, :])[nz])).sum()
    Ha = -(pa[pa > 0] * np.log2(pa[pa > 0])).sum()
    return float(I), float(Ha)
