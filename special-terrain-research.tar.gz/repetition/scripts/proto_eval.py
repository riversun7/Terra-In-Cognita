# 시제품 평가: v1(생성기 재현) vs v2(이웃 2칸 보간 + 흔든 띠 경계) — 습도·바이옴을 같은 규칙으로 다시 판정해 지표·그림 비교
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from PIL import Image
from plib import *
F = int(sys.argv[1]) if len(sys.argv) > 1 else 9
SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 20261029
P = load(F, SEED); N = P.N; n = P.n
land = P["land"] == 1; lake = P["lake"] == 1; ocean = P["ocean"] == 1
Tr = P["temperatureC"].astype(float); nw = P["nearWaterBonus"].astype(float); elevR = P["realElevationM"].astype(float)
rules = {r["id"]: r["rule"] for r in json.load(open("/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/inventory-harness/snapshot-f59a8a7/content/core/biomes.json"))["entries"]}
land_list = [(P.biomes.index(b), rules[b]) for b in P.biomes if rules[b]["kind"] == "land"]
def classify(t, hh, e):
    outb = np.full(len(t), land_list[-1][0]); done = np.zeros(len(t), bool)
    for idx, r in land_list:
        m = ~done
        for key, val in (("temperatureC", t), ("humidity", hh), ("realElevationM", e)):
            rg = r.get(key)
            if rg is None: continue
            if "min" in rg: m &= val >= rg["min"]
            if "max" in rg: m &= val < rg["max"]
        outb[m] = idx; done |= m
    return outb
def surface(Pm):
    pet = np.maximum(80, 45 * (Tr + 6)); ai = np.round(Pm) / pet
    hum = np.clip(np.round(255 * ai / (ai + 0.75) + nw), 0, 255)
    b = P["biome"].astype(np.int64).copy()
    L = np.nonzero(land)[0]
    b[L] = classify(Tr[L], hum[L], elevR[L])
    return hum, b
A1 = np.load(os.path.join(BASE, f"proto-F{F}-s{SEED}-A1.npy")).astype(float); A2 = np.load(os.path.join(BASE, f"proto-F{F}-s{SEED}-A2.npy")).astype(float)
P1 = np.load(os.path.join(BASE, f"proto-F{F}-s{SEED}-P1.npy")).astype(float); P2 = np.load(os.path.join(BASE, f"proto-F{F}-s{SEED}-P2.npy")).astype(float)
h1, b1 = surface(P1); h2, b2 = surface(P2)
res = {"F": F, "seed": SEED, "v1BiomeReplicaMatchesGenerator": float((b1 == P["biome"]).mean())}
w = P["cellAreaKm2"].astype(float); lat = P["latitudeDeg"].astype(float)
latbin = np.clip(np.floor(lat + 90).astype(np.int64), 0, 179)
fi = P["face"].astype(np.int64); ii = P["i"].astype(np.int64); jj = P["j"].astype(np.int64)
up = P["upwindCell"].astype(np.int64)
def aniso(field, k=3):
    di = ii[up] - ii; dj = jj[up] - jj
    ok = (up != np.arange(N)) & (fi[up] == fi) & (np.abs(di) <= 1) & (np.abs(dj) <= 1) & land
    pi_, pj_ = -dj, di
    def at(a, b):
        ia = ii + a; jb = jj + b
        inside = (ia >= 0) & (ia < n) & (jb >= 0) & (jb < n)
        return fi * n * n + np.clip(jb, 0, n - 1) * n + np.clip(ia, 0, n - 1), inside
    c1, o1 = at(k * pi_, k * pj_); c2, o2 = at(-k * pi_, -k * pj_); a1, o3 = at(k * di, k * dj); a2, o4 = at(-k * di, -k * dj)
    sel = ok & o1 & o2 & o3 & o4 & land[c1] & land[c2] & land[a1] & land[a2]
    return float(np.abs(field[c1] - field[c2])[sel].mean() / np.abs(field[a1] - field[a2])[sel].mean())
nb = P.nb; nbv = np.where(nb >= 0, nb, 0)
def edge(b):
    d = np.zeros(N, bool)
    for k in range(8):
        o = nbv[:, k]; d |= (nb[:, k] >= 0) & land[o] & (b[o] != b)
    return d & land
alat = np.abs(lat)
A3 = np.load(os.path.join(BASE, f"proto-F{F}-s{SEED}-A3.npy")).astype(float); P3 = np.load(os.path.join(BASE, f"proto-F{F}-s{SEED}-P3.npy")).astype(float); h3, b3 = surface(P3)
for name, A, Pm, hh, bb in (("v1", A1, P1, h1, b1), ("v2", A2, P2, h2, b2), ("v3", A3, P3, h3, b3)):
    d = edge(bb)
    I, H = mutual_info(bb[land], latbin[land], w[land])
    r2, _ = area_weighted_r2(Pm, latbin, w, land)
    r2o, _ = area_weighted_r2(Pm, latbin, w, ocean & (P["distToLandKm"] > 1000))
    shares = {P.biomes[k]: round(float(w[land & (bb == k)].sum() / w[land].sum()), 3) for k in range(len(P.biomes)) if (land & (bb == k)).any()}
    res[name] = {"moistureCrossAlong_k3": round(aniso(A), 2), "humidityCrossAlong_k3": round(aniso(hh), 2),
                 "edgeDensity_29-31": round(float(d[land & (alat >= 29) & (alat < 31)].mean()), 4), "edgeDensity_allLand": round(float(d[land].mean()), 4),
                 "biomeInfoExplainedByLat": round(I / H, 3), "landPrecipR2lat": round(r2, 3), "openOceanPrecipR2lat": round(r2o, 4),
                 "landHumidityMedian": float(np.median(hh[land])), "shares": shares}
json.dump(res, open(os.path.join(BASE, "metrics", f"proto-F{F}-s{SEED}.json"), "w"), indent=1)
print(json.dumps(res, indent=1))
# 그림: 중앙 사막 잘라내기(등장방형 화소 960~1300, 260~620) v1 / v2 바이옴
cols = np.array([[int(c[1:3], 16), int(c[3:5], 16), int(c[5:7], 16)] for c in P.colors], dtype=np.uint8)
def render(bb, x0, y0, x1, y1, scale, path):
    cells = P.pix[y0:y1, x0:x1]
    img = cols[bb[cells]]
    Image.fromarray(img).resize(((x1 - x0) * scale, (y1 - y0) * scale), Image.NEAREST).save(path)
os.makedirs(os.path.join(BASE, "..", "img"), exist_ok=True)
render(b1, 960, 260, 1300, 620, 2, os.path.join(BASE, "..", "img", "proto-desert-v1-biome.png"))
render(b2, 960, 260, 1300, 620, 2, os.path.join(BASE, "..", "img", "proto-desert-v2-biome.png"))
render(b1, 0, 0, P.W, P.H, 1, os.path.join(BASE, "..", "img", "proto-full-v1-biome.png"))
render(b2, 0, 0, P.W, P.H, 1, os.path.join(BASE, "..", "img", "proto-full-v2-biome.png"))
render(b3, 960, 260, 1300, 620, 2, os.path.join(BASE, "..", "img", "proto-desert-v3-biome.png"))
render(b3, 0, 0, P.W, P.H, 1, os.path.join(BASE, "..", "img", "proto-full-v3-biome.png"))
