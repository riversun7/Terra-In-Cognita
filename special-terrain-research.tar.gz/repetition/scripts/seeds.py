# 시드끼리 얼마나 닮았나: 위도 띠별 바이옴 분포(JS 발산), 대륙 수·크기, 해안 복잡도, 위도 띠 우세 바이옴 비율
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import *
F = int(sys.argv[1]) if len(sys.argv) > 1 else 9
seeds = [20261029, 1, 42]
def js(p, q):
    p = p / p.sum(); q = q / q.sum(); m = (p + q) / 2
    def kl(a, b):
        nz = a > 0
        return (a[nz] * np.log2(a[nz] / b[nz])).sum()
    return 0.5 * kl(p, m) + 0.5 * kl(q, m)
data = {}
for s in seeds:
    P = load(F, s)
    land = P["land"] == 1; w = P["cellAreaKm2"].astype(float)
    alat = np.abs(P["latitudeDeg"].astype(float))
    band = np.minimum(17, (alat // 5).astype(int))
    nbio = len(P.biomes)
    cond = np.zeros((18, nbio))
    np.add.at(cond, (band[land], P["biome"][land]), w[land])
    # 1° 띠마다 우세 바이옴 비율(육지 넓이 가중)
    b1 = np.minimum(89, alat.astype(int))
    dom = np.zeros((90, nbio)); np.add.at(dom, (b1[land], P["biome"][land]), w[land])
    tot = dom.sum(1)
    dominance = np.where(tot > 0, dom.max(1) / np.maximum(tot, 1e-9), np.nan)
    landw = tot / tot.sum()
    # 대륙: 육지(바다 아닌 칸) 연결 성분
    nonocean = P["ocean"] == 0
    lab = components(P, nonocean)
    ids, counts, area = comp_sizes(lab, w)
    totland = w[nonocean].sum()
    big = area > 0.005 * w.sum()
    data[s] = {"cond": cond, "share": cond.sum(0) / cond.sum(), "dominance": dominance, "landw": landw,
               "continents(>0.5% of planet)": int(big.sum()), "largestLandmassShareOfLand": round(float(area.max() / totland), 3),
               "islands(<0.01% planet)": int((area < 1e-4 * w.sum()).sum()),
               "coastCellsPerLandCell": round(float((P["coast"] == 1).sum() / nonocean.sum()), 4),
               "dominance_landWeighted": round(float(np.nansum(dominance * landw)), 3),
               "biomes": P.biomes}
out = {"F": F}
pairs = [(seeds[0], seeds[1]), (seeds[0], seeds[2]), (seeds[1], seeds[2])]
# 시드 사이: 같은 위도 띠의 바이옴 분포 JS (띠 육지 넓이 가중)
js_between = {}
for a, b in pairs:
    ca, cb = data[a]["cond"], data[b]["cond"]
    wts = (ca.sum(1) + cb.sum(1)); vals = []
    for k in range(18):
        if ca[k].sum() > 0 and cb[k].sum() > 0: vals.append((js(ca[k] + 1e-12, cb[k] + 1e-12), wts[k]))
    v = np.array(vals)
    js_between[f"{a}-{b}"] = round(float((v[:, 0] * v[:, 1]).sum() / v[:, 1].sum()), 3)
out["JS_sameLatBand_betweenSeeds(bits)"] = js_between
# 기준: 같은 시드 안에서 이웃 띠(5° 차이) 사이 JS
js_adj = {}
for s in seeds:
    c = data[s]["cond"]; vals = []
    for k in range(17):
        if c[k].sum() > 0 and c[k + 1].sum() > 0: vals.append((js(c[k] + 1e-12, c[k + 1] + 1e-12), c[k].sum() + c[k + 1].sum()))
    v = np.array(vals); js_adj[str(s)] = round(float((v[:, 0] * v[:, 1]).sum() / v[:, 1].sum()), 3)
out["JS_adjacent5degBands_sameSeed(bits)"] = js_adj
out["JS_globalBiomeShares_betweenSeeds(bits)"] = {f"{a}-{b}": round(float(js(data[a]["share"] + 1e-12, data[b]["share"] + 1e-12)), 4) for a, b in pairs}
for s in seeds:
    d = data[s]
    out[str(s)] = {k: d[k] for k in ("continents(>0.5% of planet)", "largestLandmassShareOfLand", "islands(<0.01% planet)", "coastCellsPerLandCell", "dominance_landWeighted")}
    # 위도 띠별 우세 바이옴(10° 묶음)
    prof = []
    c = d["cond"]
    for k in range(0, 18, 2):
        row = c[k] + c[k + 1]
        if row.sum() == 0: prof.append(None); continue
        top = int(row.argmax()); prof.append(f"{k*5}-{k*5+10}: {d['biomes'][top]} {row[top]/row.sum():.2f}")
    out[str(s)]["dominantBiomeBy10deg"] = prof
json.dump(out, open(os.path.join(BASE, "metrics", f"seeds-F{F}.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
