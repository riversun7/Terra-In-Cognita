# 점 배치 검사 예: 덩어리 중심의 최근접 거리와 Clark–Evans 비 R(무작위 1, 뭉침 < 1, 고른 간격 > 1) — 육지 넓이 기준
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import *
def centroids(P, mask):
    lab = components(P, mask)
    ids, counts, _ = comp_sizes(lab)
    m = lab >= 0
    inv = np.searchsorted(ids, lab[m])
    s = np.zeros((len(ids), 3)); np.add.at(s, inv, P.xyz[m])
    s /= np.linalg.norm(s, axis=1, keepdims=True)
    return s, counts
def clark_evans(pts, area_km2):
    if len(pts) < 3: return None
    dots = pts @ pts.T; np.fill_diagonal(dots, -2)
    nn = np.arccos(np.clip(dots.max(1), -1, 1)) * R_KM
    expect = 0.5 / np.sqrt(len(pts) / area_km2)
    return {"n": int(len(pts)), "nnMedianKm": round(float(np.median(nn))), "R": round(float(nn.mean() / expect), 2)}
out = {}
for seed in (20261029, 1, 42):
    P = load(9, seed); land = P["land"] == 1
    area = float(P["cellAreaKm2"][land | (P["lake"] == 1)].sum())
    r = {}
    for name, mask in {"dryBasin(playa)": P["basinKind"] == 3, "lake": P["lake"] == 1,
                       "hotspotCone>500m": P["hotspotRealM"] > 500, "riverMouth": P["riverMouth"] == 1}.items():
        pts, counts = centroids(P, mask)
        r[name] = clark_evans(pts, area)
    out[str(seed)] = r
    print(seed, json.dumps(r))
json.dump(out, open(os.path.join(BASE, "metrics", "spacing-F9.json"), "w"), indent=1)
