# 비그늘 줄무늬(먼 거리 그림자) 전 행성 통계: 칸마다 바람길을 거슬러 가며 습기를 가장 많이 깎은 오르막이 얼마나 먼지
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import *
F = int(sys.argv[1]) if len(sys.argv) > 1 else 9
SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 20261029
P = load(F, SEED)
N = P.N
up = P["upwindCell"].astype(np.int64)
ocean = P["ocean"] == 1; land = P["land"] == 1
h = np.maximum(0.0, P["preErosionElevRealM"].astype(np.float64))  # 기후는 침식 전 고도(해수면 0)
step_km = chord_km(P, np.arange(N), up)
# 칸 c에서 나가는 습기에 대한 오르막(climate.ts 150~157): 땅 칸만, climb = max(0, here - there)
climb = np.where(ocean, 0.0, np.maximum(0.0, h - h[up]))
m = P["moistureArriving"].astype(np.float64); m0 = P["moistureArrivingNoOro"].astype(np.float64)
deficit = np.where(m0 > 0.02, 1 - m / m0, 0.0)
# 바람길을 따라 4500km까지: 첫 바다 전까지의 누적 오르막과, 가장 큰 오르막(1칸 단위가 아니라 300km 창으로 합친 언덕) 위치
cur = np.arange(N); dist = np.zeros(N); cum = np.zeros(N); best = np.zeros(N); best_d = np.zeros(N)
alive = land.copy()
# 언덕 하나를 거의 같은 거리에서 모아 보려고, 각 단계에서 지나온 칸의 오르막을 거리 상자(150km)별로 더한다
BOX = 150.0
nbox = int(4500 / BOX) + 1
boxes = np.zeros((N, nbox), dtype=np.float32) if F <= 8 else None
if boxes is None:
    landidx = np.nonzero(land)[0]
    boxes = np.zeros((len(landidx), nbox), dtype=np.float32)
    pos = np.full(N, -1); pos[landidx] = np.arange(len(landidx))
for k in range(2000):
    if not alive.any(): break
    a = np.nonzero(alive)[0]
    c = cur[a]
    # 바다에 닿으면 멈춘다(바다가 습기를 다시 채운다)
    stop = ocean[c] | (up[c] == c) | (dist[a] > 4500)
    go = a[~stop]; cg = cur[go]
    bi = np.minimum(nbox - 1, (dist[go] / BOX).astype(np.int64))
    boxes[pos[go] if F > 8 else go, bi] += climb[cg].astype(np.float32)
    cum[go] += climb[cg]
    dist[go] += step_km[cg]
    cur[go] = up[cg]
    alive[a[stop]] = False
rows = pos[land] if F > 8 else np.nonzero(land)[0]
bx = boxes[rows]
top_box = bx.argmax(1); top_climb = bx.max(1)
top_dist = (top_box + 0.5) * BOX
L = np.nonzero(land)[0]
d = deficit[L]
res = {"F": F, "seed": SEED}
for thr in (0.3, 0.5, 0.8):
    sel = d > thr
    res[f"landShareDeficit>{thr}"] = round(float(sel.mean()), 4)
    for far in (300, 600, 1000, 1500):
        res[f"  ...andMainClimb>{far}kmUpwind"] = res.get(f"  ...andMainClimb>{far}kmUpwind", {})
        res[f"  ...andMainClimb>{far}kmUpwind"][str(thr)] = round(float((sel & (top_dist > far)).mean()), 4)
# 줄무늬 덩어리: 결손 > 0.5 이고 주 오르막이 600km 넘게 먼 칸들의 연결 성분 → 길이·폭(접평면 PCA)
mask = np.zeros(N, bool); mask[L[(d > 0.5) & (top_dist > 600)]] = True
lab = components(P, mask)
ids, counts, _ = comp_sizes(lab)
big = ids[counts >= 50]
shapes = []
for r in big:
    cells = np.nonzero(lab == r)[0]
    X = P.xyz[cells]; c0 = X.mean(0); c0 /= np.linalg.norm(c0)
    e_, n_ = tangent_frame(c0[None, :]); e_, n_ = e_[0], n_[0]
    Y = np.stack([(X - c0) @ e_, (X - c0) @ n_], 1) * R_KM
    cov = np.cov(Y.T); ev, evec = np.linalg.eigh(cov)
    length = 4 * np.sqrt(max(ev[1], 1e-9)); width = 4 * np.sqrt(max(ev[0], 1e-9))
    ax = evec[:, 1]; azim = float(np.degrees(np.arctan2(ax[1], ax[0]))) % 180
    # 바람길 방향(칸 → 바람이 오는 칸) 평균
    dd = P.xyz[up[cells]] - P.xyz[cells]
    wv = np.stack([dd @ e_, dd @ n_], 1); wv /= np.maximum(1e-12, np.linalg.norm(wv, axis=1, keepdims=True))
    wa = float(np.degrees(np.arctan2(wv[:, 1].mean(), wv[:, 0].mean()))) % 180
    shapes.append({"cells": int(len(cells)), "lat": round(float(P["latitudeDeg"][cells].mean()), 1), "lon": round(float(P["longitudeDeg"][cells].mean()), 1),
                   "lengthKm": round(float(length)), "widthKm": round(float(width)), "aspect": round(float(length / width), 1),
                   "axisAzimuth": round(azim, 1), "windAxisAzimuth": round(wa, 1), "meanDeficit": round(float(deficit[cells].mean()), 2),
                   "meanMainClimbDistKm": round(float(top_dist[np.searchsorted(L, cells)].mean()))})
shapes.sort(key=lambda s: -s["cells"])
res["farShadowStreaks(>=50 cells)"] = shapes[:15]
res["farShadowStreakCount"] = len(shapes)
res["farShadowStreakLandShare"] = round(float(mask.sum() / land.sum()), 4)
os.makedirs(os.path.join(BASE, "metrics"), exist_ok=True)
json.dump(res, open(os.path.join(BASE, "metrics", f"streaks-F{F}-s{SEED}.json"), "w"), indent=1)
print(json.dumps(res, indent=1))
