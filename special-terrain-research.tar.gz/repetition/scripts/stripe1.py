# 줄무늬 진단 1: 등장방형 화소 좌표로 칸을 찾고, 가로지르는 선(경도 고정) 위의 값들을 본다
import sys; sys.path.insert(0, __import__("os").path.dirname(__file__))
import numpy as np
from plib import load
P = load(9)
def cell_at(px, py): return int(P.pix[py, px])
def lonlat(px, py): return ((px + 0.5) / P.W * 360 - 180, 90 - (py + 0.5) / P.H * 180)
# 줄무늬를 가로지르는 남북 선: 화소 x = 1200 (경도), y = 300 ~ 480
names = ["biome", "temperatureC", "humidity", "precipitationMm", "moistureArriving", "moistureArrivingNoOro", "moistureCoastal", "rainShadow", "leeRidgeRealM", "realElevationM", "distToOceanKm", "upwindCell", "basinKind", "face"]
px = int(sys.argv[1]) if len(sys.argv) > 1 else 1200
print("px", px, "lon", round(lonlat(px, 0)[0], 2))
prev = None
for py in range(300, 470, 3):
    c = cell_at(px, py)
    if c == prev: continue
    prev = c
    lat = P["latitudeDeg"][c]
    row = [f"py{py} lat{lat:6.2f} c{c}"]
    for nm in names:
        v = P[nm][c]
        if nm == "biome": row.append(f"{P.biomes[v][:10]:10s}")
        elif isinstance(v, (np.floating,)): row.append(f"{nm[:8]}={v:.3f}")
        else: row.append(f"{nm[:8]}={v}")
    print(" ".join(row))
