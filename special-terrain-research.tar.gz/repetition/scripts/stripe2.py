# 줄무늬 진단 2: 칸에서 바람이 오는 쪽(upwindCell)을 따라가며 바다·오르막·습기를 적는다
import sys, os; sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import load, chord_km
P = load(9)
up = P["upwindCell"]; ocean = P["ocean"]; elev = P["preErosionElevRealM"]  # 기후는 침식 전 고도로 계산(해수면 0 기준)
lat = P["latitudeDeg"]; lon = P["longitudeDeg"]
def trace(c, maxkm=4600):
    path = [c]; km = 0.0
    while True:
        u = int(up[path[-1]])
        if u == path[-1] or km > maxkm: break
        km += float(chord_km(P, path[-1], u)); path.append(u)
    return path, km
def summarize(c):
    path, km = trace(c)
    # 생성기 식(climate.ts 145~158): 땅 칸 오르막 = max(0, max(sea, h_here) - max(sea, h_from))
    climb_total = 0.0; first_ocean = None; land_km = 0.0; tops = []
    for k in range(len(path) - 1):
        a, b = path[k], path[k + 1]
        if ocean[a] == 1:
            if first_ocean is None: first_ocean = k
            continue
        if first_ocean is not None: continue  # 바다를 만난 뒤는 바다에서 습기가 다시 찬다(먼 쪽은 무시)
        here = max(0.0, float(elev[a])); there = max(0.0, float(elev[b]))
        climb_total += max(0.0, here - there)
        land_km += float(chord_km(P, a, b))
        tops.append(here)
    end = path[-1]
    return dict(cell=c, lat=float(lat[c]), lon=float(lon[c]), steps=len(path) - 1, km=round(km),
                firstOceanStep=first_ocean, landKmBeforeOcean=round(land_km), climbBeforeOceanM=round(climb_total),
                maxGroundBeforeOcean=round(max(tops) if tops else 0), oroFactor=round(float(np.exp(-1.1 * climb_total / 1000)), 4),
                end=end, endCalm=bool(up[end] == end), endOcean=int(ocean[end]),
                mArr=round(float(P["moistureArriving"][c]), 3), mNoOro=round(float(P["moistureArrivingNoOro"][c]), 3),
                biome=P.biomes[P["biome"][c]])
px = 1200
prev = None
for py in range(355, 420, 2):
    c = int(P.pix[py, px])
    if c == prev: continue
    prev = c
    s = summarize(c)
    print(s)
