# 줄무늬 진단 3: 마른 줄무늬 칸의 바람길에서 가장 높은 칸이 무엇인지(열점·섬 호·안데스 화산) 본다
import sys, os; sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import load, chord_km
P = load(9)
up = P["upwindCell"]; ocean = P["ocean"]; elev = P["preErosionElevRealM"]
lat = P["latitudeDeg"]; lon = P["longitudeDeg"]
for c in [197552, 196528, 193968, 190384, 214448]:
    path = [c]
    while int(up[path[-1]]) != path[-1] and len(path) < 400: path.append(int(up[path[-1]]))
    hs = [max(0.0, float(elev[x])) if ocean[x] == 0 else -1 for x in path]
    k = int(np.argmax(hs)); top = path[k]
    km = sum(float(chord_km(P, path[t], path[t + 1])) for t in range(k))
    print(f"cell {c} lat {lat[c]:.2f} lon {lon[c]:.2f} -> top cell {top} at {km:.0f} km upwind: lat {lat[top]:.2f} lon {lon[top]:.2f} ground {hs[k]:.0f} m "
          f"hotspot {P['hotspotRealM'][top]:.0f} arc {P['islandArcRealM'][top]:.0f} andeanVolc {P['andeanVolcanicRealM'][top]:.0f} andean {P['andeanRealM'][top]:.0f} collision {P['collisionRealM'][top]:.0f} "
          f"hotspotId {P['hotspotId'][top]} step {P['hotspotStep'][top]} nearestKm {P['hotspotNearestKm'][top]:.0f} continental {P['continental'][top]} ocean {ocean[top]}")
    # 바람길 방향: 칸 → 바람이 오는 칸의 방위(동쪽 기준 반시계, 도)
    a = c; b = int(up[c])
    p = P.xyz[a]; d = P.xyz[b] - p
    e = np.array([-p[1], p[0], 0.0]); e /= np.linalg.norm(e); nvec = np.cross(p, e)
    az = np.degrees(np.arctan2(d @ nvec, d @ e))
    u, v = float(P["windU"][a]), float(P["windV"][a])
    true_az = np.degrees(np.arctan2(-v, -u))
    print(f"   chain azimuth {az:.1f} deg (from east, CCW); true upwind azimuth {true_az:.1f}; error {az - true_az:.1f}; face {P['face'][a]} i {P['i'][a]} j {P['j'][a]}")
