# 줄무늬 원인 그림: 강수 지도(F9) 중앙 사막 위에 마른 줄무늬 칸·젖은 띠 칸의 바람길(바람이 오는 쪽)과 6.8km 봉우리를 그린다
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from PIL import Image, ImageDraw
from plib import *
P = load(9)
up = P["upwindCell"]; lat = P["latitudeDeg"]; lon = P["longitudeDeg"]
S = "/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/s2-gen/final-f9/equirect-precipitation.png"
im = Image.open(S).convert("RGB")
x0, y0, x1, y1, sc = 960, 260, 1300, 620, 3
im = im.crop((x0, y0, x1, y1)).resize(((x1 - x0) * sc, (y1 - y0) * sc), Image.NEAREST)
dr = ImageDraw.Draw(im)
def px(c):
    X = (lon[c] + 180) / 360 * P.W - 0.5; Y = (90 - lat[c]) / 180 * P.H - 0.5
    return ((X - x0 + 0.5) * sc, (Y - y0 + 0.5) * sc)
def chain(c, color, maxsteps=200):
    pts = [px(c)]; cur = c
    for _ in range(maxsteps):
        n2 = int(up[cur])
        if n2 == cur: break
        cur = n2; pts.append(px(cur))
    dr.line(pts, fill=color, width=3)
    r = 7; x, y = pts[0]; dr.ellipse((x - r, y - r, x + r, y + r), outline=color, width=3)
chain(193968, (200, 0, 0))     # 마른 줄무늬(18.7°N 31°E): 1,681km 위쪽 6,805m 봉우리를 지난다
chain(214448, (0, 0, 200))     # 젖은 띠(25.0°N 31°E): 640~1,430km 위쪽 안쪽 바다를 지난다
chain(227760, (120, 0, 160))   # 무풍대(29.2°N): 바람이 오는 칸 = 자기 자신
x, y = px(234495); r = 10
dr.ellipse((x - r, y - r, x + r, y + r), outline=(255, 255, 255), width=4)
im.save(os.path.join(BASE, "..", "img", "stripe-cause-overlay.png"))
print("saved")
