# 습도 계단: 증발 가능량을 반올림한 기온으로 계산해서(surface.ts 186) 정수 등온선마다 습도가 뛴다 — 크기와 바이옴 영향
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from plib import *
P = load(9)
land = P["land"] == 1
T = P["temperatureExactC"].astype(float); Tr = P["temperatureC"].astype(float)
p = P["precipitationExactMm"].astype(float); nw = P["nearWaterBonus"].astype(float)
pet = lambda t: np.maximum(80, 45 * (t + 6))
def hum(t):
    ai = p / pet(t)
    return np.clip(np.round(255 * ai / (ai + 0.75) + nw), 0, 255)
h_round = hum(Tr); h_exact = hum(T)
assert (h_round[land] == P["humidity"][land]).all(), "humidity replica mismatch"
d = (h_round - h_exact)[land]
res = {"replicaMatchesStoredHumidity": True,
       "absDiff_mean": round(float(np.abs(d).mean()), 2), "absDiff_p90": round(float(np.percentile(np.abs(d), 90)), 1),
       "absDiff_max": float(np.abs(d).max()), "share|diff|>=5": round(float((np.abs(d) >= 5).mean()), 3)}
# 이웃 사이 습도 차이: 반올림 기온이 다른 이웃 쌍 vs 같은 이웃 쌍
nb = P.nb; nbv = np.where(nb >= 0, nb, 0)
same, cross = [], []
for k in (1, 3, 4, 6):
    o = nbv[:, k]; okk = (nb[:, k] >= 0) & land & land[o] & (P["riverCell"] == 0) & (P["riverCell"][o] == 0) & (nw == 0) & (nw[o] == 0)
    diffT = Tr[o] != Tr
    dh = np.abs(P["humidity"][o].astype(float) - P["humidity"].astype(float))
    cross.append(dh[okk & diffT]); same.append(dh[okk & ~diffT])
cross = np.concatenate(cross); same = np.concatenate(same)
res["neighbourHumidityStep"] = {"acrossIntegerIsotherm_mean": round(float(cross.mean()), 2), "sameRoundedT_mean": round(float(same.mean()), 2),
                                "acrossIntegerIsotherm_p90": float(np.percentile(cross, 90)), "sameRoundedT_p90": float(np.percentile(same, 90))}
# 바이옴이 바뀌는 칸: 정확한 기온으로 습도를 냈다면 다른 바이옴이었을 칸
rules = json.load(open("/home/user/terra-in-cognita/.claude/worktrees/wf_855dd1b7-352-1/content/core/biomes.json"))["entries"]
land_rules = [(P.biomes.index(r["id"]), r["rule"]) for r in rules if r["rule"]["kind"] == "land" and r["id"] in P.biomes]
order = [P.biomes.index(b) for b in P.biomes]
ruleby = {r["id"]: r["rule"] for r in rules}
land_list = [(P.biomes.index(b), ruleby[b]) for b in P.biomes if ruleby[b]["kind"] == "land"]
def classify(t, h, e):
    outb = np.full(len(t), land_list[-1][0])
    done = np.zeros(len(t), bool)
    for idx, r in land_list:
        m = ~done
        for key, val in (("temperatureC", t), ("humidity", h), ("realElevationM", e)):
            rg = r.get(key)
            if rg is None: continue
            if "min" in rg: m &= val >= rg["min"]
            if "max" in rg: m &= val < rg["max"]
        outb[m] = idx; done |= m
    return outb
L = np.nonzero(land)[0]
b1 = classify(Tr[L], h_round[L], P["realElevationM"][L].astype(float))
assert (b1 == P["biome"][L]).all(), "biome replica mismatch"
b2 = classify(Tr[L], h_exact[L], P["realElevationM"][L].astype(float))
res["landShareBiomeChangedByRoundedPET"] = round(float((b1 != b2).mean()), 4)
json.dump(res, open(os.path.join(BASE, "metrics", "terraces-F9.json"), "w"), indent=1)
print(json.dumps(res, indent=1))
