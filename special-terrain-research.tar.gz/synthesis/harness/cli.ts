// 특수 지형 조건 분석 하네스 (읽기 전용, 스크래치) — S2 행성 생성기를 단계별로 돌려 칸별 배열을 만들고 조건을 평가한다.
//
// 실행 (Node 24, .ts를 바로 실행):
//   export PATH=/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/node24/node-v24.22.1-linux-x64/bin:$PATH
//   H=/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/inventory-harness
//   node $H/cli.ts --verify-only                      # 해시·복제본 대조만 (팩 시드는 F7 10330ff7이어야 한다)
//   node $H/cli.ts --baseline                         # 바이옴 비율·값 범위 (시드: 팩 + 1 + 42)
//   node $H/cli.ts --fields                           # 칸별 배열 목록(이름·자료형·단위·출처)
//   node $H/cli.ts --cond 'warmShallow=ocean && depthClass === DEPTH.COASTAL && temperatureC >= 22' \
//                  --cond 'reefCandidate=warmShallow && dist_riverMouth > 300'
//   node $H/cli.ts --conds $H/conditions.example.ts --json /tmp/out.json
//
// 선택:
//   --root DIR        생성기 루트(기본: 작업 트리 wf_855dd1b7-352-1). 고정 사본: $H/snapshot-f59a8a7
//   --planet ID       content/core/planets.json 행성 ID (기본 s2_test_planet)
//   --face-level F    면 레벨 (기본 7, 4~10)
//   --seeds LIST      쉼표 목록, "pack" = 팩 행성의 시드 (기본 pack,1,42)
//   --cond NAME=EXPR  조건(여러 번). 식 문법은 lib/analyze.ts 머리 주석. 뒤 조건은 앞 조건 이름·adj_·dist_·nbmax_·nbmin_을 쓸 수 있다
//   --conds FILE      `export const conditions = [{ name, expr } | { name, mask(planet, h) }]` 모듈(.ts/.mjs)
//   --show-bands      덩어리 크기 분포·위도 띠를 시드마다 자세히
//   --json FILE       모든 결과를 JSON으로
//   --dump DIR        시드마다 칸별 배열(.bin, little-endian) + manifest.json (numpy: np.fromfile(path, dtype))
//   --no-cache        캐시를 쓰지 않고 다시 생성(캐시: $H/cache, 지문 = 생성기 원본 + 하네스 원본 sha256)
//   --no-verify       새로 생성할 때 공식 runPlanetGenerator 대조를 건너뜀
//   --quiet
import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import {
  type Baseline,
  type ConditionSpec,
  type ConditionStats,
  baselineOf,
  conditionStats,
  evaluateCondition,
  newContext,
} from "./lib/analyze.ts";
import { FIELD_BY_NAME, FIELD_SPECS } from "./lib/catalog.ts";
import { DEFAULT_ROOT } from "./lib/load.ts";
import { type Planet, loadPlanet, packPlanets, writePlanetDump } from "./lib/planet.ts";

interface Args {
  root: string;
  planet: string;
  faceLevel: number;
  seeds: string;
  conds: ConditionSpec[];
  condsFile: string | null;
  baseline: boolean;
  fields: boolean;
  verifyOnly: boolean;
  showBands: boolean;
  json: string | null;
  dump: string | null;
  cache: boolean;
  verify: boolean;
  quiet: boolean;
}

function parseArgs(argv: string[]): Args {
  const args: Args = {
    root: DEFAULT_ROOT, planet: "s2_test_planet", faceLevel: 7, seeds: "pack,1,42", conds: [], condsFile: null,
    baseline: false, fields: false, verifyOnly: false, showBands: false, json: null, dump: null, cache: true,
    verify: true, quiet: false,
  };
  for (let k = 0; k < argv.length; k++) {
    const arg = argv[k] as string;
    const value = () => {
      const v = argv[++k];
      if (v === undefined) throw new Error(`${arg} needs a value`);
      return v;
    };
    switch (arg) {
      case "--root": args.root = path.resolve(value()); break;
      case "--planet": args.planet = value(); break;
      case "--face-level": args.faceLevel = Number(value()); break;
      case "--seeds": args.seeds = value(); break;
      case "--cond": {
        const text = value();
        const at = text.indexOf("=");
        if (at <= 0 || text[at + 1] === "=") throw new Error(`--cond needs NAME=EXPR: ${text}`);
        args.conds.push({ name: text.slice(0, at).trim(), expr: text.slice(at + 1).trim() });
        break;
      }
      case "--conds": args.condsFile = path.resolve(value()); break;
      case "--baseline": args.baseline = true; break;
      case "--fields": args.fields = true; break;
      case "--verify-only": args.verifyOnly = true; break;
      case "--show-bands": args.showBands = true; break;
      case "--json": args.json = path.resolve(value()); break;
      case "--dump": args.dump = path.resolve(value()); break;
      case "--no-cache": args.cache = false; break;
      case "--no-verify": args.verify = false; break;
      case "--quiet": args.quiet = true; break;
      case "-h":
      case "--help":
        console.log("see the header comment of cli.ts for usage");
        process.exit(0);
        break;
      default:
        throw new Error(`unknown argument ${arg}`);
    }
  }
  return args;
}

const pct = (v: number, digits = 2) => (Number.isFinite(v) ? v.toFixed(digits) : "-");
const pad = (v: string | number, width: number) => String(v).padStart(width);
const num = (v: number, digits = 0) => (Number.isFinite(v) ? v.toFixed(digits) : "-");

function printVerification(planet: Planet): boolean {
  const v = planet.meta.verification;
  const replicaOk =
    v.tectonicsElevationMismatches === 0 && v.tectonicsPlateMismatches === 0 && v.tectonicsContinentalMismatches === 0 &&
    v.climateTemperatureMismatches === 0 && v.climatePrecipitationMismatches === 0 && v.climateOceanDistanceMismatches === 0 &&
    v.hydrologyDischargeMismatches === 0 && v.hydrologyBasinStateMismatches === 0 && (v.humidityReplicaMismatches ?? 0) === 0;
  const stagedOk = v.stagedMatchesOfficial !== false && v.detailsMatchOfficial !== false;
  const knownText = v.knownHash === null ? "no known hash" : v.officialMatchesKnown === null ? `known ${v.knownHash}` : v.officialMatchesKnown ? `= known ${v.knownHash}` : `!= known ${v.knownHash} (generator changed?)`;
  console.log(
    `  ${planet.meta.planetId} seed ${planet.meta.seed} F${planet.meta.faceLevel}: staged ${v.stagedHash}, official ${v.officialHash ?? "(skipped)"} ${knownText}; ` +
      `staged==official ${v.stagedMatchesOfficial ?? "-"}, receiver/basinKind ${v.detailsMatchOfficial ?? "-"}; ` +
      `replica mismatches tect elev/plate/crust ${v.tectonicsElevationMismatches}/${v.tectonicsPlateMismatches}/${v.tectonicsContinentalMismatches}, ` +
      `climate T/P/oceanDist ${v.climateTemperatureMismatches}/${v.climatePrecipitationMismatches}/${v.climateOceanDistanceMismatches}, ` +
      `water balance discharge/basinState ${v.hydrologyDischargeMismatches}/${v.hydrologyBasinStateMismatches}, riparian humidity ${v.humidityReplicaMismatches}` +
      `${planet.meta.fromCache ? " (cached)" : ""}`,
  );
  return replicaOk && stagedOk;
}

function printFields(): void {
  console.log("name                     dtype    kind     units                            source");
  for (const spec of FIELD_SPECS) {
    console.log(`${spec.name.padEnd(24)} ${spec.dtype.padEnd(8)} ${spec.kind.padEnd(8)} ${spec.units.padEnd(32)} ${spec.src}\n${" ".repeat(25)}${spec.desc}`);
  }
}

function printBaseline(title: string, baseline: Baseline): void {
  console.log(`\n== baseline ${title}: ${baseline.cells} cells, hash ${baseline.hash}`);
  const s = baseline.shares;
  console.log(
    `   ocean ${pct(s.oceanPct ?? 0)}%  lake ${pct(s.lakePct ?? 0)}%  land ${pct(s.landPct ?? 0)}%  | of land: river cells ${pct(s.riverCellPctOfLand ?? 0)}%  dry basin ${pct(s.dryBasinPctOfLand ?? 0)}%  coast ${pct(s.coastPctOfLand ?? 0)}%  | max river order ${s.maxRiverOrder}`,
  );
  console.log("   biome                 %all  %domain | elevationM game (min p5 p50 p95 max) | temperatureC (min p5 p50 p95 max) | precipitationMm (min p5 p50 p95 max) | humidity (min p5 p50 p95 max) | forest mean | |lat| p5-p95");
  for (const b of baseline.biomes) {
    const r = b.ranges;
    const five = (x: { min: number; p5: number; p50: number; p95: number; max: number }, w: number, d = 0) =>
      [x.min, x.p5, x.p50, x.p95, x.max].map((v) => pad(num(v, d), w)).join(" ");
    console.log(
      `   ${b.id.padEnd(20)} ${pad(pct(b.pctAll), 6)} ${pad(pct(b.pctOfDomain), 7)} | ${five(r.elevationM, 5)} | ${five(r.temperatureC, 4)} | ${five(r.precipitationMm, 5)} | ${five(r.humidity, 3)} | ${pad(num(r.forest.mean), 4)} | ${num(r.absLatDeg.p5)}-${num(r.absLatDeg.p95)}`,
    );
  }
  const o = baseline.overall;
  console.log(
    `   (all dry land)        elevationM ${num(o.elevationM?.min ?? NaN)}..${num(o.elevationM?.max ?? NaN)} (real ${num(o.realElevationM?.min ?? NaN)}..${num(o.realElevationM?.max ?? NaN)} m), T ${num(o.temperatureC?.min ?? NaN)}..${num(o.temperatureC?.max ?? NaN)} C, P ${num(o.precipitationMm?.min ?? NaN)}..${num(o.precipitationMm?.max ?? NaN)} mm, humidity ${num(o.humidity?.min ?? NaN)}..${num(o.humidity?.max ?? NaN)}`,
  );
}

function printCondition(name: string, expr: string | null, stats: ConditionStats[], showBands: boolean): void {
  console.log(`\n== ${name}${expr ? `: ${expr}` : " (mask function)"}`);
  console.log("   seed        match   %all  %area  %land %ocean  %lake | clusters single   med   p90   max  maxShare | F9 maps med/max | nearest centroid km min/med");
  for (const s of stats) {
    const c = s.clusters;
    console.log(
      `   ${pad(s.seed, 9)} ${pad(s.all.matched, 7)} ${pad(pct(s.all.pct), 6)} ${pad(pct(s.areaPctAll), 6)} ${pad(pct(s.land.pct), 6)} ${pad(pct(s.ocean.pct), 6)} ${pad(pct(s.lake.pct), 6)} | ${pad(c.count, 8)} ${pad(c.singletons, 6)} ${pad(num(c.sizeMedian, 1), 5)} ${pad(num(c.sizeP90, 1), 5)} ${pad(c.sizeMax, 5)} ${pad(pct(100 * c.largestShareOfMatched, 0), 8)}% | ${num(c.f9MapsMedian)}/${num(c.f9MapsMax)} | ${c.nearestCentroidKm ? `${num(c.nearestCentroidKm.min)}/${num(c.nearestCentroidKm.median)}` : "-"}`,
    );
  }
  // 시드 합산
  const sum = (pick: (s: ConditionStats) => number) => stats.reduce((a, s) => a + pick(s), 0);
  const matched = sum((s) => s.all.matched);
  const total = sum((s) => s.all.total);
  const landM = sum((s) => s.land.matched);
  const landT = sum((s) => s.land.total);
  const oceanM = sum((s) => s.ocean.matched);
  const oceanT = sum((s) => s.ocean.total);
  const lakeM = sum((s) => s.lake.matched);
  const lakeT = sum((s) => s.lake.total);
  console.log(
    `   pooled   ${pad(matched, 7)} ${pad(pct((100 * matched) / total), 6)}        ${pad(pct((100 * landM) / Math.max(1, landT)), 6)} ${pad(pct((100 * oceanM) / Math.max(1, oceanT)), 6)} ${pad(pct((100 * lakeM) / Math.max(1, lakeT)), 6)} | clusters/seed ${num(sum((s) => s.clusters.count) / stats.length, 1)}; matched split land/ocean/lake ${landM}/${oceanM}/${lakeM}`,
  );
  const bandMatched = new Array(18).fill(0);
  for (const s of stats) s.latitude.bands.forEach((b, k) => { bandMatched[k] += b.matched; });
  const bandRow = bandMatched.map((m) => pad(matched ? num((100 * m) / matched, 0) : "-", 3)).join("");
  console.log(`   latitude % of matched, 10deg bands S90..N90: ${bandRow}`);
  const absMean = stats.map((s) => s.latitude.absMean).filter(Number.isFinite);
  console.log(
    `   |lat| mean ${num(absMean.reduce((a, b) => a + b, 0) / Math.max(1, absMean.length), 1)} (per seed p10/p50/p90: ${stats.map((s) => `${num(s.latitude.absP10)}/${num(s.latitude.absP50)}/${num(s.latitude.absP90)}`).join(", ")}); north/south ${sum((s) => s.latitude.north)}/${sum((s) => s.latitude.south)}`,
  );
  const biomeTotals = new Map<string, number>();
  for (const s of stats) for (const b of s.biomes) biomeTotals.set(b.id, (biomeTotals.get(b.id) ?? 0) + b.matched);
  const biomeRow = [...biomeTotals.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([id, m]) => `${id} ${num((100 * m) / Math.max(1, matched), 0)}%`).join(", ");
  console.log(`   biomes of matched: ${biomeRow || "-"}`);
  if (showBands) {
    for (const s of stats) {
      console.log(`   seed ${s.seed} cluster sizes: ${s.clusters.histogram.filter((h) => h.count > 0).map((h) => `${h.label}:${h.count}`).join(" ")}; top ${s.clusters.top.join(",")}; area med/max ${num(s.clusters.areaMedianKm2)}/${num(s.clusters.areaMaxKm2)} real km2`);
      console.log(`   seed ${s.seed} latitude (% of band matching): ${s.latitude.bands.map((b) => `${b.from}:${num(b.pctOfBand, 1)}`).join(" ")}`);
    }
  }
}

async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));
  if (args.fields) {
    printFields();
    return;
  }
  const log = args.quiet ? () => {} : (line: string) => console.error(`[harness] ${line}`);
  const pack = packPlanets(args.root);
  const seeds: number[] = [];
  for (const token of args.seeds.split(",").map((t) => t.trim()).filter(Boolean)) {
    if (token === "pack") for (const p of pack) { if (p.id === args.planet) seeds.push(p.seed); }
    else seeds.push(Number(token));
  }
  const unique = [...new Set(seeds)];
  const planets: Planet[] = [];
  for (const seed of unique) {
    planets.push(await loadPlanet({ root: args.root, planetId: args.planet, faceLevel: args.faceLevel, seed, cache: args.cache, verify: args.verify, log }));
  }
  console.log(`root ${args.root}`);
  console.log(`generator version ${planets[0]?.meta.generatorVersion}, fingerprint ${planets[0]?.meta.fingerprint}, face level ${args.faceLevel} (${planets[0]?.meta.cellCount} cells; 1 cell = ${4 ** (9 - args.faceLevel)} F9 cells = 2nd maps)`);
  console.log("verification:");
  let ok = true;
  for (const planet of planets) ok = printVerification(planet) && ok;
  if (!ok) console.log("  WARNING: replica or staged pipeline does not match the generator — intermediates may be wrong");
  console.log(`  max RSS ${Math.round(process.resourceUsage().maxRSS / 1024)} MiB`);
  if (args.dump) {
    for (const planet of planets) {
      const dir = path.join(args.dump, `${planet.meta.planetId}-F${planet.meta.faceLevel}-s${planet.meta.seed}`);
      writePlanetDump(dir, planet);
      console.log(`dumped ${dir}`);
    }
  }
  if (args.verifyOnly) return;

  const results: { baseline?: unknown; conditions?: unknown } = {};
  if (args.baseline) {
    const perSeed = planets.map((planet) => baselineOf([planet]));
    for (const b of perSeed) printBaseline(`seed ${b.seed}`, b);
    const pooled = baselineOf(planets);
    if (planets.length > 1) printBaseline(`pooled seeds ${unique.join(",")}`, pooled);
    results.baseline = { perSeed, pooled };
  }

  let specs: ConditionSpec[] = [...args.conds];
  if (args.condsFile) {
    const mod = await import(pathToFileURL(args.condsFile).href);
    const list = mod.conditions ?? mod.default;
    if (!Array.isArray(list)) throw new Error(`${args.condsFile} must export conditions (array)`);
    specs = [...list, ...specs];
  }
  for (const spec of specs) {
    if (FIELD_BY_NAME.has(spec.name) || spec.name === "biomeId") throw new Error(`condition name "${spec.name}" collides with a field`);
    if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(spec.name)) throw new Error(`condition name "${spec.name}" must be an identifier`);
  }
  if (specs.length > 0) {
    const contexts = planets.map((planet) => newContext(planet));
    const all: { name: string; expr: string | null; note: string | null; stats: ConditionStats[] }[] = [];
    for (const spec of specs) {
      const stats = planets.map((planet, k) => {
        const mask = evaluateCondition(contexts[k] as ReturnType<typeof newContext>, spec);
        return conditionStats(planet, spec.name, spec.expr ?? null, mask);
      });
      printCondition(spec.name, spec.expr ?? null, stats, args.showBands);
      if (spec.note) console.log(`   note: ${spec.note}`);
      all.push({ name: spec.name, expr: spec.expr ?? null, note: spec.note ?? null, stats });
    }
    results.conditions = all;
  }
  if (args.json) {
    const meta = planets.map((p) => p.meta);
    mkdirSync(path.dirname(args.json), { recursive: true });
    writeFileSync(args.json, `${JSON.stringify({ meta, ...results }, null, 1)}\n`);
    console.log(`\nwrote ${args.json}`);
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.stack : error);
  process.exit(1);
});
