// 조건 모듈 예시 — 문법 보여 주기용. 문턱 값은 검토하지 않은 임시 값이다(후보·조건은 다른 작업에서 정한다).
// 실행: node cli.ts --conds conditions.example.ts [--show-bands] [--json out.json]
// - expr: 칸 하나의 식(필드 이름, 앞선 조건 이름, adj_X / dist_X / nbmax_X / nbmin_X, 상수 B·FEATURE·BASIN·DEPTH·W·MOUTH)
// - mask(planet, h): 배열 전체를 직접 계산(h.adjCount·h.distKm·h.dilate·h.neighborMax·h.neighborMin·h.mask(식)·h.masks)
export const conditions = [
  {
    name: "warmShallowSea",
    expr: "ocean && depthClass === DEPTH.COASTAL && seaLevelTempC >= 22",
    note: "coastal-depth ocean (<60 m real) with sea-surface temperature proxy >= 22 C",
  },
  {
    name: "reefCandidate",
    expr: "warmShallowSea && distToRiverMouthKm > 250",
    note: "warm shallow sea away from river mouths (sediment proxy)",
  },
  {
    name: "mangroveCandidate",
    expr: "land && coast && temperatureC >= 22 && humidity >= 150 && realElevationM <= 120 && slopeMPerKm < 4",
  },
  {
    name: "volcanicCandidate",
    expr: "!ocean && volcanicRealM >= 500",
    note: "andean volcanic arc + island arc + hotspot terms (tectonics.ts:249,252-256; hotspots.ts:69-83)",
  },
  {
    name: "hotSpringCandidate",
    expr: "land && !volcanicCandidate && (dist_volcanicCandidate <= 200 || (wRift > 0.15 && boundaryDistKm < 150)) && precipitationMm >= 300",
    note: "composition demo: dist_<earlier condition> and blended rift weight",
  },
  {
    name: "riverDelta",
    mask: (planet: any, h: any) => {
      const F = planet.fields;
      const mouths = new Uint8Array(planet.grid.cellCount);
      for (let c = 0; c < mouths.length; c++) {
        mouths[c] = F.riverMouth[c] === 1 && F.river[c] >= 3 && F.slopeMPerKm[c] < 3 ? 1 : 0;
      }
      const grown = h.dilate(mouths, 1);
      for (let c = 0; c < grown.length; c++) grown[c] = grown[c] && F.land[c] ? 1 : 0;
      return grown;
    },
    note: "mask-function demo: river mouths into the ocean with order >= 3, grown one cell over land",
  },
];
