// 조건 평가와 통계 — 칸마다 참/거짓 조건 → 비율(전체·육지·바다·호수), 이어진 덩어리(8이웃) 수와 크기, 위도 분포, 바이옴 구성.
// 조건 식(문자열)은 칸 하나의 값을 이름으로 쓴다: 예) "ocean && depthClass === DEPTH.COASTAL && temperatureC >= 22"
// - 필드 이름(catalog.ts) = 그 칸의 값, biomeId = 바이옴 ID 문자열
// - 앞서 정의한 조건 이름 = 0/1
// - adj_X = X가 참인 8이웃 수(0~8), dist_X = X가 참인 가장 가까운 칸까지 실제 환산 km(상한 2500),
//   nbmax_X / nbmin_X = 8이웃의 X 최댓값/최솟값(자기 칸 제외). X는 필드 이름이나 앞선 조건 이름
// - 상수: B.<바이옴ID> = 바이옴 번호, FEATURE.{NONE,COLLISION,ANDEAN,TRENCH,ISLAND_ARC,RIFT}, BASIN.{OPEN,LAKE,FILLED,DRY},
//   DEPTH.{NONE,COASTAL,SHELF,DEEP}, W.{OCEAN,LAKE,RIVER,COAST}, MOUTH.{OCEAN,LAKE,DRY}
import { FIELD_BY_NAME, type TypedArray } from "./catalog.ts";
import type { Planet } from "./planet.ts";

export const CONSTANTS = {
  FEATURE: { NONE: 0, COLLISION: 1, ANDEAN: 2, TRENCH: 3, ISLAND_ARC: 4, RIFT: 5 },
  BASIN: { OPEN: 0, LAKE: 1, FILLED: 2, DRY: 3 },
  DEPTH: { NONE: 0, COASTAL: 1, SHELF: 2, DEEP: 3 },
  W: { OCEAN: 1, LAKE: 2, RIVER: 4, COAST: 8 },
  MOUTH: { OCEAN: 1, LAKE: 2, DRY: 3 },
} as const;

const DIST_CAP_KM = 2500;
type NumArray = ArrayLike<number> & { [index: number]: number };

// ── 이웃·거리 도우미(조건 모듈에서도 쓴다) ──
export function adjCount(planet: Planet, values: ArrayLike<number>): Uint8Array {
  const { grid } = planet;
  const { neighbors8 } = planet.G.grid;
  const result = new Uint8Array(grid.cellCount);
  const out = new Int32Array(8);
  for (let c = 0; c < grid.cellCount; c++) {
    neighbors8(grid, c, out);
    let k = 0;
    for (let e = 0; e < 8; e++) {
      const next = out[e] as number;
      if (next >= 0 && values[next]) k++;
    }
    result[c] = k;
  }
  return result;
}

export function neighborExtreme(planet: Planet, values: ArrayLike<number>, wantMax: boolean): Float64Array {
  const { grid } = planet;
  const { neighbors8 } = planet.G.grid;
  const result = new Float64Array(grid.cellCount);
  const out = new Int32Array(8);
  for (let c = 0; c < grid.cellCount; c++) {
    neighbors8(grid, c, out);
    let best = wantMax ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY;
    for (let e = 0; e < 8; e++) {
      const next = out[e] as number;
      if (next < 0) continue;
      const v = values[next] as number;
      best = wantMax ? Math.max(best, v) : Math.min(best, v);
    }
    result[c] = best;
  }
  return result;
}

/** values가 참인 칸까지 실제 환산 km(생성기 distanceField, 8이웃, 상한 capKm) */
export function distKm(planet: Planet, values: ArrayLike<number>, capKm = DIST_CAP_KM): Float32Array {
  const { G, grid } = planet;
  const field = G.queues.distanceField(grid, (c: number) => !!values[c], G.util.km(capKm));
  const result = new Float32Array(grid.cellCount);
  const R: number = G.util.REFERENCE_RADIUS_KM;
  for (let c = 0; c < grid.cellCount; c++) result[c] = (field.angle[c] as number) * R;
  return result;
}

/** 마스크를 칸 steps번 넓힌다 */
export function dilate(planet: Planet, mask: ArrayLike<number>, steps = 1): Uint8Array {
  let current = Uint8Array.from(mask, (v) => (v ? 1 : 0));
  for (let s = 0; s < steps; s++) {
    const counts = adjCount(planet, current);
    const next = new Uint8Array(current.length);
    for (let c = 0; c < current.length; c++) next[c] = current[c] || (counts[c] as number) > 0 ? 1 : 0;
    current = next;
  }
  return current;
}

// ── 조건 식 컴파일 ──
export interface CompileContext {
  readonly planet: Planet;
  /** 앞서 계산한 조건 마스크 */
  readonly masks: Map<string, Uint8Array>;
  /** adj_·dist_·nbmax_·nbmin_ 캐시 */
  readonly derived: Map<string, ArrayLike<number>>;
}

export function newContext(planet: Planet): CompileContext {
  return { planet, masks: new Map(), derived: new Map() };
}

function sourceArray(ctx: CompileContext, name: string): ArrayLike<number> {
  const mask = ctx.masks.get(name);
  if (mask) return mask;
  const field = ctx.planet.fields[name];
  if (field) return field;
  throw new Error(`unknown field or condition "${name}"`);
}

function derivedArray(ctx: CompileContext, id: string): ArrayLike<number> | null {
  const match = /^(adj|dist|nbmax|nbmin)_(.+)$/.exec(id);
  if (!match) return null;
  const cached = ctx.derived.get(id);
  if (cached) return cached;
  const [, op, name] = match as unknown as [string, string, string];
  const source = sourceArray(ctx, name);
  let result: ArrayLike<number>;
  if (op === "adj") result = adjCount(ctx.planet, source);
  else if (op === "dist") result = distKm(ctx.planet, source);
  else result = neighborExtreme(ctx.planet, source, op === "nbmax");
  ctx.derived.set(id, result);
  return result;
}

export function compileExpression(ctx: CompileContext, expr: string): (i: number) => boolean {
  const ids = new Set(expr.match(/[A-Za-z_$][A-Za-z0-9_$]*/g) ?? []);
  const lines: string[] = [];
  const A: Record<string, ArrayLike<number>> = {};
  for (const id of ids) {
    if (id === "biomeId") {
      lines.push("const biomeId = $BIOME_IDS[$A.biome[$c]];");
      A.biome = ctx.planet.fields.biome as TypedArray;
      continue;
    }
    if (ctx.masks.has(id) || FIELD_BY_NAME.has(id)) {
      A[id] = sourceArray(ctx, id);
      lines.push(`const ${id} = $A.${id}[$c];`);
      continue;
    }
    const derived = derivedArray(ctx, id);
    if (derived) {
      A[id] = derived;
      lines.push(`const ${id} = $A.${id}[$c];`);
    }
  }
  const B: Record<string, number> = {};
  ctx.planet.meta.biomeIds.forEach((id, index) => {
    B[id] = index;
  });
  // 안쪽 이름은 $로 시작한다(필드 i·j 등과 겹치지 않게)
  const body = `return function ($c) { ${lines.join(" ")} return !!(${expr}); };`;
  const factory = new Function("$A", "$BIOME_IDS", "B", "FEATURE", "BASIN", "DEPTH", "W", "MOUTH", body);
  const { FEATURE, BASIN, DEPTH, W, MOUTH } = CONSTANTS;
  return factory(A, ctx.planet.meta.biomeIds, B, FEATURE, BASIN, DEPTH, W, MOUTH);
}

export interface Helpers {
  readonly adjCount: (values: ArrayLike<number>) => Uint8Array;
  readonly distKm: (values: ArrayLike<number>, capKm?: number) => Float32Array;
  readonly dilate: (mask: ArrayLike<number>, steps?: number) => Uint8Array;
  readonly neighborMax: (values: ArrayLike<number>) => Float64Array;
  readonly neighborMin: (values: ArrayLike<number>) => Float64Array;
  /** 식 → 마스크(앞선 조건 이름도 쓸 수 있다) */
  readonly mask: (expr: string) => Uint8Array;
  readonly masks: ReadonlyMap<string, Uint8Array>;
  readonly constants: typeof CONSTANTS;
}

export interface ConditionSpec {
  readonly name: string;
  /** 칸 조건 식 */
  readonly expr?: string;
  /** 마스크 함수(이웃·거리 등 자유 계산) */
  readonly mask?: (planet: Planet, helpers: Helpers) => ArrayLike<number>;
  readonly note?: string;
}

export function helpersFor(ctx: CompileContext): Helpers {
  const planet = ctx.planet;
  return {
    adjCount: (values) => adjCount(planet, values),
    distKm: (values, capKm) => distKm(planet, values, capKm),
    dilate: (mask, steps) => dilate(planet, mask, steps),
    neighborMax: (values) => neighborExtreme(planet, values, true),
    neighborMin: (values) => neighborExtreme(planet, values, false),
    mask: (expr) => maskFromExpression(ctx, expr),
    masks: ctx.masks,
    constants: CONSTANTS,
  };
}

export function maskFromExpression(ctx: CompileContext, expr: string): Uint8Array {
  const test = compileExpression(ctx, expr);
  const count = ctx.planet.grid.cellCount;
  const mask = new Uint8Array(count);
  for (let c = 0; c < count; c++) mask[c] = test(c) ? 1 : 0;
  return mask;
}

export function evaluateCondition(ctx: CompileContext, spec: ConditionSpec): Uint8Array {
  let mask: Uint8Array;
  if (spec.expr !== undefined) mask = maskFromExpression(ctx, spec.expr);
  else if (spec.mask) mask = Uint8Array.from(spec.mask(ctx.planet, helpersFor(ctx)), (v) => (v ? 1 : 0));
  else throw new Error(`condition ${spec.name} needs expr or mask`);
  ctx.masks.set(spec.name, mask);
  return mask;
}

// ── 통계 ──
function quantile(sorted: ArrayLike<number>, q: number): number {
  if (sorted.length === 0) return Number.NaN;
  const position = (sorted.length - 1) * q;
  const lo = Math.floor(position);
  const hi = Math.ceil(position);
  const a = sorted[lo] as number;
  const b = sorted[hi] as number;
  return a + (b - a) * (position - lo);
}

export interface ClusterInfo {
  readonly count: number;
  readonly singletons: number;
  readonly sizeMin: number;
  readonly sizeMedian: number;
  readonly sizeMean: number;
  readonly sizeP90: number;
  readonly sizeMax: number;
  readonly top: readonly number[];
  readonly histogram: readonly { readonly label: string; readonly count: number }[];
  readonly largestShareOfMatched: number;
  readonly areaMedianKm2: number;
  readonly areaMaxKm2: number;
  /** 2차맵(F9 칸) 수로 환산: 칸 수 × 4^(9−F) */
  readonly f9MapsMedian: number;
  readonly f9MapsMax: number;
  /** 덩어리 중심 사이 최근접 거리(실제 환산 km). 덩어리가 4000개를 넘으면 null */
  readonly nearestCentroidKm: { readonly min: number; readonly median: number; readonly max: number } | null;
  /** 칸 → 덩어리 번호(-1 = 조건 밖) */
  readonly label: Int32Array;
}

export function clustersOf(planet: Planet, mask: ArrayLike<number>): ClusterInfo {
  const { grid } = planet;
  const { neighbors8 } = planet.G.grid;
  const count: number = grid.cellCount;
  const label = new Int32Array(count).fill(-1);
  const queue = new Int32Array(count);
  const out = new Int32Array(8);
  const sizes: number[] = [];
  const areas: number[] = [];
  const centroids: number[] = [];
  const cellArea = planet.fields.cellAreaKm2 as Float32Array;
  for (let start = 0; start < count; start++) {
    if (!mask[start] || label[start] !== -1) continue;
    const id = sizes.length;
    let head = 0;
    let tail = 0;
    queue[tail++] = start;
    label[start] = id;
    let area = 0;
    let cx = 0;
    let cy = 0;
    let cz = 0;
    while (head < tail) {
      const c = queue[head++] as number;
      area += cellArea[c] as number;
      cx += grid.x[c];
      cy += grid.y[c];
      cz += grid.z[c];
      neighbors8(grid, c, out);
      for (let e = 0; e < 8; e++) {
        const next = out[e] as number;
        if (next < 0 || label[next] !== -1 || !mask[next]) continue;
        label[next] = id;
        queue[tail++] = next;
      }
    }
    sizes.push(tail);
    areas.push(area);
    const length = Math.sqrt(cx * cx + cy * cy + cz * cz) || 1;
    centroids.push(cx / length, cy / length, cz / length);
  }
  const sorted = Float64Array.from(sizes).sort();
  const sortedAreas = Float64Array.from(areas).sort();
  const matched = sizes.reduce((a, b) => a + b, 0);
  const bins = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024];
  const histogram = bins.map((lo, k) => {
    const hi = bins[k + 1] ?? Number.POSITIVE_INFINITY;
    return {
      label: hi === lo + 1 ? `${lo}` : Number.isFinite(hi) ? `${lo}-${hi - 1}` : `${lo}+`,
      count: sizes.filter((s) => s >= lo && s < hi).length,
    };
  });
  const scale = 4 ** (9 - planet.meta.faceLevel);
  let nearestCentroidKm: ClusterInfo["nearestCentroidKm"] = null;
  const k = sizes.length;
  if (k >= 2 && k <= 4000) {
    const R: number = planet.G.util.REFERENCE_RADIUS_KM;
    const nearest = new Float64Array(k);
    for (let a = 0; a < k; a++) {
      let best = Number.POSITIVE_INFINITY;
      const ax = centroids[3 * a] as number;
      const ay = centroids[3 * a + 1] as number;
      const az = centroids[3 * a + 2] as number;
      for (let b = 0; b < k; b++) {
        if (a === b) continue;
        const dx = ax - (centroids[3 * b] as number);
        const dy = ay - (centroids[3 * b + 1] as number);
        const dz = az - (centroids[3 * b + 2] as number);
        best = Math.min(best, dx * dx + dy * dy + dz * dz);
      }
      nearest[a] = 2 * Math.asin(Math.min(1, Math.sqrt(best) / 2)) * R;
    }
    nearest.sort();
    nearestCentroidKm = { min: nearest[0] as number, median: quantile(nearest, 0.5), max: nearest[k - 1] as number };
  }
  return {
    count: k,
    singletons: sizes.filter((s) => s === 1).length,
    sizeMin: k ? (sorted[0] as number) : 0,
    sizeMedian: quantile(sorted, 0.5),
    sizeMean: k ? matched / k : 0,
    sizeP90: quantile(sorted, 0.9),
    sizeMax: k ? (sorted[k - 1] as number) : 0,
    top: Array.from(sorted).reverse().slice(0, 8),
    histogram,
    largestShareOfMatched: matched ? (k ? (sorted[k - 1] as number) / matched : 0) : 0,
    areaMedianKm2: quantile(sortedAreas, 0.5),
    areaMaxKm2: k ? (sortedAreas[k - 1] as number) : 0,
    f9MapsMedian: quantile(sorted, 0.5) * scale,
    f9MapsMax: (k ? (sorted[k - 1] as number) : 0) * scale,
    nearestCentroidKm,
    label,
  };
}

export interface ShareInfo {
  readonly matched: number;
  readonly total: number;
  readonly pct: number;
}

export interface ConditionStats {
  readonly name: string;
  readonly expr: string | null;
  readonly planetId: string;
  readonly seed: number;
  readonly faceLevel: number;
  readonly hash: string;
  readonly all: ShareInfo;
  readonly areaPctAll: number;
  readonly land: ShareInfo;
  readonly ocean: ShareInfo;
  readonly lake: ShareInfo;
  readonly clusters: Omit<ClusterInfo, "label">;
  readonly latitude: {
    readonly bands: readonly { readonly from: number; readonly to: number; readonly matched: number; readonly pctOfMatched: number; readonly pctOfBand: number }[];
    readonly absMean: number;
    readonly absP10: number;
    readonly absP50: number;
    readonly absP90: number;
    readonly north: number;
    readonly south: number;
  };
  readonly biomes: readonly { readonly id: string; readonly matched: number; readonly pctOfMatched: number }[];
}

export function conditionStats(planet: Planet, name: string, expr: string | null, mask: ArrayLike<number>): ConditionStats {
  const F = planet.fields;
  const count = planet.grid.cellCount;
  const share = (pick: (c: number) => boolean): ShareInfo => {
    let matched = 0;
    let total = 0;
    for (let c = 0; c < count; c++) {
      if (!pick(c)) continue;
      total++;
      if (mask[c]) matched++;
    }
    return { matched, total, pct: total ? (100 * matched) / total : 0 };
  };
  const all = share(() => true);
  let area = 0;
  let areaMatched = 0;
  for (let c = 0; c < count; c++) {
    const a = F.cellAreaKm2[c] as number;
    area += a;
    if (mask[c]) areaMatched += a;
  }
  const lat = F.latitudeDeg as Float32Array;
  const bands = [];
  for (let from = -90; from < 90; from += 10) {
    const to = from + 10;
    let inBand = 0;
    let matched = 0;
    for (let c = 0; c < count; c++) {
      const l = lat[c] as number;
      if (l < from || (to < 90 ? l >= to : l > to)) continue;
      inBand++;
      if (mask[c]) matched++;
    }
    bands.push({ from, to, matched, pctOfMatched: all.matched ? (100 * matched) / all.matched : 0, pctOfBand: inBand ? (100 * matched) / inBand : 0 });
  }
  const absLats: number[] = [];
  let north = 0;
  for (let c = 0; c < count; c++) {
    if (!mask[c]) continue;
    absLats.push(Math.abs(lat[c] as number));
    if ((lat[c] as number) >= 0) north++;
  }
  const sortedAbs = Float64Array.from(absLats).sort();
  const biomeCounts = new Map<number, number>();
  for (let c = 0; c < count; c++) if (mask[c]) biomeCounts.set(F.biome[c] as number, (biomeCounts.get(F.biome[c] as number) ?? 0) + 1);
  const biomes = [...biomeCounts.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([index, matched]) => ({ id: planet.meta.biomeIds[index] ?? `#${index}`, matched, pctOfMatched: (100 * matched) / all.matched }));
  const { label: _label, ...clusters } = clustersOf(planet, mask);
  return {
    name,
    expr,
    planetId: planet.meta.planetId,
    seed: planet.meta.seed,
    faceLevel: planet.meta.faceLevel,
    hash: planet.meta.hash,
    all,
    areaPctAll: area ? (100 * areaMatched) / area : 0,
    land: share((c) => F.land[c] === 1),
    ocean: share((c) => F.ocean[c] === 1),
    lake: share((c) => F.lake[c] === 1),
    clusters,
    latitude: {
      bands,
      absMean: absLats.length ? absLats.reduce((a, b) => a + b, 0) / absLats.length : Number.NaN,
      absP10: quantile(sortedAbs, 0.1),
      absP50: quantile(sortedAbs, 0.5),
      absP90: quantile(sortedAbs, 0.9),
      north,
      south: absLats.length - north,
    },
    biomes,
  };
}

// ── 바탕 통계(바이옴별 비율과 값 범위) ──
export interface RangeInfo {
  readonly min: number;
  readonly p5: number;
  readonly p50: number;
  readonly p95: number;
  readonly max: number;
  readonly mean: number;
}

function rangeOf(values: number[]): RangeInfo {
  const sorted = Float64Array.from(values).sort();
  const n = sorted.length;
  return {
    min: n ? (sorted[0] as number) : Number.NaN,
    p5: quantile(sorted, 0.05),
    p50: quantile(sorted, 0.5),
    p95: quantile(sorted, 0.95),
    max: n ? (sorted[n - 1] as number) : Number.NaN,
    mean: n ? values.reduce((a, b) => a + b, 0) / n : Number.NaN,
  };
}

export const BASELINE_FIELDS = ["elevationM", "realElevationM", "temperatureC", "precipitationMm", "humidity", "forest", "absLatDeg"] as const;

export interface BiomeBaseline {
  readonly id: string;
  readonly cells: number;
  readonly pctAll: number;
  /** 육지 바이옴은 육지(바다·호수 아님) 대비, 바다 바이옴은 바다 대비, 호수는 전체 대비 */
  readonly pctOfDomain: number;
  readonly ranges: Record<(typeof BASELINE_FIELDS)[number], RangeInfo>;
}

export interface Baseline {
  readonly planetId: string;
  readonly seed: number;
  readonly faceLevel: number;
  readonly hash: string;
  readonly cells: number;
  readonly shares: Record<string, number>;
  readonly overall: Record<string, RangeInfo>;
  readonly biomes: readonly BiomeBaseline[];
}

export function baselineOf(planets: readonly Planet[]): Baseline {
  const first = planets[0];
  if (!first) throw new Error("no planets");
  const ids = first.meta.biomeIds;
  const groups = ids.map(() => Object.fromEntries(BASELINE_FIELDS.map((name) => [name, [] as number[]])) as Record<string, number[]>);
  const overall = Object.fromEntries(BASELINE_FIELDS.map((name) => [name, [] as number[]])) as Record<string, number[]>;
  let cells = 0;
  let ocean = 0;
  let lake = 0;
  let land = 0;
  let riverCells = 0;
  let dry = 0;
  let coast = 0;
  let maxRiver = 0;
  for (const planet of planets) {
    const F = planet.fields;
    const count = planet.grid.cellCount;
    cells += count;
    for (let c = 0; c < count; c++) {
      const b = F.biome[c] as number;
      for (const name of BASELINE_FIELDS) {
        const v = F[name][c] as number;
        groups[b]?.[name]?.push(v);
        if (F.land[c] === 1) overall[name]?.push(v);
      }
      if (F.ocean[c]) ocean++;
      else if (F.lake[c]) lake++;
      else land++;
      if (F.riverCell[c]) riverCells++;
      if (F.basinKind[c] === 3) dry++;
      if (F.coast[c]) coast++;
      maxRiver = Math.max(maxRiver, F.river[c] as number);
    }
  }
  const domainOf = (index: number): number => {
    const rule = ids[index] ?? "";
    if (rule.startsWith("ocean")) return ocean;
    if (rule === "lake") return cells;
    return land;
  };
  const biomes: BiomeBaseline[] = ids.map((id, index) => {
    const group = groups[index] as Record<string, number[]>;
    const n = (group.elevationM as number[]).length;
    return {
      id,
      cells: n,
      pctAll: (100 * n) / cells,
      pctOfDomain: (100 * n) / Math.max(1, domainOf(index)),
      ranges: Object.fromEntries(BASELINE_FIELDS.map((name) => [name, rangeOf(group[name] as number[])])) as BiomeBaseline["ranges"],
    };
  });
  return {
    planetId: first.meta.planetId,
    seed: planets.length === 1 ? first.meta.seed : -1,
    faceLevel: first.meta.faceLevel,
    hash: planets.length === 1 ? first.meta.hash : planets.map((p) => p.meta.hash).join(","),
    cells,
    shares: {
      oceanPct: (100 * ocean) / cells,
      lakePct: (100 * lake) / cells,
      landPct: (100 * land) / cells,
      riverCellPctOfLand: (100 * riverCells) / Math.max(1, land),
      dryBasinPctOfLand: (100 * dry) / Math.max(1, land),
      coastPctOfLand: (100 * coast) / Math.max(1, land),
      maxRiverOrder: maxRiver,
    },
    overall: Object.fromEntries(BASELINE_FIELDS.map((name) => [name, rangeOf(overall[name] as number[])])),
    biomes,
  };
}
