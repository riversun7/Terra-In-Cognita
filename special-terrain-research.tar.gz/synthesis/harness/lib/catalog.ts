// 칸별 배열 목록 — 이름·자료형·단위·출처(파일:행)·종류. 행 번호는 생성기 작업 트리 f59a8a7 기준.
// 종류(kind)
// - final   : PlanetFields 필드(또는 그 비트를 푼 것). 서버 굽기에 실제로 남는 값
// - details : runPlanetGenerator가 fields 밖으로 돌려주는 것(GeneratorDetails)
// - stage   : 내보낸 단계 함수가 돌려주지만 runPlanetGenerator가 버리는 것 — 단계 함수를 직접 불러 정확히 얻는다
// - replica : 단계 함수 안 지역 변수 — 하네스 복제본(shadowTectonics/shadowClimate)이 다시 계산. 생성기 결과와 비트 대조로 확인
// - derived : 생성기가 계산하지 않는 값 — 하네스가 생성기 자료로 새로 계산(식은 desc)
// 거리 Km는 모두 실제 환산 km(생성기 내부 단위, REFERENCE_RADIUS_KM 6371.0088). 게임 km = ÷ 12. RealM = 실제 환산 m.

export type Dtype = "int8" | "uint8" | "int16" | "uint16" | "int32" | "float32" | "float64";
export type Kind = "final" | "details" | "stage" | "replica" | "derived";

export interface FieldSpec {
  readonly name: string;
  readonly dtype: Dtype;
  readonly units: string;
  readonly kind: Kind;
  readonly src: string;
  readonly desc: string;
}

const f = (name: string, dtype: Dtype, units: string, kind: Kind, src: string, desc: string): FieldSpec => ({
  name, dtype, units, kind, src, desc,
});

export const FIELD_SPECS: readonly FieldSpec[] = [
  // ── 위치 ──
  f("face", "uint8", "0..5", "derived", "types.ts:61, grid.ts:1", "cube face of cell index c = face*n^2 + j*n + i"),
  f("i", "uint16", "0..n-1", "derived", "types.ts:61", "column on face"),
  f("j", "uint16", "0..n-1", "derived", "types.ts:61", "row on face"),
  f("latitudeDeg", "float32", "deg (N+)", "replica", "climate.ts:83-84", "latitude = detAsin(z)*180/pi exactly as climate uses (z = spin axis, unrotated grid)"),
  f("absLatDeg", "float32", "deg", "derived", "climate.ts:85", "|latitude|"),
  f("longitudeDeg", "float32", "deg (E+)", "derived", "grid.ts:18-20", "atan2(y, x) of the unrotated cell centre (not used by the generator)"),
  f("cellAreaKm2", "float32", "real km^2", "derived", "grid.ts:101-103", "areaOf(c) * 6371.0088^2 (game km^2 = /144)"),
  // ── 최종 PlanetFields ──
  f("elevationM", "int16", "game m (x12 = real)", "final", "surface.ts:141-144", "stored elevation, sea level 0; ocean/lake = bottom, filled/dry basins = filled height"),
  f("biome", "uint8", "index", "final", "surface.ts:160,183,189-190", "biome table index (first matching land rule wins, surface.ts:85-103)"),
  f("temperatureC", "int8", "degC", "final", "surface.ts:145-146", "annual mean temperature, rounded"),
  f("precipitationMm", "uint16", "mm/yr", "final", "surface.ts:147-148", "annual precipitation, rounded"),
  f("humidity", "uint8", "0..255", "final", "surface.ts:159,182,186-188", "255*AI/(AI+0.75)+nearWater; ocean/lake 255"),
  f("water", "uint8", "bits", "final", "surface.ts:150-180, types.ts:83-99", "1 ocean, 2 lake, 4 river, 8 coast, bits4-5 depth class"),
  f("river", "uint8", "Strahler order", "final", "surface.ts:149, hydrology.ts:172-221", "river order, 0 = none"),
  f("forest", "uint8", "0..255", "final", "surface.ts:191-198", "forest density = biome base * wetness(0.6..1) * fbm variation(0.85..1.15)"),
  f("ocean", "uint8", "0/1", "final", "types.ts:85, surface.ts:153-154", "water & 1 (same as classifyOcean ocean mask)"),
  f("lake", "uint8", "0/1", "final", "types.ts:87, surface.ts:179", "water & 2"),
  f("riverCell", "uint8", "0/1", "final", "types.ts:89, surface.ts:175-176", "water & 4 (river > 0)"),
  f("coast", "uint8", "0/1", "final", "types.ts:91, surface.ts:170", "water & 8: non-ocean cell with an ocean 8-neighbour"),
  f("depthClass", "uint8", "0..3", "final", "types.ts:93-99, surface.ts:155-158", "(water>>4)&3: 1 coastal <60 m real, 2 shelf <200 m, 3 deep; 0 not ocean"),
  f("land", "uint8", "0/1", "derived", "-", "not ocean and not lake (dry land incl. river cells)"),
  f("realElevationM", "int32", "real m", "final", "surface.ts:189", "elevationM*12 (the value biome rules test)"),
  // ── GeneratorDetails ──
  f("receiver", "int32", "cell index", "details", "generate.ts:141, flood.ts:13,53,81", "flow target (final post-erosion flow), -1 for ocean"),
  f("basinKind", "uint8", "0..3", "details", "generate.ts:142, hydrology.ts:153-159,183-188", "0 open, 1 lake (under water), 2 filled small pit, 3 dry basin (playa)"),
  // ── 단계 반환값(runPlanetGenerator가 버림) ──
  f("plate", "uint8", "plate id", "stage", "tectonics.ts:105-106,273 (dropped generate.ts:92)", "plate index from warped weighted spherical Voronoi"),
  f("continental", "uint8", "0/1", "stage", "tectonics.ts:129-131,273", "continental crust (land + shelf share by area percentile)"),
  f("preErosionElevRealM", "float32", "real m vs sea level", "stage", "tectonics.ts:205-272, seaLevel.ts:56-58", "elevation after tectonics + corner sea push, before erosion (climate used this)"),
  f("finalElevRealM", "float32", "real m vs sea level", "stage", "generate.ts:108-115", "post-erosion raw elevation (float)"),
  f("groundElevRealM", "float32", "real m vs sea level", "stage", "surface.ts:142", "unrounded stored ground (filled for filled/dry basins) = elevationM*12 before rounding"),
  f("erosionRealM", "float32", "real m", "stage", "generate.ts:108-115, hydrology.ts:130-149", "pre-erosion minus post-erosion elevation (>= 0, land only)"),
  f("filledRealM", "float32", "real m vs sea level", "stage", "flood.ts:15,43,54,85,98", "Priority-Flood filled surface (final flow)"),
  f("depressionDepthRealM", "float32", "real m", "stage", "flood.ts:85 vs elevation", "filled - elevation (pit/lake depth), 0 outside pits"),
  f("lakeDepthRealM", "float32", "real m", "stage", "flood.ts:85, hydrology.ts:186-187", "depressionDepthRealM where basinKind = lake"),
  f("basinId", "int32", "id", "stage", "flood.ts:20,95", "depression id (-1 none), final flow"),
  f("basinExit", "int32", "cell index", "stage", "flood.ts:22,93", "spill cell of the cell's depression (-1 none)"),
  f("basinState", "uint8", "0..2/255", "stage", "hydrology.ts:48-50,104-113", "water balance of the cell's depression: 0 filled, 1 lake, 2 dry, 255 none"),
  f("basinAreaKm2", "float32", "real km^2", "replica", "hydrology.ts:74-87", "area of the cell's depression where filled > ground (0 if none)"),
  f("basinMaxDepthRealM", "float32", "real m", "replica", "hydrology.ts:86", "max fill depth of the cell's depression (lake if >= 35 m and >= 3000 km^2)"),
  f("basinInflowKm3", "float32", "real km^3/yr", "replica", "hydrology.ts:91,120", "water entering the cell's depression"),
  f("basinEvaporationKm3", "float32", "real km^3/yr", "replica", "hydrology.ts:84-85,108", "surface evaporation of the depression x 100/lakePercent (value compared with inflow)"),
  f("basinWaterRatio", "float32", "ratio", "derived", "hydrology.ts:109", "inflow/evaporation: >= 1 overflowing lake, < 1 dry basin (only lake-sized basins); 0 outside depressions"),
  f("temperatureExactC", "float32", "degC", "stage", "climate.ts:82-89,199", "unrounded temperature"),
  f("precipitationExactMm", "float32", "mm/yr", "stage", "climate.ts:187-198", "unrounded precipitation"),
  f("distToOceanKm", "float32", "real km (cap 2500)", "stage", "climate.ts:186,199 (oceanDistance)", "distance to nearest ocean cell over any cells; 0 for ocean"),
  f("runoffMm", "float32", "mm/yr", "stage", "hydrology.ts:33-45, generate.ts:105", "P^2/(P+PET) on non-ocean cells"),
  f("dischargeKm3", "float64", "real km^3/yr", "stage", "hydrology.ts:94,119-121 (generate.ts:119)", "accumulated runoff (final water balance; lakes lose evaporation, dry basins absorb)"),
  // ── 복제: 판 구조 지역 변수 ──
  f("crustNoise", "float32", "noise units", "replica", "tectonics.ts:113-128", "generator name 'continentality': fbm + plate bias - corner push (crust, not climate)"),
  f("crustRank", "float32", "0..1", "replica", "tectonics.ts:133,276-310", "area rank inside continental crust (0 crust edge .. 1 innermost); drives shelf/land ramp"),
  f("plateBoundary", "uint8", "0/1", "replica", "tectonics.ts:140-151", "cell has an 8-neighbour on another plate"),
  f("neighborPlate", "int16", "plate id/-1", "replica", "tectonics.ts:143-150", "first other-plate neighbour's plate"),
  f("convergence", "float32", "rel. angular speed (NaN off-boundary)", "replica", "tectonics.ts:157-169", ">0 convergent, <=0 divergent; normal = centre difference projected on tangent plane"),
  f("shear", "float32", "rel. angular speed (NaN off-boundary)", "derived", "plates.ts:64-71 (not in generator)", "relative velocity along the boundary (transform component); generator ignores it"),
  f("boundaryClass", "uint8", "0..3", "derived", "tectonics.ts:169 + shear", "0 not boundary, 1 convergent, 2 divergent, 3 transform (|shear| > |convergence|); generator itself only knows the sign of convergence"),
  f("boundaryFeatureRaw", "uint8", "0..5", "replica", "tectonics.ts:173-182, boundaries.ts:6-11", "0 none, 1 collision, 2 andean, 3 trench, 4 island arc, 5 rift (before blending)"),
  f("boundaryStrengthRaw", "float32", "0..1.5", "replica", "tectonics.ts:172", "min(1.5, |convergence|/0.55)"),
  f("midOceanRidge", "uint8", "0/1", "replica", "tectonics.ts:180-181", "divergent boundary on oceanic crust (ridge source)"),
  f("boundarySlot", "int32", "slot/-1", "replica", "boundaries.ts:39-48,78-82", "boundary slot (-1 if blended weights < 1e-4)"),
  f("boundaryDistKm", "float32", "real km (cap 700)", "replica", "tectonics.ts:185-190", "distance to nearest weighted boundary slot on the SAME plate"),
  f("boundarySource", "int32", "cell/-1", "replica", "tectonics.ts:185-190,233", "that nearest boundary cell"),
  f("wCollision", "float32", "0..1.5", "replica", "boundaries.ts:50-77, tectonics.ts:240-241", "blended collision weight at boundarySource"),
  f("wAndean", "float32", "0..1.5", "replica", "boundaries.ts:50-77, tectonics.ts:242", "blended andean (ocean-continent subduction, continental side) weight"),
  f("wTrench", "float32", "0..1.5", "replica", "boundaries.ts:50-77, tectonics.ts:243", "blended trench weight"),
  f("wArc", "float32", "0..1.5", "replica", "boundaries.ts:50-77, tectonics.ts:244", "blended island-arc weight"),
  f("wRift", "float32", "0..1.5", "replica", "boundaries.ts:50-77, tectonics.ts:245", "blended continental rift weight"),
  f("boundaryAlong", "float32", "0.35..1.65", "replica", "tectonics.ts:238", "low-frequency strength modulation along the boundary"),
  f("ridgeTexture", "float32", "0.45..1.55", "replica", "tectonics.ts:239", "ridged-noise texture multiplying mountain terms"),
  f("ridgeDistKm", "float32", "real km (cap 2800)", "replica", "tectonics.ts:191-196,227", "distance to mid-ocean ridge through oceanic crust (seafloor age proxy)"),
  f("shelfDistKm", "float32", "real km (cap 260)", "replica", "tectonics.ts:197-202,229", "distance from continental crust over oceanic crust (continental slope)"),
  f("crustBaseRealM", "float32", "real m (absolute)", "replica", "tectonics.ts:217-224,226-230", "crust base height before noise (shelf/land ramp, or ocean floor by age/slope)"),
  f("reliefNoiseRealM", "float32", "real m", "replica", "tectonics.ts:225,231", "fBm relief term"),
  f("collisionRealM", "float32", "real m", "replica", "tectonics.ts:246", "continent-continent collision uplift"),
  f("andeanRealM", "float32", "real m", "replica", "tectonics.ts:248", "andean-type range uplift"),
  f("andeanVolcanicRealM", "float32", "real m", "replica", "tectonics.ts:249", "andean volcanic arc term (volcanism-scaled, peak ~190 km inland of boundary)"),
  f("trenchRealM", "float32", "real m (<=0)", "replica", "tectonics.ts:251", "trench deepening"),
  f("islandArcRealM", "float32", "real m", "replica", "tectonics.ts:252-256", "island-arc volcano term (volcanism-scaled, broken by noise)"),
  f("riftRealM", "float32", "real m (<=0)", "replica", "tectonics.ts:257", "continental rift depression"),
  f("hotspotRealM", "float32", "real m", "replica", "hotspots.ts:69-83, tectonics.ts:261-272", "sum of hotspot-chain volcano gaussians"),
  f("hotspotNearestKm", "float32", "real km (chord)", "derived", "hotspots.ts:19-58", "distance to nearest hotspot-chain volcano centre"),
  f("hotspotStep", "uint8", "0..5/255", "derived", "hotspots.ts:41-53", "chain step of nearest volcano (0 = youngest/active, 5 = oldest)"),
  f("hotspotId", "uint8", "id/255", "derived", "hotspots.ts:29", "hotspot of nearest volcano"),
  f("upliftRealM", "float32", "real m", "derived", "tectonics.ts:246-256", "collision + andean + andeanVolcanic + islandArc"),
  f("volcanicRealM", "float32", "real m", "derived", "tectonics.ts:249,252-256, hotspots.ts:69-83", "andeanVolcanic + islandArc + hotspot"),
  // ── 복제: 기후 지역 변수 ──
  f("seaLevelTempC", "float32", "degC", "replica", "climate.ts:85-86", "sea-level temperature by latitude (ocean cells = this)"),
  f("windU", "float32", "rel. (east +)", "replica", "climate.ts:53-68,107", "zonal wind component of the latitude band"),
  f("windV", "float32", "rel. (north +)", "replica", "climate.ts:53-68,107", "meridional wind component"),
  f("upwindCell", "int32", "cell index", "replica", "climate.ts:92-131", "neighbour the wind comes from (self if calm)"),
  f("orographicRise", "float32", "m/m", "replica", "climate.ts:150-153", "climb from upwind cell / distance (windward slope), land only"),
  f("orographicLift", "float32", "0..2.5", "replica", "climate.ts:192", "min(2.5, 45*rise): precipitation multiplier - 1"),
  f("moistureArriving", "float32", "0..1", "replica", "climate.ts:133-185", "moisture carried in along the wind path (after blur)"),
  f("moistureCoastal", "float32", "0..0.55", "replica", "climate.ts:190", "0.55*exp(-oceanDistance/450 km)"),
  f("moisture", "float32", "0..1", "replica", "climate.ts:191", "max(arriving, coastal)"),
  f("convectiveBase", "float32", "0.12..0.42", "replica", "climate.ts:194-195", "moisture-independent (convective) share, large near equator"),
  f("zonalPrecipMm", "float32", "mm/yr", "replica", "climate.ts:45-50,196", "latitude-band base precipitation"),
  f("moistureArrivingNoOro", "float32", "0..1", "derived", "climate.ts:157 without the climb term", "arriving moisture if mountains did not deplete it"),
  f("precipitationNoOroMm", "float32", "mm/yr", "derived", "climate.ts:196 with moistureArrivingNoOro", "precipitation without upwind orographic depletion"),
  f("rainShadow", "float32", "0..1", "derived", "-", "1 - P/P_noOro: share of precipitation lost to cumulative upwind climbing along the whole wind path (small relief counts too)"),
  f("leeRidgeRealM", "float32", "real m", "derived", "climate.ts:92-131 upwind chain", "highest ground (sea surface for ocean) within 500 km upwind minus own ground, >= 0 (lee of a range)"),
  // ── 새로 계산(생성기에 없음) ──
  f("potentialEvapMm", "float32", "mm/yr", "derived", "hydrology.ts:23-25, surface.ts:186", "max(80, 45*(T+6)) at rounded T (as humidity uses)"),
  f("aridityIndex", "float32", "P/PET", "derived", "surface.ts:186", "exact AI used for humidity (float P / PET(rounded T)); ocean/lake 0"),
  f("nearWaterBonus", "float32", "humidity units", "replica", "surface.ts(c08f84f):188-199, riparian.ts", "riparian humidity bonus: riverBonus(order of nearest river) x riverShare(dist, cell size) x river length share, or lake 24 x lakeShare; 12 km real band"),
  f("humidityDry", "uint8", "0..255", "derived", "surface.ts(c08f84f):200-201", "humidity without the riparian bonus: round(255*AI/(AI+0.75)) (land only)"),
  f("riverLengthShare", "float32", "0..1", "stage", "hydrology.ts(c08f84f) Rivers.length", "share of the cell length a river occupies (1 if inflow already over threshold)"),
  f("slopeMPerKm", "float32", "real m per real km", "derived", "-", "max |ground diff| / chord over 8 neighbours (F-dependent: F7 cell ~72 km real)"),
  f("downslopeMPerKm", "float32", "real m per real km", "derived", "-", "ground drop to receiver / chord (0 if ocean)"),
  f("reliefRealM", "float32", "real m", "derived", "-", "max-min ground elevation over 3x3 neighbourhood"),
  f("drainageAreaKm2", "float32", "real km^2", "derived", "flood.ts:17 order", "upstream area along receiver (incl. self), ignores basin water balance"),
  f("riverMouth", "uint8", "0..3", "derived", "-", "river cell whose receiver is 1 ocean / 2 lake / 3 dry basin; 0 otherwise"),
  f("endorheic", "uint8", "0/1", "derived", "hydrology.ts:113 (dry basins)", "land cell draining into a dry basin before the ocean"),
  f("oceanDepthRealM", "float32", "real m", "derived", "surface.ts:155", "sea level - elevation (ocean only, exact float)"),
  f("distToLandKm", "float32", "real km (cap 2500)", "derived", "queues.ts:97-168", "ocean cell to nearest non-ocean cell (0 on land)"),
  f("distToRiverKm", "float32", "real km (cap 2500)", "derived", "queues.ts:97-168", "to nearest river cell"),
  f("distToLakeKm", "float32", "real km (cap 2500)", "derived", "queues.ts:97-168", "to nearest lake cell"),
  f("distToRiverMouthKm", "float32", "real km (cap 2500)", "derived", "queues.ts:97-168", "to nearest river mouth into the ocean"),
  f("distToPlateBoundaryKm", "float32", "real km (cap 2500)", "derived", "queues.ts:97-168", "to nearest plate-boundary cell of any plate (unconstrained)"),
];

export const FIELD_BY_NAME: ReadonlyMap<string, FieldSpec> = new Map(FIELD_SPECS.map((spec) => [spec.name, spec]));

export type TypedArray = Int8Array | Uint8Array | Int16Array | Uint16Array | Int32Array | Float32Array | Float64Array;

export function allocate(dtype: Dtype, length: number): TypedArray {
  switch (dtype) {
    case "int8": return new Int8Array(length);
    case "uint8": return new Uint8Array(length);
    case "int16": return new Int16Array(length);
    case "uint16": return new Uint16Array(length);
    case "int32": return new Int32Array(length);
    case "float32": return new Float32Array(length);
    case "float64": return new Float64Array(length);
  }
}

export function fromBuffer(dtype: Dtype, buffer: ArrayBuffer): TypedArray {
  switch (dtype) {
    case "int8": return new Int8Array(buffer);
    case "uint8": return new Uint8Array(buffer);
    case "int16": return new Int16Array(buffer);
    case "uint16": return new Uint16Array(buffer);
    case "int32": return new Int32Array(buffer);
    case "float32": return new Float32Array(buffer);
    case "float64": return new Float64Array(buffer);
  }
}
