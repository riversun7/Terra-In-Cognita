// 생성기 모듈 불러오기 — 저장소(또는 사본) 루트를 받아 절대 경로로 동적 import 한다.
// 저장소 코드는 고치지 않는다. 생성기가 index.ts로 내보내지 않는 단계 함수도 각 모듈 파일에서는 export 되어 있어 그대로 쓴다.
import { pathToFileURL } from "node:url";
import { existsSync } from "node:fs";
import path from "node:path";

/** 기본 루트: 생성기 작업 트리(읽기만) */
export const DEFAULT_ROOT = "/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/synthesis/harness/snapshot-c08f84f";

// 생성기 모듈 묶음 (타입은 느슨하게: Node 타입 지우기로 바로 실행하므로 타입 검사는 하지 않는다)
export interface GeneratorModules {
  root: string;
  index: any;
  grid: any;
  tectonics: any;
  plates: any;
  boundaries: any;
  hotspots: any;
  noise: any;
  queues: any;
  random: any;
  util: any;
  seaLevel: any;
  flood: any;
  climate: any;
  hydrology: any;
  surface: any;
  hash: any;
  version: any;
  corners: any;
  shared: any;
  riparian: any;
}

/** 해시 대조에 쓰는 생성기 원본 파일 목록(캐시 지문에도 쓴다) */
export function generatorSourceFiles(root: string): string[] {
  const gen = path.join(root, "packages/planet/src/generator");
  const names = [
    "boundaries.ts", "climate.ts", "definition.ts", "flood.ts", "generate.ts", "grid.ts", "hash.ts",
    "hotspots.ts", "hydrology.ts", "index.ts", "noise.ts", "plates.ts", "queues.ts", "riparian.ts",
    "random.ts", "seaLevel.ts", "surface.ts", "tectonics.ts", "types.ts", "util.ts", "version.ts",
  ];
  return [
    ...names.map((name) => path.join(gen, name)),
    path.join(root, "packages/planet/src/corners.ts"),
    path.join(root, "packages/planet/src/faces.ts"),
    path.join(root, "packages/planet/src/levels.ts"),
    path.join(root, "packages/planet/src/projection.ts"),
    path.join(root, "packages/planet/src/cellKey.ts"),
    path.join(root, "packages/planet/src/hilbert.ts"),
    path.join(root, "packages/shared/src/detMath.ts"),
    path.join(root, "packages/shared/src/rng.ts"),
    path.join(root, "packages/shared/src/planetDefinition.ts"),
    path.join(root, "packages/shared/src/planetPresets.ts"),
    path.join(root, "content/core/planets.json"),
    path.join(root, "content/core/biomes.json"),
  ];
}

export async function loadGenerator(root: string = DEFAULT_ROOT): Promise<GeneratorModules> {
  const abs = path.resolve(root);
  const gen = path.join(abs, "packages/planet/src/generator");
  if (!existsSync(path.join(gen, "index.ts"))) throw new Error(`generator not found under ${abs}`);
  const load = (file: string) => import(pathToFileURL(file).href);
  const [
    index, grid, tectonics, plates, boundaries, hotspots, noise, queues, random, util,
    seaLevel, flood, climate, hydrology, surface, hash, version, corners, shared, riparian,
  ] = await Promise.all([
    load(path.join(gen, "index.ts")),
    load(path.join(gen, "grid.ts")),
    load(path.join(gen, "tectonics.ts")),
    load(path.join(gen, "plates.ts")),
    load(path.join(gen, "boundaries.ts")),
    load(path.join(gen, "hotspots.ts")),
    load(path.join(gen, "noise.ts")),
    load(path.join(gen, "queues.ts")),
    load(path.join(gen, "random.ts")),
    load(path.join(gen, "util.ts")),
    load(path.join(gen, "seaLevel.ts")),
    load(path.join(gen, "flood.ts")),
    load(path.join(gen, "climate.ts")),
    load(path.join(gen, "hydrology.ts")),
    load(path.join(gen, "surface.ts")),
    load(path.join(gen, "hash.ts")),
    load(path.join(gen, "version.ts")),
    load(path.join(abs, "packages/planet/src/corners.ts")),
    load(path.join(abs, "packages/shared/src/index.ts")),
    load(path.join(gen, "riparian.ts")),
  ]);
  return {
    root: abs, index, grid, tectonics, plates, boundaries, hotspots, noise, queues, random, util,
    seaLevel, flood, climate, hydrology, surface, hash, version, corners, shared, riparian,
  };
}
