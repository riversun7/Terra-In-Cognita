// 행성 한 개(정의 + 시드 + 면 레벨)를 단계별로 돌려 칸별 배열을 모은다 — 읽기 전용(저장소 코드는 고치지 않는다).
// 1) 단계 파이프라인: generate.ts runPlanetGenerator(79~145행)와 같은 순서로 생성기의 단계 함수를 직접 부른다
//    → 단계 반환값(판 번호, 대륙 지각, 채운 높이, 누적 유량 …)을 버리지 않고 남긴다. 결과 해시를 공식 실행과 대조한다.
// 2) 복제본(shadowTectonics·shadowClimate)으로 단계 안 지역 변수를 다시 계산하고, 고도·기온·강수가 생성기 값과
//    비트까지 같은지 본다.
// 3) 생성기에 없는 값(경사, 거리장, 하구 …)을 새로 계산한다.
// 결과는 캐시 폴더에 배열마다 이진 파일 + manifest.json으로 남긴다(지문 = 생성기 원본 + 하네스 원본의 sha256).
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync, readdirSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { FIELD_SPECS, type FieldSpec, type TypedArray, allocate, fromBuffer } from "./catalog.ts";
import { type GeneratorModules, generatorSourceFiles, loadGenerator } from "./load.ts";
import { type HotspotInfo, shadowTectonics } from "./shadowTectonics.ts";
import { shadowClimate } from "./shadowClimate.ts";
import { shadowWaterBalance } from "./shadowHydrology.ts";

export const HARNESS_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const HARNESS_VERSION = 2;
/** 알려진 골든 해시(작업 기록 29-1020-s2-generator.md 60행: S2 시험 행성, F6·F7·F9·F10) */
export const KNOWN_HASHES: Readonly<Record<string, string>> = {
  // 생성기 출력 판 2(c08f84f, 강가 가산 해상도 무관): 작업 기록 29-1450-s2-generator-review-fixes.md, generate.test.ts
  "s2_test_planet:20261029:5": "5c984c77",
  "s2_test_planet:20261029:6": "215d9b32",
  "s2_test_planet:20261029:7": "5664ca15",
  "s2_test_planet:20261029:9": "ac761e56",
};
// generate.ts 24·26행 (내보내지 않아서 옮겨 적음)
const EROSION_PASSES = 3;
const EROSION_STRENGTH = 0.25;
const DIST_CAP_KM = 2500;

export interface Verification {
  /** 단계 파이프라인 해시 */
  readonly stagedHash: string;
  /** runPlanetGenerator 해시(공식) — 생략했으면 null */
  readonly officialHash: string | null;
  /** 작업 기록의 골든 해시(알려진 것만) */
  readonly knownHash: string | null;
  readonly stagedMatchesOfficial: boolean | null;
  readonly officialMatchesKnown: boolean | null;
  /** receiver·basinKind 배열이 공식 결과와 같은지 */
  readonly detailsMatchOfficial: boolean | null;
  /** 복제본 대조: 다른 칸 수(0이면 비트까지 같음) */
  readonly tectonicsElevationMismatches: number;
  readonly tectonicsPlateMismatches: number;
  readonly tectonicsContinentalMismatches: number;
  readonly climateTemperatureMismatches: number;
  readonly climatePrecipitationMismatches: number;
  readonly climateOceanDistanceMismatches: number;
  readonly hydrologyDischargeMismatches: number;
  readonly hydrologyBasinStateMismatches: number;
  /** 강가 가산 복제로 다시 만든 습도가 저장 습도와 다른 칸 수 */
  readonly humidityReplicaMismatches: number;
}

export interface PlanetMetaInfo {
  readonly harnessVersion: number;
  readonly planetId: string;
  readonly seed: number;
  readonly faceLevel: number;
  readonly n: number;
  readonly cellCount: number;
  readonly generatorVersion: number;
  readonly hash: string;
  readonly settings: Record<string, number>;
  readonly biomeIds: readonly string[];
  readonly biomeColors: readonly string[];
  readonly seaLevelRealM: number;
  readonly crustThreshold: number;
  readonly riverThresholdKm3: number;
  readonly plateCount: number;
  readonly rotation: readonly number[];
  readonly hotspots: readonly HotspotInfo[];
  readonly root: string;
  readonly fingerprint: string;
  readonly verification: Verification;
  readonly timingsMs: Record<string, number>;
  readonly fromCache: boolean;
}

export interface Planet {
  readonly meta: PlanetMetaInfo;
  readonly fields: Record<string, TypedArray>;
  /** 생성기 격자(neighbors8·areaOf와 함께 쓴다) */
  readonly grid: any;
  readonly G: GeneratorModules;
}

export interface LoadOptions {
  readonly root?: string;
  readonly planetId?: string;
  readonly faceLevel?: number;
  readonly seed?: number;
  readonly cache?: boolean;
  /** 공식 runPlanetGenerator도 돌려 해시를 대조한다(기본 true) */
  readonly verify?: boolean;
  readonly log?: (line: string) => void;
}

// ── 행성 정의 읽기 ──
function entriesOf(root: string, file: string): any[] {
  const parsed = JSON.parse(readFileSync(path.join(root, "content/core", file), "utf8"));
  if (!parsed || !Array.isArray(parsed.entries)) throw new Error(`${file} has no entries`);
  return parsed.entries;
}

export function packPlanets(root: string): { id: string; seed: number; faceLevel: number }[] {
  return entriesOf(root, "planets.json").map((p) => ({ id: p.id, seed: p.seed, faceLevel: p.faceLevel }));
}

function fingerprintOf(root: string): string {
  const hash = createHash("sha256");
  hash.update(`harness:${HARNESS_VERSION}\n`);
  for (const file of generatorSourceFiles(root)) {
    hash.update(`${path.relative(root, file)}\n`);
    hash.update(existsSync(file) ? readFileSync(file) : "missing");
  }
  const libDir = path.join(HARNESS_DIR, "lib");
  for (const name of readdirSync(libDir).sort()) {
    if (name.endsWith(".ts")) hash.update(readFileSync(path.join(libDir, name)));
  }
  return hash.digest("hex").slice(0, 16);
}

// ── 캐시 ──
function cacheDir(planetId: string, seed: number, faceLevel: number, fingerprint: string): string {
  return path.join(HARNESS_DIR, "cache", `${planetId}-F${faceLevel}-s${seed}-${fingerprint}`);
}

export function writePlanetDump(dir: string, planet: Planet): void {
  mkdirSync(dir, { recursive: true });
  const fields: (FieldSpec & { file: string; length: number })[] = [];
  for (const spec of FIELD_SPECS) {
    const array = planet.fields[spec.name];
    if (!array) continue;
    const file = `${spec.name}.bin`;
    writeFileSync(path.join(dir, file), new Uint8Array(array.buffer, array.byteOffset, array.byteLength));
    fields.push({ ...spec, file, length: array.length });
  }
  const manifest = {
    note: "little-endian raw arrays, one per field; cell index c = face*n^2 + j*n + i (numpy: np.fromfile(file, dtype))",
    meta: planet.meta,
    fields,
  };
  writeFileSync(path.join(dir, "manifest.json"), `${JSON.stringify(manifest, null, 1)}\n`);
}

function readPlanetDump(dir: string): { meta: PlanetMetaInfo; fields: Record<string, TypedArray> } | null {
  const manifestFile = path.join(dir, "manifest.json");
  if (!existsSync(manifestFile)) return null;
  const manifest = JSON.parse(readFileSync(manifestFile, "utf8"));
  const fields: Record<string, TypedArray> = {};
  for (const entry of manifest.fields) {
    const bytes = readFileSync(path.join(dir, entry.file));
    const buffer = new ArrayBuffer(bytes.length);
    new Uint8Array(buffer).set(bytes);
    fields[entry.name] = fromBuffer(entry.dtype, buffer);
  }
  // 목록에 새로 생긴 필드가 캐시에 없으면 캐시를 버린다
  for (const spec of FIELD_SPECS) if (!fields[spec.name]) return null;
  return { meta: { ...manifest.meta, fromCache: true }, fields };
}

// ── 대조 도우미 ──
function mismatches(a: ArrayLike<number>, b: ArrayLike<number>): number {
  if (a.length !== b.length) return Math.max(a.length, b.length);
  let count = 0;
  for (let k = 0; k < a.length; k++) {
    const x = a[k] as number;
    const y = b[k] as number;
    if (!(x === y || (Number.isNaN(x) && Number.isNaN(y)))) count++;
  }
  return count;
}

/** 행성 하나를 불러온다(캐시가 있으면 캐시) */
export async function loadPlanet(options: LoadOptions = {}): Promise<Planet> {
  const G = await loadGenerator(options.root);
  const log = options.log ?? (() => {});
  const planetId = options.planetId ?? "s2_test_planet";
  const planets = entriesOf(G.root, "planets.json");
  const biomeEntries = entriesOf(G.root, "biomes.json");
  const definition = planets.find((p) => p.id === planetId);
  if (!definition) throw new Error(`planet ${planetId} not in content/core/planets.json`);
  const faceLevel = options.faceLevel ?? 7;
  const baseInput = G.index.planetInputFromDefinition(definition, biomeEntries, faceLevel);
  const seed = options.seed ?? baseInput.seed;
  const input = { ...baseInput, seed };
  const grid = G.grid.buildGrid(faceLevel);
  const fingerprint = fingerprintOf(G.root);
  const dir = cacheDir(planetId, seed, faceLevel, fingerprint);
  if (options.cache !== false) {
    const cached = readPlanetDump(dir);
    if (cached) {
      log(`cache hit ${dir}`);
      return { meta: cached.meta, fields: cached.fields, grid, G };
    }
  }
  const planet = computePlanet(G, grid, input, planetId, fingerprint, options.verify !== false, log);
  if (options.cache !== false) writePlanetDump(dir, planet);
  return planet;
}

function computePlanet(
  G: GeneratorModules,
  grid: any,
  input: any,
  planetId: string,
  fingerprint: string,
  verify: boolean,
  log: (line: string) => void,
): Planet {
  const timings: Record<string, number> = {};
  let last = performance.now();
  const lap = (name: string) => {
    const now = performance.now();
    timings[name] = Math.round(now - last);
    last = now;
  };
  const { faceLevel, seed, biomes } = input;
  const settings = { ...input.settings };
  const count: number = grid.cellCount;
  const n: number = grid.n;
  const RKM: number = G.util.REFERENCE_RADIUS_KM;
  const { neighbors8, areaOf, chordBetween } = G.grid;
  const H = G.hydrology;

  // ── 1) 단계 파이프라인 (generate.ts 89~137행과 같은 순서) ──
  const tect = G.tectonics.buildTectonics(grid, seed, settings);
  const tectonicElevation = Float32Array.from(tect.elevation);
  lap("tectonics");
  const { seaLevel, ocean } = G.seaLevel.classifyOcean(grid, tect.elevation, settings.landPercent);
  const elevation: Float32Array = tect.elevation;
  const preErosion = Float32Array.from(elevation);
  let flow = G.flood.priorityFlood(grid, elevation, ocean);
  lap("seaLevel+flow");
  const climate = G.climate.computeClimate(grid, elevation, seaLevel, ocean, settings);
  const runoff = H.runoffOf(climate.precipitation, climate.temperature, ocean);
  lap("climate");
  const strength = (EROSION_STRENGTH * settings.erosionPercent) / 100;
  if (strength > 0) {
    for (let pass = 0; pass < EROSION_PASSES; pass++) {
      const passBalance = H.waterBalance(grid, flow, elevation, runoff, climate.temperature, settings.lakePercent);
      H.erodeOnce(grid, flow, elevation, passBalance.discharge, ocean, seaLevel, strength);
      flow = G.flood.priorityFlood(grid, elevation, ocean);
    }
  }
  lap("erosion");
  const balance = H.waterBalance(grid, flow, elevation, runoff, climate.temperature, settings.lakePercent);
  const rivers = H.findRivers(grid, flow, elevation, balance, ocean, runoff, settings.riverDensityPercent);
  lap("hydrology");
  const surface = G.surface.buildSurface(
    grid, seed, elevation, seaLevel, ocean, flow, rivers, climate.temperature, climate.precipitation, biomes,
  );
  const stagedHash: string = G.hash.hashPlanetFields(faceLevel, surface);
  lap("surface+hash");

  // ── 2) 복제본 ──
  const st = shadowTectonics(G, grid, seed, settings);
  lap("shadowTectonics");
  const sc = shadowClimate(G, grid, preErosion, seaLevel, ocean, settings);
  lap("shadowClimate");
  const sw = shadowWaterBalance(G, grid, flow, elevation, runoff, climate.temperature, settings.lakePercent);
  lap("shadowWaterBalance");

  // ── 공식 실행 대조 ──
  let officialHash: string | null = null;
  let detailsMatch: boolean | null = null;
  if (verify) {
    const official = G.index.runPlanetGenerator(input);
    officialHash = official.fields.meta.hash;
    detailsMatch = mismatches(official.receiver, flow.receiver) === 0 && mismatches(official.basinKind, rivers.basinKind) === 0;
    lap("officialRun");
  }
  const knownHash = KNOWN_HASHES[`${planetId}:${seed}:${faceLevel}`] ?? null;
  const verification: any = {
    stagedHash,
    officialHash,
    knownHash,
    stagedMatchesOfficial: officialHash === null ? null : officialHash === stagedHash,
    officialMatchesKnown: knownHash === null || officialHash === null ? null : officialHash === knownHash,
    detailsMatchOfficial: detailsMatch,
    tectonicsElevationMismatches: mismatches(st.elevation, tectonicElevation),
    tectonicsPlateMismatches: mismatches(st.plate, tect.plate),
    tectonicsContinentalMismatches: mismatches(st.continental, tect.continental),
    climateTemperatureMismatches: mismatches(sc.temperature, climate.temperature),
    climatePrecipitationMismatches: mismatches(sc.precipitation, climate.precipitation),
    climateOceanDistanceMismatches: mismatches(sc.oceanDistance, climate.oceanDistance),
    hydrologyDischargeMismatches: mismatches(sw.discharge, balance.discharge),
    hydrologyBasinStateMismatches: mismatches(sw.basinState, balance.basinState),
    humidityReplicaMismatches: -1,
  };

  // ── 3) 배열 모으기 ──
  const F: Record<string, TypedArray> = {};
  for (const spec of FIELD_SPECS) F[spec.name] = allocate(spec.dtype, count);
  const put = (name: string, source: ArrayLike<number>) => {
    const target = F[name];
    if (!target) throw new Error(`unknown field ${name}`);
    for (let c = 0; c < count; c++) target[c] = source[c] as number;
  };
  // 위치
  const faceCells: number = grid.faceCells;
  for (let c = 0; c < count; c++) {
    const face = Math.floor(c / faceCells);
    const rest = c - face * faceCells;
    const j = Math.floor(rest / n);
    F.face[c] = face;
    F.j[c] = j;
    F.i[c] = rest - j * n;
    F.longitudeDeg[c] = (Math.atan2(grid.y[c], grid.x[c]) * 180) / Math.PI;
    F.cellAreaKm2[c] = areaOf(grid, c) * RKM * RKM;
  }
  put("latitudeDeg", sc.latitudeDeg);
  for (let c = 0; c < count; c++) F.absLatDeg[c] = Math.abs(sc.latitudeDeg[c] as number);
  // 최종
  for (const name of ["elevationM", "biome", "temperatureC", "precipitationMm", "humidity", "water", "river", "forest"]) {
    put(name, surface[name]);
  }
  const DEPTH_SHIFT: number = G.index.DEPTH_CLASS_SHIFT;
  for (let c = 0; c < count; c++) {
    const w = surface.water[c] as number;
    F.ocean[c] = w & 1 ? 1 : 0;
    F.lake[c] = w & 2 ? 1 : 0;
    F.riverCell[c] = w & 4 ? 1 : 0;
    F.coast[c] = w & 8 ? 1 : 0;
    F.depthClass[c] = (w >> DEPTH_SHIFT) & 3;
    F.land[c] = w & 3 ? 0 : 1;
    F.realElevationM[c] = (surface.elevationM[c] as number) * 12;
  }
  // 부가 정보·단계 반환값
  put("receiver", flow.receiver);
  put("basinKind", rivers.basinKind);
  put("plate", tect.plate);
  put("continental", tect.continental);
  const CELL_LAKE: number = H.CELL_LAKE;
  const CELL_FILLED: number = H.CELL_FILLED;
  const CELL_DRY: number = H.CELL_DRY;
  const ground = new Float32Array(count);
  for (let c = 0; c < count; c++) {
    const kind = rivers.basinKind[c] as number;
    const g = kind === CELL_FILLED || kind === CELL_DRY ? (flow.filled[c] as number) : (elevation[c] as number);
    ground[c] = g;
    F.preErosionElevRealM[c] = (preErosion[c] as number) - seaLevel;
    F.finalElevRealM[c] = (elevation[c] as number) - seaLevel;
    F.groundElevRealM[c] = g - seaLevel;
    F.erosionRealM[c] = (preErosion[c] as number) - (elevation[c] as number);
    F.filledRealM[c] = (flow.filled[c] as number) - seaLevel;
    const depth = Math.max(0, (flow.filled[c] as number) - (elevation[c] as number));
    F.depressionDepthRealM[c] = depth;
    F.lakeDepthRealM[c] = kind === CELL_LAKE ? depth : 0;
    const b = flow.basin[c] as number;
    F.basinId[c] = b;
    F.basinExit[c] = b >= 0 ? (flow.basinExit[b] as number) : -1;
    F.basinState[c] = b >= 0 ? (balance.basinState[b] as number) : 255;
    if (b >= 0) {
      F.basinAreaKm2[c] = sw.basinAreaKm2[b] as number;
      F.basinMaxDepthRealM[c] = sw.basinMaxDepthM[b] as number;
      F.basinInflowKm3[c] = sw.basinInflowKm3[b] as number;
      F.basinEvaporationKm3[c] = sw.basinEvaporationKm3[b] as number;
      const evaporation = sw.basinEvaporationKm3[b] as number;
      F.basinWaterRatio[c] = evaporation > 0 ? (sw.basinInflowKm3[b] as number) / evaporation : Number.POSITIVE_INFINITY;
    }
    F.oceanDepthRealM[c] = ocean[c] === 1 ? seaLevel - (elevation[c] as number) : 0;
  }
  put("temperatureExactC", climate.temperature);
  put("precipitationExactMm", climate.precipitation);
  for (let c = 0; c < count; c++) F.distToOceanKm[c] = (climate.oceanDistance[c] as number) * RKM;
  put("runoffMm", runoff);
  put("dischargeKm3", balance.discharge);
  // 복제: 판 구조
  for (const name of [
    "crustNoise", "crustRank", "plateBoundary", "neighborPlate", "convergence", "shear", "boundaryFeatureRaw",
    "boundaryStrengthRaw", "midOceanRidge", "boundarySlot", "boundaryDistKm", "boundarySource", "wCollision",
    "wAndean", "wTrench", "wArc", "wRift", "boundaryAlong", "ridgeTexture", "ridgeDistKm", "shelfDistKm",
    "crustBaseRealM", "reliefNoiseRealM", "collisionRealM", "andeanRealM", "andeanVolcanicRealM", "trenchRealM",
    "islandArcRealM", "riftRealM", "hotspotRealM", "hotspotNearestKm", "hotspotStep", "hotspotId",
  ]) {
    put(name, (st as any)[name]);
  }
  for (let c = 0; c < count; c++) {
    const arcs = (st.andeanVolcanicRealM[c] as number) + (st.islandArcRealM[c] as number);
    F.upliftRealM[c] = (st.collisionRealM[c] as number) + (st.andeanRealM[c] as number) + arcs;
    F.volcanicRealM[c] = arcs + (st.hotspotRealM[c] as number);
    // 경계 분류: 상대 속도의 큰 쪽 성분(생성기는 수렴 부호만 쓴다)
    const conv = st.convergence[c] as number;
    const sh = st.shear[c] as number;
    if (st.plateBoundary[c] === 1 && Number.isFinite(conv) && Number.isFinite(sh)) {
      F.boundaryClass[c] = Math.abs(sh) > Math.abs(conv) ? 3 : conv > 0 ? 1 : 2;
    }
  }
  // 복제: 기후
  for (const name of [
    "seaLevelTempC", "windU", "windV", "upwindCell", "orographicRise", "orographicLift", "moistureArriving",
    "moistureCoastal", "moisture", "convectiveBase", "zonalPrecipMm", "moistureArrivingNoOro",
  ]) {
    put(name, (sc as any)[name]);
  }
  put("precipitationNoOroMm", sc.precipitationNoOro);
  for (let c = 0; c < count; c++) {
    const p = sc.precipitation[c] as number;
    const p0 = sc.precipitationNoOro[c] as number;
    F.rainShadow[c] = p0 > 0 ? Math.max(0, 1 - p / p0) : 0;
  }
  // 바람 아래 산줄기: 바람이 오는 쪽으로 500km(실제 환산) 안의 가장 높은 땅(바다는 해수면) − 자기 땅
  {
    const surfaceOf = (c: number) => Math.max(seaLevel, ocean[c] === 1 ? seaLevel : (ground[c] as number));
    for (let c = 0; c < count; c++) {
      let best = Number.NEGATIVE_INFINITY;
      let cur = c;
      let travelled = 0;
      for (let step = 0; step < 512; step++) {
        const up = sc.upwindCell[cur] as number;
        if (up === cur) break;
        travelled += chordBetween(grid, cur, up) * RKM;
        if (travelled > 500) break;
        best = Math.max(best, surfaceOf(up));
        cur = up;
      }
      F.leeRidgeRealM[c] = Number.isFinite(best) ? Math.max(0, best - surfaceOf(c)) : 0;
    }
  }
  lap("collect");

  // ── 새로 계산 ──
  const out = new Int32Array(8);
  const reachAngle = G.riparian.RIPARIAN_REACH + 2 * grid.meanCellAngle;
  const overLand = (_from: number, to: number) => ocean[to] !== 1;
  const nearRiver = G.queues.distanceField(grid, (c: number) => (rivers.order[c] as number) > 0, reachAngle, overLand);
  const nearLake = G.queues.distanceField(grid, (c: number) => rivers.basinKind[c] === CELL_LAKE, reachAngle, overLand);
  let humidityReplicaMismatches = 0;
  for (let c = 0; c < count; c++) {
    const t = surface.temperatureC[c] as number;
    const pet = H.potentialEvaporation(t);
    F.potentialEvapMm[c] = pet;
    const isWater = (surface.water[c] as number) & 3;
    F.aridityIndex[c] = isWater ? 0 : (climate.precipitation[c] as number) / pet;
    // surface.ts(c08f84f) 강가·호숫가 가산 복제: 띠 몫(riparian.ts) × 강 길이 몫
    if (!(ocean[c] === 1) && rivers.basinKind[c] !== CELL_LAKE) {
      const size = Math.sqrt(areaOf(grid, c));
      let nearWater = 0;
      const riverCell = nearRiver.source[c] as number;
      if (riverCell >= 0) {
        const share = G.riparian.riverShare(nearRiver.angle[c] as number, size) * (rivers.length[riverCell] as number);
        nearWater = G.riparian.riverBonus(rivers.order[riverCell] as number) * share;
      }
      if ((nearLake.source[c] as number) >= 0) {
        nearWater = Math.max(nearWater, G.riparian.LAKE_SHORE_BONUS * G.riparian.lakeShare(nearLake.angle[c] as number, size));
      }
      F.nearWaterBonus[c] = nearWater;
      const aridity = (climate.precipitation[c] as number) / pet;
      const h = Math.min(255, Math.max(0, Math.round((255 * aridity) / (aridity + 0.75) + nearWater)));
      F.humidityDry[c] = Math.min(255, Math.max(0, Math.round((255 * aridity) / (aridity + 0.75))));
      if (h !== (surface.humidity[c] as number)) humidityReplicaMismatches++;
      F.riverLengthShare[c] = rivers.length[c] as number;
    }
    // 경사·기복 (실제 환산 m / 실제 환산 km)
    neighbors8(grid, c, out);
    const here = ground[c] as number;
    let maxSlope = 0;
    let lo = here;
    let hi = here;
    for (let k = 0; k < 8; k++) {
      const next = out[k] as number;
      if (next < 0) continue;
      const other = ground[next] as number;
      const dKm = chordBetween(grid, c, next) * RKM;
      maxSlope = Math.max(maxSlope, Math.abs(other - here) / dKm);
      lo = Math.min(lo, other);
      hi = Math.max(hi, other);
    }
    F.slopeMPerKm[c] = maxSlope;
    F.reliefRealM[c] = hi - lo;
    const r = flow.receiver[c] as number;
    if (r >= 0) {
      const below = ocean[r] === 1 ? seaLevel : (ground[r] as number);
      F.downslopeMPerKm[c] = Math.max(0, here - below) / (chordBetween(grid, c, r) * RKM);
    }
    // 하구
    if ((rivers.order[c] as number) > 0 && r >= 0) {
      if (ocean[r] === 1) F.riverMouth[c] = 1;
      else if (rivers.basinKind[r] === CELL_LAKE) F.riverMouth[c] = 2;
      else if (rivers.basinKind[r] === CELL_DRY) F.riverMouth[c] = 3;
    }
  }
  // 상류 면적·내륙 유역: flow.order는 하류 → 상류(받는 칸이 앞)
  const area = F.drainageAreaKm2 as Float32Array;
  for (let c = 0; c < count; c++) area[c] = F.cellAreaKm2[c] as number;
  for (let k = flow.orderLength - 1; k >= 0; k--) {
    const c = flow.order[k] as number;
    const r = flow.receiver[c] as number;
    if (r >= 0) area[r] = (area[r] as number) + (area[c] as number);
  }
  for (let k = 0; k < flow.orderLength; k++) {
    const c = flow.order[k] as number;
    const r = flow.receiver[c] as number;
    if (rivers.basinKind[c] === CELL_DRY) F.endorheic[c] = 1;
    else if (r >= 0 && ocean[r] !== 1 && F.endorheic[r] === 1) F.endorheic[c] = 1;
  }
  // 거리장(생성기 distanceField, 상한 2500km)
  const distKm = (name: string, isSource: (c: number) => boolean) => {
    const field = G.queues.distanceField(grid, isSource, G.util.km(DIST_CAP_KM));
    const target = F[name] as Float32Array;
    for (let c = 0; c < count; c++) target[c] = (field.angle[c] as number) * RKM;
  };
  distKm("distToLandKm", (c) => ocean[c] !== 1);
  distKm("distToRiverKm", (c) => (rivers.order[c] as number) > 0);
  distKm("distToLakeKm", (c) => rivers.basinKind[c] === CELL_LAKE);
  distKm("distToRiverMouthKm", (c) => F.riverMouth[c] === 1);
  distKm("distToPlateBoundaryKm", (c) => st.plateBoundary[c] === 1);
  verification.humidityReplicaMismatches = humidityReplicaMismatches;
  lap("derived");

  const biomeEntries = entriesOf(G.root, "biomes.json");
  const meta: PlanetMetaInfo = {
    harnessVersion: HARNESS_VERSION,
    planetId,
    seed,
    faceLevel,
    n,
    cellCount: count,
    generatorVersion: G.version.GENERATOR_VERSION,
    hash: stagedHash,
    settings,
    biomeIds: biomes.map((b: any) => b.id),
    biomeColors: biomes.map((b: any) => biomeEntries.find((e) => e.id === b.id)?.color ?? "#ff00ff"),
    seaLevelRealM: seaLevel,
    crustThreshold: st.crustThreshold,
    riverThresholdKm3: settings.riverDensityPercent > 0 ? (12 * 100) / settings.riverDensityPercent : Number.POSITIVE_INFINITY,
    plateCount: st.plateCount,
    rotation: st.rotation,
    hotspots: st.hotspots,
    root: G.root,
    fingerprint,
    verification,
    timingsMs: timings,
    fromCache: false,
  };
  log(`generated ${planetId} seed ${seed} F${faceLevel}: hash ${stagedHash} (${Object.values(timings).reduce((a, b) => a + b, 0)} ms)`);
  return { meta, fields: F, grid, G };
}
