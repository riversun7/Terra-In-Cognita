// 기후 단계 복제본 — climate.ts computeClimate(70~200행)를 연산 순서까지 그대로 따라 하면서 지역 변수(위도, 바람, 바람이 오는
// 칸, 오르막, 도착 습기, 해안 습기, 대류 몫)를 남긴다. 결과 기온·강수는 생성기 값과 비트까지 같아야 한다(planet.ts가 대조).
// 더해서(생성기에는 없음): 오르막 습기 손실을 끈 두 번째 바람길(같은 두 배 뛰기) → 비그늘 지수.
import type { GeneratorModules } from "./load.ts";

// climate.ts 15~33행 상수 (OROGRAPHIC_* 등은 내보내지 않아서 옮겨 적음)
const DEGREES_PER_RADIAN = 180 / Math.PI;
const RADIANS_PER_DEGREE = Math.PI / 180;

export interface ShadowClimate {
  readonly latitudeDeg: Float32Array;
  readonly seaLevelTempC: Float32Array;
  readonly temperature: Float32Array;
  readonly windU: Float32Array;
  readonly windV: Float32Array;
  readonly upwindCell: Int32Array;
  readonly orographicRise: Float32Array;
  readonly orographicLift: Float32Array;
  readonly moistureArriving: Float32Array;
  readonly moistureArrivingNoOro: Float32Array;
  readonly moistureCoastal: Float32Array;
  readonly moisture: Float32Array;
  readonly convectiveBase: Float32Array;
  readonly zonalPrecipMm: Float32Array;
  readonly precipitation: Float32Array;
  readonly precipitationNoOro: Float32Array;
  readonly oceanDistance: Float32Array;
}

export function shadowClimate(
  G: GeneratorModules,
  grid: any,
  elevation: Float32Array,
  seaLevel: number,
  ocean: Uint8Array,
  settings: any,
): ShadowClimate {
  const { detAsin, detExp } = G.shared;
  const { neighbors8 } = G.grid;
  const C = G.climate;
  const U = G.util;
  const km: (v: number) => number = U.km;
  const clamp: (v: number, a: number, b: number) => number = U.clamp;
  const REFERENCE_RADIUS_M = U.REFERENCE_RADIUS_KM * 1000;
  const LAPSE_RATE_PER_M: number = C.LAPSE_RATE_PER_M;
  const OCEAN_RECHARGE = km(350);
  const LAND_DEPLETION = km(3000);
  const OROGRAPHIC_DEPLETION_PER_KM = 1.1;
  const OROGRAPHIC_GAIN = 45;
  const OROGRAPHIC_MAX = 2.5;
  const COASTAL_REACH = km(450);
  const WIND_PATH = km(4500);

  const count: number = grid.cellCount;
  const temperature = new Float32Array(count);
  const latitude = new Float32Array(count);
  const seaLevelTempC = new Float32Array(count);
  const equator = settings.equatorTemperatureC;
  const span = settings.equatorTemperatureC - settings.poleTemperatureC;
  for (let c = 0; c < count; c++) {
    const degrees = detAsin(clamp(grid.z[c] ?? 0, -1, 1)) * DEGREES_PER_RADIAN;
    latitude[c] = degrees;
    const t = Math.abs(degrees) / 90;
    const seaLevelTemperature = equator - span * t * Math.sqrt(t);
    seaLevelTempC[c] = seaLevelTemperature;
    const altitude = Math.max(0, (elevation[c] ?? 0) - seaLevel);
    temperature[c] = seaLevelTemperature - LAPSE_RATE_PER_M * altitude;
  }

  const upwind = new Int32Array(count);
  const windU = new Float32Array(count);
  const windV = new Float32Array(count);
  const out = new Int32Array(8);
  for (let c = 0; c < count; c++) {
    const x = grid.x[c] ?? 0;
    const y = grid.y[c] ?? 0;
    const z = grid.z[c] ?? 0;
    upwind[c] = c;
    const horizontal = Math.sqrt(x * x + y * y);
    if (horizontal < 1e-6) continue;
    const ex = -y / horizontal;
    const ey = x / horizontal;
    const nx = -z * ey;
    const ny = z * ex;
    const nz = x * ey - y * ex;
    const { u, v } = C.windAt(latitude[c] ?? 0);
    windU[c] = u;
    windV[c] = v;
    const wx = -(u * ex + v * nx);
    const wy = -(u * ey + v * ny);
    const wz = -v * nz;
    const strength = Math.sqrt(wx * wx + wy * wy + wz * wz);
    if (strength < 0.05) continue;
    neighbors8(grid, c, out);
    let best = -1;
    let bestScore = 0.3;
    for (let k = 0; k < 8; k++) {
      const next = out[k] ?? -1;
      if (next < 0) continue;
      const dx = (grid.x[next] ?? 0) - x;
      const dy = (grid.y[next] ?? 0) - y;
      const dz = (grid.z[next] ?? 0) - z;
      const length = Math.sqrt(dx * dx + dy * dy + dz * dz);
      const score = (dx * wx + dy * wy + dz * wz) / (length * strength);
      if (score > bestScore) {
        bestScore = score;
        best = next;
      }
    }
    if (best >= 0) upwind[c] = best;
  }

  const chord = (a: number, b: number): number => {
    const dx = (grid.x[a] ?? 0) - (grid.x[b] ?? 0);
    const dy = (grid.y[a] ?? 0) - (grid.y[b] ?? 0);
    const dz = (grid.z[a] ?? 0) - (grid.z[b] ?? 0);
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  };

  let mapA = new Float32Array(count);
  let mapB = new Float32Array(count);
  // 두 번째 바람길: 오르막 손실 항(OROGRAPHIC_DEPLETION)만 뺀 것
  let mapA2 = new Float32Array(count);
  let mapB2 = new Float32Array(count);
  const rise = new Float32Array(count);
  for (let c = 0; c < count; c++) {
    const from = upwind[c] ?? c;
    if (from === c) {
      mapA[c] = 0;
      mapB[c] = ocean[c] === 1 ? 1 : 0.2;
      mapA2[c] = 0;
      mapB2[c] = mapB[c] ?? 0;
      continue;
    }
    const step = chord(c, from);
    if (ocean[c] === 1) {
      const keep = detExp(-step / OCEAN_RECHARGE);
      mapA[c] = keep;
      mapB[c] = 1 - keep;
      mapA2[c] = keep;
      mapB2[c] = 1 - keep;
    } else {
      const here = Math.max(seaLevel, elevation[c] ?? 0);
      const there = Math.max(seaLevel, elevation[from] ?? 0);
      const climb = Math.max(0, here - there);
      rise[c] = climb / (step * REFERENCE_RADIUS_M);
      const tropics = (latitude[c] ?? 0) / 14;
      const reach = LAND_DEPLETION * (1 + 1.5 * detExp(-tropics * tropics));
      mapA[c] = detExp(-step / reach - (OROGRAPHIC_DEPLETION_PER_KM * climb) / 1000);
      mapB[c] = 0;
      mapA2[c] = detExp(-step / reach);
      mapB2[c] = 0;
    }
  }
  let jump = Int32Array.from(upwind);
  let nextA = new Float32Array(count);
  let nextB = new Float32Array(count);
  let nextA2 = new Float32Array(count);
  let nextB2 = new Float32Array(count);
  let nextJump = new Int32Array(count);
  for (let covered = grid.meanCellAngle; covered < WIND_PATH; covered *= 2) {
    for (let c = 0; c < count; c++) {
      const far = jump[c] ?? c;
      const a = mapA[c] ?? 0;
      nextA[c] = a * (mapA[far] ?? 0);
      nextB[c] = a * (mapB[far] ?? 0) + (mapB[c] ?? 0);
      const a2 = mapA2[c] ?? 0;
      nextA2[c] = a2 * (mapA2[far] ?? 0);
      nextB2[c] = a2 * (mapB2[far] ?? 0) + (mapB2[c] ?? 0);
      nextJump[c] = jump[far] ?? far;
    }
    [mapA, nextA] = [nextA, mapA];
    [mapB, nextB] = [nextB, mapB];
    [mapA2, nextA2] = [nextA2, mapA2];
    [mapB2, nextB2] = [nextB2, mapB2];
    [jump, nextJump] = [nextJump, jump];
  }

  // climate.ts 202~223행 blur
  const blur = (field: Float32Array, passes: number): Float32Array => {
    let current = field;
    let next = new Float32Array(field.length);
    const nb = new Int32Array(8);
    for (let pass = 0; pass < passes; pass++) {
      for (let c = 0; c < grid.cellCount; c++) {
        neighbors8(grid, c, nb);
        let sum = current[c] ?? 0;
        let weight = 1;
        for (let k = 0; k < 8; k++) {
          const other = nb[k] ?? -1;
          if (other < 0) continue;
          sum += current[other] ?? 0;
          weight++;
        }
        next[c] = sum / weight;
      }
      [current, next] = [next, current];
    }
    return current;
  };

  let arriving = new Float32Array(count);
  let arriving2 = new Float32Array(count);
  for (let c = 0; c < count; c++) {
    const from = upwind[c] ?? c;
    arriving[c] = from === c ? (mapB[c] ?? 0) : (mapB[from] ?? 0);
    arriving2[c] = from === c ? (mapB2[c] ?? 0) : (mapB2[from] ?? 0);
  }
  const passes = Math.max(1, 2 * (grid.faceLevel - 5));
  arriving = blur(arriving, passes);
  arriving2 = blur(arriving2, passes);
  const coast = G.queues.distanceField(grid, (c: number) => ocean[c] === 1, km(2500));
  const precipitation = new Float32Array(count);
  const precipitationNoOro = new Float32Array(count);
  const moistureCoastal = new Float32Array(count);
  const moisture = new Float32Array(count);
  const orographicLift = new Float32Array(count);
  const convectiveBase = new Float32Array(count);
  const zonalPrecipMm = new Float32Array(count);
  const scale = settings.precipitationPercent / 100;
  for (let c = 0; c < count; c++) {
    const coastal = 0.55 * detExp(-(coast.angle[c] ?? 0) / COASTAL_REACH);
    const m = Math.max(arriving[c] ?? 0, coastal);
    const lift = ocean[c] === 1 ? 0 : Math.min(OROGRAPHIC_MAX, OROGRAPHIC_GAIN * (rise[c] ?? 0));
    const equatorial = (latitude[c] ?? 0) / 12;
    const base = 0.12 + 0.3 * detExp(-equatorial * equatorial);
    const zonal = C.zonalPrecipitation(latitude[c] ?? 0);
    const value = scale * zonal * (base + (1 - base) * m) * (1 + lift);
    precipitation[c] = clamp(value, 0, 12_000);
    const m2 = Math.max(arriving2[c] ?? 0, coastal);
    precipitationNoOro[c] = clamp(scale * zonal * (base + (1 - base) * m2) * (1 + lift), 0, 12_000);
    moistureCoastal[c] = coastal;
    moisture[c] = m;
    orographicLift[c] = lift;
    convectiveBase[c] = base;
    zonalPrecipMm[c] = zonal;
  }
  return {
    latitudeDeg: latitude,
    seaLevelTempC,
    temperature,
    windU,
    windV,
    upwindCell: upwind,
    orographicRise: rise,
    orographicLift,
    moistureArriving: arriving,
    moistureArrivingNoOro: arriving2,
    moistureCoastal,
    moisture,
    convectiveBase,
    zonalPrecipMm,
    precipitation,
    precipitationNoOro,
    oceanDistance: coast.angle,
  };
}
