// 물 수지 복제본 — hydrology.ts waterBalance(63~123행)를 연산 순서까지 그대로 따라 하면서 웅덩이별 지역 변수(면적, 최대 깊이,
// 수면 증발, 들어온 물)를 남긴다. 누적 유량(discharge)은 생성기 값과 비트까지 같아야 한다(planet.ts가 대조).
import type { GeneratorModules } from "./load.ts";

export interface ShadowWaterBalance {
  readonly discharge: Float64Array;
  readonly basinState: Uint8Array;
  /** 웅덩이별(번호 = flood.ts basin) */
  readonly basinAreaKm2: Float64Array;
  readonly basinMaxDepthM: Float32Array;
  /** 수면 증발(km³/년) × 호수 보존 배율(100 / lakePercent) — 판정에 쓴 값 */
  readonly basinEvaporationKm3: Float64Array;
  readonly basinInflowKm3: Float64Array;
}

export function shadowWaterBalance(
  G: GeneratorModules,
  grid: any,
  flow: any,
  elevation: Float32Array,
  runoff: Float32Array,
  temperature: Float32Array,
  lakePercent: number,
): ShadowWaterBalance {
  const R: number = G.util.REFERENCE_RADIUS_KM;
  const { areaOf } = G.grid;
  // hydrology.ts 13~20행 상수, 28~30행 lakeEvaporation (내보내지 않아서 옮겨 적음)
  const KM3_PER_MM_SR = 1e-6 * R * R;
  const KM2_PER_SR = R * R;
  const LAKE_MIN_DEPTH_M = 35;
  const LAKE_MIN_AREA_KM2 = 3000;
  const BASIN_FILLED = 0;
  const BASIN_LAKE = 1;
  const BASIN_DRY = 2;
  const lakeEvaporation = (t: number) => Math.min(1800, Math.max(0, 45 * (t + 6)));

  const count: number = grid.cellCount;
  const { receiver, filled, order, orderLength, basin, basinExit, basinCount } = flow;
  const basinArea = new Float64Array(basinCount);
  const basinEvaporation = new Float64Array(basinCount);
  const basinDepth = new Float32Array(basinCount);
  for (let c = 0; c < count; c++) {
    const b = basin[c] ?? -1;
    if (b < 0) continue;
    const depth = (filled[c] ?? 0) - (elevation[c] ?? 0);
    if (depth <= 0) continue;
    const area = areaOf(grid, c);
    basinArea[b] = (basinArea[b] ?? 0) + area;
    basinEvaporation[b] = (basinEvaporation[b] ?? 0) + lakeEvaporation(temperature[c] ?? 0) * area * KM3_PER_MM_SR;
    basinDepth[b] = Math.max(basinDepth[b] ?? 0, depth);
  }
  const exitOf = new Int32Array(count).fill(-1);
  for (let b = 0; b < basinCount; b++) exitOf[basinExit[b] ?? 0] = b;
  const basinState = new Uint8Array(basinCount);
  const basinInflow = new Float64Array(basinCount);
  const evaporationScale = lakePercent > 0 ? 100 / lakePercent : Number.POSITIVE_INFINITY;
  const discharge = new Float64Array(count);
  for (let c = 0; c < count; c++) discharge[c] = (runoff[c] ?? 0) * areaOf(grid, c) * KM3_PER_MM_SR;
  for (let k = orderLength - 1; k >= 0; k--) {
    const c = order[k] ?? 0;
    const exiting = exitOf[c] ?? -1;
    if (exiting >= 0) {
      const inflow = basinInflow[exiting] ?? 0;
      const lakeSized =
        (basinDepth[exiting] ?? 0) >= LAKE_MIN_DEPTH_M && (basinArea[exiting] ?? 0) * KM2_PER_SR >= LAKE_MIN_AREA_KM2;
      if (!lakeSized) {
        basinState[exiting] = BASIN_FILLED;
        discharge[c] = (discharge[c] ?? 0) + inflow;
      } else {
        const evaporation = (basinEvaporation[exiting] ?? 0) * evaporationScale;
        if (inflow >= evaporation) {
          basinState[exiting] = BASIN_LAKE;
          discharge[c] = (discharge[c] ?? 0) + inflow - evaporation;
        } else {
          basinState[exiting] = BASIN_DRY;
        }
      }
    }
    const r = receiver[c] ?? -1;
    if (r < 0) continue;
    const b = basin[c] ?? -1;
    if (b >= 0 && basin[r] !== b) basinInflow[b] = (basinInflow[b] ?? 0) + (discharge[c] ?? 0);
    else discharge[r] = (discharge[r] ?? 0) + (discharge[c] ?? 0);
  }
  const areaKm2 = new Float64Array(basinCount);
  const evaporationKm3 = new Float64Array(basinCount);
  for (let b = 0; b < basinCount; b++) {
    areaKm2[b] = (basinArea[b] ?? 0) * KM2_PER_SR;
    evaporationKm3[b] = (basinEvaporation[b] ?? 0) * evaporationScale;
  }
  return {
    discharge,
    basinState,
    basinAreaKm2: areaKm2,
    basinMaxDepthM: basinDepth,
    basinEvaporationKm3: evaporationKm3,
    basinInflowKm3: basinInflow,
  };
}
