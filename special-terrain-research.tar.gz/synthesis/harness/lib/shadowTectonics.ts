// 판 구조 단계 복제본 — tectonics.ts buildTectonics(84~274행)를 연산 순서까지 그대로 따라 하면서 지역 변수(판 경계 종류·
// 세기·거리, 지각 순위, 고도 항목별 기여, 열점)를 배열로 남긴다. 결과 고도는 생성기 buildTectonics와 비트까지 같아야 한다
// (planet.ts가 대조한다). 모듈 내부 함수(cornerProximity·bump·continentalRank)와 상수는 원본을 옮겨 적었다.
import type { GeneratorModules } from "./load.ts";

// tectonics.ts 45~54행 상수 (내보내지 않아서 옮겨 적음)
const CONVERGENCE_REFERENCE = 0.55;
const CORNER_PUSH_RADIUS = 0.035;
const CORNER_PUSH = 0.3;

export interface HotspotInfo {
  /** 열점 번호(생성 순서) */
  readonly id: number;
  /** 사슬 첫 화산(가장 젊은, step 0)의 격자 좌표 위도·경도(도) */
  readonly latDeg: number;
  readonly lonDeg: number;
  /** 대륙 지각 위면 1 (높이 0.35배) */
  readonly continental: boolean;
  /** step 0 화산 높이(실제 환산 m) */
  readonly peakRealM: number;
}

export interface ShadowTectonics {
  readonly plate: Uint8Array;
  readonly continental: Uint8Array;
  readonly crustNoise: Float32Array;
  readonly crustThreshold: number;
  readonly crustRank: Float32Array;
  readonly plateBoundary: Uint8Array;
  readonly neighborPlate: Int16Array;
  readonly convergence: Float32Array;
  readonly shear: Float32Array;
  readonly boundaryFeatureRaw: Uint8Array;
  readonly boundaryStrengthRaw: Float32Array;
  readonly midOceanRidge: Uint8Array;
  readonly boundarySlot: Int32Array;
  readonly boundaryDistKm: Float32Array;
  readonly boundarySource: Int32Array;
  readonly wCollision: Float32Array;
  readonly wAndean: Float32Array;
  readonly wTrench: Float32Array;
  readonly wArc: Float32Array;
  readonly wRift: Float32Array;
  readonly boundaryAlong: Float32Array;
  readonly ridgeTexture: Float32Array;
  readonly ridgeDistKm: Float32Array;
  readonly shelfDistKm: Float32Array;
  readonly crustBaseRealM: Float32Array;
  readonly reliefNoiseRealM: Float32Array;
  readonly collisionRealM: Float32Array;
  readonly andeanRealM: Float32Array;
  readonly andeanVolcanicRealM: Float32Array;
  readonly trenchRealM: Float32Array;
  readonly islandArcRealM: Float32Array;
  readonly riftRealM: Float32Array;
  readonly hotspotRealM: Float32Array;
  readonly hotspotNearestKm: Float32Array;
  readonly hotspotStep: Uint8Array;
  readonly hotspotId: Uint8Array;
  /** 복제한 판 구조 고도(실제 환산 m, 해수면 전 절대값) — 생성기 값과 대조용 */
  readonly elevation: Float32Array;
  readonly hotspots: readonly HotspotInfo[];
  readonly plateCount: number;
  /** 무늬 공간 회전(행 우선 3×3) */
  readonly rotation: readonly number[];
}

export function shadowTectonics(G: GeneratorModules, grid: any, seed: number, settings: any): ShadowTectonics {
  const P = G.plates;
  const Bd = G.boundaries;
  const Hs = G.hotspots;
  const N = G.noise;
  const Q = G.queues;
  const R = G.random;
  const U = G.util;
  const { neighbors8, areaOf } = G.grid;
  const { CUBE_CORNERS } = G.corners;
  const { detExp } = G.shared;
  const km: (v: number) => number = U.km;
  const smoothstep: (a: number, b: number, v: number) => number = U.smoothstep;
  const RKM: number = U.REFERENCE_RADIUS_KM;
  const BOUNDARY_REACH = km(700);

  // tectonics.ts 66~74행
  const cornerProximity = (x: number, y: number, z: number, radius: number): number => {
    let best = 0;
    for (const corner of CUBE_CORNERS) {
      const [sx, sy, sz] = corner.axisSigns;
      best = Math.max(best, (sx * x + sy * y + sz * z) / Math.sqrt(3));
    }
    return detExp(-(2 - 2 * best) / (radius * radius));
  };
  // tectonics.ts 77~82행
  const bump = (d: number, center: number, halfWidth: number): number => {
    const t = (d - center) / halfWidth;
    if (t <= -1 || t >= 1) return 0;
    const s = 1 - t * t;
    return s * s;
  };
  // tectonics.ts 277~310행
  const continentalRank = (value: Float32Array, continental: Uint8Array): Float32Array => {
    const rank = new Float32Array(grid.cellCount);
    let min = Number.POSITIVE_INFINITY;
    let max = Number.NEGATIVE_INFINITY;
    for (let c = 0; c < grid.cellCount; c++) {
      if (continental[c] !== 1) continue;
      min = Math.min(min, value[c] ?? 0);
      max = Math.max(max, value[c] ?? 0);
    }
    if (!(max > min)) return rank;
    const bins = 4096;
    const cumulative = new Float64Array(bins + 1);
    const binOf = (v: number) => Math.min(bins - 1, Math.floor(((v - min) / (max - min)) * bins));
    let total = 0;
    for (let c = 0; c < grid.cellCount; c++) {
      if (continental[c] !== 1) continue;
      const area = areaOf(grid, c);
      const bin = binOf(value[c] ?? 0) + 1;
      cumulative[bin] = (cumulative[bin] ?? 0) + area;
      total += area;
    }
    for (let b = 1; b <= bins; b++) cumulative[b] = (cumulative[b] ?? 0) + (cumulative[b - 1] ?? 0);
    for (let c = 0; c < grid.cellCount; c++) {
      if (continental[c] !== 1) continue;
      const v = value[c] ?? 0;
      const b = binOf(v);
      const below = cumulative[b] ?? 0;
      const inside = (cumulative[b + 1] ?? 0) - below;
      const fraction = ((v - min) / (max - min)) * bins - b;
      rank[c] = (below + inside * Math.min(1, Math.max(0, fraction))) / total;
    }
    return rank;
  };

  const count: number = grid.cellCount;
  const continentalShare = Math.min(0.97, (settings.landPercent + settings.shelfPercent) / 100);
  const plates = P.createPlates(seed, settings.plateCount, continentalShare);
  const warpSeed = R.streamSeed(seed, R.STREAM_PLATE_WARP);
  const continentSeed = R.streamSeed(seed, R.STREAM_CONTINENTS);
  const uplift = settings.upliftPercent / 100;
  const rugged = settings.ruggednessPercent / 100;
  const volcanism = settings.volcanismPercent / 100;

  const rotation = P.chooseRotation(seed, plates, warpSeed, continentSeed);
  const sx = new Float64Array(count);
  const sy = new Float64Array(count);
  const sz = new Float64Array(count);
  for (let c = 0; c < count; c++) {
    const [x, y, z] = P.rotate(rotation, grid.x[c] ?? 0, grid.y[c] ?? 0, grid.z[c] ?? 0);
    sx[c] = x;
    sy[c] = y;
    sz[c] = z;
  }
  const plate = new Uint8Array(count);
  for (let c = 0; c < count; c++) plate[c] = P.plateAt(plates, warpSeed, sx[c] ?? 0, sy[c] ?? 0, sz[c] ?? 0);

  // ── 지각 (108~133행) ──
  const continentOctaves = Math.min(P.CONTINENT_OCTAVES, N.octavesFor(P.CONTINENT_FREQUENCY, grid.meanCellAngle, 6));
  const crustNoise = new Float32Array(count);
  for (let c = 0; c < count; c++) {
    const noise = N.fbm3(continentSeed, sx[c] ?? 0, sy[c] ?? 0, sz[c] ?? 0, P.CONTINENT_FREQUENCY, continentOctaves, 0.55);
    const bias = P.plateOf(plates, plate[c] ?? 0).bias;
    const push = CORNER_PUSH * cornerProximity(grid.x[c] ?? 0, grid.y[c] ?? 0, grid.z[c] ?? 0, CORNER_PUSH_RADIUS);
    crustNoise[c] = noise + bias - push;
  }
  const crustThreshold: number = U.areaPercentile(grid, crustNoise, 1 - continentalShare);
  const continental = new Uint8Array(count);
  for (let c = 0; c < count; c++) continental[c] = (crustNoise[c] ?? 0) > crustThreshold ? 1 : 0;
  const crustRank = continentalRank(crustNoise, continental);

  // ── 판 경계 (135~183행) + 기록: 이웃 판, 수렴 속도(부호), 어긋남(변환 단층 성분, 생성기에는 없음) ──
  const feature = new Uint8Array(count);
  const strength = new Float32Array(count);
  const ridge = new Uint8Array(count);
  const plateBoundary = new Uint8Array(count);
  const neighborPlate = new Int16Array(count).fill(-1);
  const convergenceOut = new Float32Array(count).fill(Number.NaN);
  const shear = new Float32Array(count).fill(Number.NaN);
  const out = new Int32Array(8);
  for (let c = 0; c < count; c++) {
    const own = plate[c] ?? 0;
    neighbors8(grid, c, out);
    let other = -1;
    for (let k = 0; k < 8; k++) {
      const next = out[k] ?? -1;
      if (next >= 0 && plate[next] !== own) {
        other = next;
        break;
      }
    }
    if (other < 0) continue;
    plateBoundary[c] = 1;
    neighborPlate[c] = plate[other] ?? 0;
    const a = P.plateOf(plates, own);
    const b = P.plateOf(plates, plate[other] ?? 0);
    const px = sx[c] ?? 0;
    const py = sy[c] ?? 0;
    const pz = sz[c] ?? 0;
    let nx = b.center[0] - a.center[0];
    let ny = b.center[1] - a.center[1];
    let nz = b.center[2] - a.center[2];
    const along = nx * px + ny * py + nz * pz;
    nx -= along * px;
    ny -= along * py;
    nz -= along * pz;
    const length = Math.sqrt(nx * nx + ny * ny + nz * nz);
    if (length < 1e-9) continue;
    const [ax, ay, az] = P.plateVelocity(a, px, py, pz);
    const [bx, by, bz] = P.plateVelocity(b, px, py, pz);
    const convergence = ((ax - bx) * nx + (ay - by) * ny + (az - bz) * nz) / length;
    convergenceOut[c] = convergence;
    // 기록 전용: 접선(경계를 따라가는) 방향 t = p × n̂ 위의 상대 속도 = 변환 단층 성분
    const tx = (py * nz - pz * ny) / length;
    const ty = (pz * nx - px * nz) / length;
    const tz = (px * ny - py * nx) / length;
    shear[c] = (ax - bx) * tx + (ay - by) * ty + (az - bz) * tz;
    const ownContinental = continental[c] === 1;
    const otherContinental = continental[other] === 1;
    strength[c] = Math.min(1.5, Math.abs(convergence) / CONVERGENCE_REFERENCE);
    if (convergence > 0) {
      if (ownContinental && otherContinental) feature[c] = Bd.FEATURE_COLLISION;
      else if (ownContinental) feature[c] = Bd.FEATURE_ANDEAN;
      else if (otherContinental) feature[c] = Bd.FEATURE_TRENCH;
      else feature[c] = a.density >= b.density ? Bd.FEATURE_TRENCH : Bd.FEATURE_ISLAND_ARC;
    } else if (ownContinental && otherContinental) {
      feature[c] = Bd.FEATURE_RIFT;
    } else if (!ownContinental) {
      ridge[c] = 1;
    }
  }
  const mix = Bd.blendBoundaryFeatures(grid, plate, feature, strength);
  const boundary = Q.distanceField(grid, (c: number) => (mix.slot[c] ?? -1) >= 0, BOUNDARY_REACH, (from: number, to: number) => plate[from] === plate[to]);
  const ridgeDistance = Q.distanceField(grid, (c: number) => ridge[c] === 1, km(2800), (_from: number, to: number) => continental[to] === 0);
  const shelfDistance = Q.distanceField(grid, (c: number) => continental[c] === 1, km(260), (_from: number, to: number) => continental[to] === 0);

  // ── 고도 합치기 (204~260행) + 항목별 기여 ──
  const elevation = new Float32Array(count);
  const crustBaseRealM = new Float32Array(count);
  const reliefNoiseRealM = new Float32Array(count);
  const collisionRealM = new Float32Array(count);
  const andeanRealM = new Float32Array(count);
  const andeanVolcanicRealM = new Float32Array(count);
  const trenchRealM = new Float32Array(count);
  const islandArcRealM = new Float32Array(count);
  const riftRealM = new Float32Array(count);
  const wCollision = new Float32Array(count);
  const wAndean = new Float32Array(count);
  const wTrench = new Float32Array(count);
  const wArc = new Float32Array(count);
  const wRift = new Float32Array(count);
  const boundaryAlong = new Float32Array(count);
  const ridgeTexture = new Float32Array(count);
  const reliefSeed = R.streamSeed(seed, R.STREAM_RELIEF);
  const mountainSeed = R.streamSeed(seed, R.STREAM_MOUNTAINS);
  const reliefOctaves = N.octavesFor(5, grid.meanCellAngle, 8);
  const ridgeOctaves = N.octavesFor(7, grid.meanCellAngle, 6);
  const halfCell = grid.meanCellAngle / 2;
  const shelfRank = settings.shelfPercent / Math.max(1, settings.landPercent + settings.shelfPercent);
  const FK: number = Bd.FEATURE_KINDS;
  for (let c = 0; c < count; c++) {
    const x = sx[c] ?? 0;
    const y = sy[c] ?? 0;
    const z = sz[c] ?? 0;
    let h: number;
    if (continental[c] === 1) {
      const r = crustRank[c] ?? 0;
      if (r < shelfRank) {
        h = -180 * (1 - r / shelfRank);
      } else {
        const t = (r - shelfRank) / (1 - shelfRank);
        h = 900 * t * Math.sqrt(t);
      }
      crustBaseRealM[c] = h;
      const noiseTerm = rugged * (200 + 0.25 * Math.max(0, h)) * N.fbm3(reliefSeed, x, y, z, 5, reliefOctaves, 0.52);
      reliefNoiseRealM[c] = noiseTerm;
      h += noiseTerm;
    } else {
      const age = Math.min(1, (ridgeDistance.angle[c] ?? 0) / km(2800));
      const floor = -2500 - 3000 * Math.sqrt(age);
      const slope = smoothstep(0, km(220), shelfDistance.angle[c] ?? 0);
      h = -350 + (floor + 350) * slope;
      crustBaseRealM[c] = h;
      const noiseTerm = rugged * 220 * N.fbm3(reliefSeed, x, y, z, 5, reliefOctaves, 0.5);
      reliefNoiseRealM[c] = noiseTerm;
      h += noiseTerm;
    }
    const source = boundary.source[c] ?? -1;
    const slot = source >= 0 ? (mix.slot[source] ?? -1) : -1;
    if (slot >= 0) {
      const d = (boundary.angle[c] ?? 0) + halfCell;
      const along = 0.35 + (0.5 + 0.5 * N.fbm3(mountainSeed + 7, x, y, z, 2.5, 3, 0.5)) * 1.3;
      const texture = 0.45 + 1.1 * N.ridged3(mountainSeed, x, y, z, 7, ridgeOctaves, 0.55);
      boundaryAlong[c] = along;
      ridgeTexture[c] = texture;
      const at = slot * FK;
      wCollision[c] = mix.weight[at] ?? 0;
      wAndean[c] = mix.weight[at + 1] ?? 0;
      wTrench[c] = mix.weight[at + 2] ?? 0;
      wArc[c] = mix.weight[at + 3] ?? 0;
      wRift[c] = mix.weight[at + 4] ?? 0;
      const collision = (mix.weight[at] ?? 0) * along;
      const andean = (mix.weight[at + 1] ?? 0) * along;
      const trench = (mix.weight[at + 2] ?? 0) * along;
      const arc = (mix.weight[at + 3] ?? 0) * along;
      const rift = (mix.weight[at + 4] ?? 0) * along;
      if (collision > 0) {
        const term = uplift * 4200 * collision * texture * (1 - smoothstep(km(130), km(480), d));
        collisionRealM[c] = term;
        h += term;
      }
      if (andean > 0) {
        const term1 = uplift * 3800 * andean * texture * bump(d, km(150), km(160));
        andeanRealM[c] = term1;
        h += term1;
        const term2 = volcanism * 900 * andean * texture * bump(d, km(190), km(60));
        andeanVolcanicRealM[c] = term2;
        h += term2;
      }
      if (trench > 0) {
        const term = uplift * 3600 * trench * bump(d, km(30), km(80));
        trenchRealM[c] = -term;
        h -= term;
      }
      if (arc > 0) {
        const islands = Math.min(1, Math.max(0, 3 * (N.fbm3(mountainSeed + 11, x, y, z, 16, 2, 0.5) + 0.12)));
        const term = volcanism * 3900 * arc * texture * islands * bump(d, km(160), km(75));
        islandArcRealM[c] = term;
        h += term;
      }
      if (rift > 0) {
        const term = uplift * 1700 * rift * bump(d, 0, km(90));
        riftRealM[c] = -term;
        h -= term;
      }
    }
    elevation[c] = h;
  }

  // ── 열점 (261~272행): 목록은 생성기 함수 그대로, 칸별 더하기(hotspots.ts 60~83행)는 옮겨 적고 가장 가까운 화산을 기록 ──
  const volcanoes = Hs.hotspotVolcanoes(seed, plates, warpSeed, settings.hotspotCount, volcanism, (x: number, y: number, z: number, owner: number) => {
    const noise = N.fbm3(continentSeed, x, y, z, P.CONTINENT_FREQUENCY, continentOctaves, 0.55);
    return noise + P.plateOf(plates, owner).bias > crustThreshold;
  });
  const hotspotRealM = new Float32Array(count);
  const hotspotNearestKm = new Float32Array(count).fill(Number.POSITIVE_INFINITY);
  const hotspotStep = new Uint8Array(count).fill(255);
  const hotspotId = new Uint8Array(count).fill(255);
  if (volcanoes.length > 0) {
    for (let c = 0; c < count; c++) {
      const x = sx[c] ?? 0;
      const y = sy[c] ?? 0;
      const z = sz[c] ?? 0;
      let add = 0;
      let bestD2 = Number.POSITIVE_INFINITY;
      let best = -1;
      for (let v = 0; v < volcanoes.length; v++) {
        const volcano = volcanoes[v];
        const dx = x - volcano.x;
        const dy = y - volcano.y;
        const dz = z - volcano.z;
        const d2 = dx * dx + dy * dy + dz * dz;
        const r2 = volcano.radius * volcano.radius;
        if (d2 < 9 * r2) add += volcano.height * detExp(-d2 / r2);
        if (d2 < bestD2) {
          bestD2 = d2;
          best = v;
        }
      }
      if (add !== 0) elevation[c] = (elevation[c] ?? 0) + add;
      hotspotRealM[c] = add;
      // 현 길이 → 각도: 2·asin(chord/2) ≈ chord (가까운 거리). 기록 전용이라 근사로 충분
      hotspotNearestKm[c] = Math.sqrt(bestD2) * RKM;
      hotspotStep[c] = best % 6;
      hotspotId[c] = Math.floor(best / 6);
    }
  }
  // 열점 목록(사슬 첫 화산을 격자 좌표로 되돌린다: 격자 = 회전ᵀ × 무늬)
  const hotspots: HotspotInfo[] = [];
  for (let k = 0; k * 6 < volcanoes.length; k++) {
    const v = volcanoes[k * 6];
    const r = rotation;
    const gx = r[0] * v.x + r[3] * v.y + r[6] * v.z;
    const gy = r[1] * v.x + r[4] * v.y + r[7] * v.z;
    const gz = r[2] * v.x + r[5] * v.y + r[8] * v.z;
    const ownerIndex = P.plateAt(plates, warpSeed, v.x, v.y, v.z);
    const noise = N.fbm3(continentSeed, v.x, v.y, v.z, P.CONTINENT_FREQUENCY, continentOctaves, 0.55);
    hotspots.push({
      id: k,
      latDeg: (Math.asin(Math.max(-1, Math.min(1, gz))) * 180) / Math.PI,
      lonDeg: (Math.atan2(gy, gx) * 180) / Math.PI,
      continental: noise + P.plateOf(plates, ownerIndex).bias > crustThreshold,
      peakRealM: v.height,
    });
  }

  const toKm = (angle: Float32Array) => {
    const result = new Float32Array(angle.length);
    for (let c = 0; c < angle.length; c++) result[c] = (angle[c] ?? 0) * RKM;
    return result;
  };
  return {
    plate,
    continental,
    crustNoise,
    crustThreshold,
    crustRank,
    plateBoundary,
    neighborPlate,
    convergence: convergenceOut,
    shear,
    boundaryFeatureRaw: feature,
    boundaryStrengthRaw: strength,
    midOceanRidge: ridge,
    boundarySlot: mix.slot,
    boundaryDistKm: toKm(boundary.angle),
    boundarySource: boundary.source,
    wCollision,
    wAndean,
    wTrench,
    wArc,
    wRift,
    boundaryAlong,
    ridgeTexture,
    ridgeDistKm: toKm(ridgeDistance.angle),
    shelfDistKm: toKm(shelfDistance.angle),
    crustBaseRealM,
    reliefNoiseRealM,
    collisionRealM,
    andeanRealM,
    andeanVolcanicRealM,
    trenchRealM,
    islandArcRealM,
    riftRealM,
    hotspotRealM,
    hotspotNearestKm,
    hotspotStep,
    hotspotId,
    elevation,
    hotspots,
    plateCount: plates.length,
    rotation: Array.from(rotation),
  };
}
