// 특수 지형 종합안 조건 (두 설계안 A·B를 합친 판) — 스크래치, 읽기 전용. 생성기 c08f84f(출력 판 2) 사본 하네스 위에서 잰다.
// 표기: 실제 환산(RealM·Km)은 생성기 내부 단위. 게임 m·km = ÷ 12. realElevationM = elevationM × 12.
// 층(layer): landform(지형 층, 칸마다 하나, 우선순위), ecology(생태 층, 칸마다 하나), point(지점 층: 띠 + 2차맵 안 지점),
//           variant(변형 표시), aux(보조, 후보 아님), alt(비교용 다른 문턱, 최종안 아님)
// 새 스트림 번호(101~)는 측정용 임시 번호다(실제 구현은 random.ts 끝에 붙인다).
import {
  areaThreshold, cellKmOf, cellOfPoint, distSource, maxWithinKm, patchNoise, reliefKm, seededSites, stampDisc, upwindHas,
  type Planet,
} from "./helpers.ts";

export const STREAM = {
  LITHOLOGY: 9, // A안 탄산염(석회암) 지대 — 암석 종류 필드의 출발점
  SEA_ICE_EDGE: 10,
  KARST_B: 101,
  DUNES: 102,
  KELP: 103,
  GROVE: 104,
  CRYSTAL: 105,
  BOG: 106,
  INSELBERG: 107,
  CREVASSE: 108,
  HOT_SPRING: 120,
  OASIS: 121,
  IMPACT: 131,
  WAR_THEATRE: 132,
  WAR_CRATER: 133,
} as const;

export interface Cand {
  readonly name: string;
  readonly layer: "landform" | "ecology" | "point" | "variant" | "aux" | "alt";
  readonly expr?: string;
  readonly mask?: (planet: Planet, h: any) => ArrayLike<number>;
}

const B = (planet: Planet, id: string): number => planet.meta.biomeIds.indexOf(id);

/** 노이즈 문턱 거르기 */
const noiseGate = (stream: number, frequency: number, threshold: number, base: string) => (planet: Planet, h: any) => {
  const n = patchNoise(planet, stream, frequency);
  const m = h.mask(base);
  const out = new Uint8Array(m.length);
  for (let c = 0; c < m.length; c++) out[c] = m[c] && (n[c] as number) > threshold ? 1 : 0;
  return out;
};

/** 반경 km 기복 조건 */
const reliefGate = (base: string, test: (r: number) => boolean, km = 100) => (planet: Planet, h: any) => {
  const r = reliefKm(planet, km);
  const m = h.mask(base);
  const out = new Uint8Array(m.length);
  for (let c = 0; c < m.length; c++) out[c] = m[c] && test(r[c] as number) ? 1 : 0;
  return out;
};

/** 대륙 지각 육지 면적의 위 share만큼 = 탄산염(석회암) 지대. 면적 백분위라 행성마다 비율이 같다 */
function carbonateMask(planet: Planet, share: number, frequency = 6): Uint8Array {
  const F = planet.fields;
  const N = planet.grid.cellCount;
  const value = patchNoise(planet, STREAM.LITHOLOGY, frequency, 4, 0.5);
  const include = (c: number) => F.land[c] === 1 && F.continental[c] === 1;
  const t = areaThreshold(planet, value, 1 - share, include);
  const out = new Uint8Array(N);
  for (let c = 0; c < N; c++) out[c] = include(c) && (value[c] as number) > t ? 1 : 0;
  return out;
}

/** 큰 하구까지 거리 ≤ 반경(하구 유량에 따라 다름): R = clamp(k × √(Q ÷ 100), min, max) km */
function nearMouthScaled(planet: Planet, minQ: number, k: number, minKm: number, maxKm: number): Float32Array {
  const F = planet.fields;
  const N = planet.grid.cellCount;
  const isMouth = (c: number) => F.riverMouth[c] === 1 && (F.dischargeKm3[c] as number) >= minQ;
  const d = distSource(planet, isMouth, maxKm + 50, `mouth${minQ}`);
  const ratio = new Float32Array(N).fill(99);
  for (let c = 0; c < N; c++) {
    const s = d.source[c] as number;
    if (s < 0) continue;
    const q = F.dischargeKm3[s] as number;
    const r = Math.min(maxKm, Math.max(minKm, k * Math.sqrt(q / 100)));
    ratio[c] = (d.km[c] as number) / r; // ≤ 1이면 반경 안
  }
  return ratio;
}

// 열 대용값(실제 환산 m): 화산호 + 섬 호 + 2 × 열곡 깊이 + 젊은(0~1단계) 열점
const HEAT = "(andeanVolcanicRealM + islandArcRealM + 2 * (riftRealM < 0 ? -riftRealM : 0) + (hotspotStep <= 1 ? hotspotRealM : 0))";

export const CANDS: Cand[] = [
  // ── 보조 ──
  { name: "aux_arcV", layer: "aux", expr: "andeanVolcanicRealM + islandArcRealM >= 300" },
  { name: "aux_bigMouth50", layer: "aux", expr: "riverMouth === MOUTH.OCEAN && dischargeKm3 >= 50" },
  { name: "aux_bigMouth100", layer: "aux", expr: "riverMouth === MOUTH.OCEAN && dischargeKm3 >= 100" },
  { name: "aux_deepSea", layer: "aux", expr: "ocean && depthClass === DEPTH.DEEP" },
  { name: "aux_bigRiver", layer: "aux", expr: "riverCell && dischargeKm3 >= 100 && realElevationM <= 500" },
  { name: "aux_river20", layer: "aux", expr: "riverCell && dischargeKm3 >= 20" },
  { name: "aux_transform", layer: "aux", expr: "plateBoundary && boundaryClass === 3" },
  { name: "aux_desertOrPlaya", layer: "aux", expr: "biomeId === 'desert' || basinKind === BASIN.DRY" },
  { name: "aux_iceLand", layer: "aux", expr: "land && biomeId === 'ice_sheet'" },
  { name: "aux_notIce", layer: "aux", expr: "!(land && biomeId === 'ice_sheet')" },
  {
    name: "aux_peak50",
    layer: "aux",
    mask: (planet) => Uint8Array.from(maxWithinKm(planet, planet.fields.realElevationM, 50, "elev"), (v) => (v >= 1000 ? 1 : 0)),
  },
  {
    name: "aux_incision400",
    layer: "aux",
    mask: (planet) => {
      const F = planet.fields;
      const m = maxWithinKm(planet, F.groundElevRealM, 50, "ground");
      return Uint8Array.from(m, (v, c) => (v - (F.groundElevRealM[c] as number) >= 400 ? 1 : 0));
    },
  },

  // ══ 지형 층 (landform) ══
  // 1 화산 지대: 화산호(안데스형 + 섬 호) 또는 열점 화산 항이 300m(실제 환산, 게임 25m) 이상인 땅
  { name: "volcano", layer: "landform", expr: "land && (aux_arcV || hotspotRealM >= 300)" },
  { name: "v_volcanoArc", layer: "variant", expr: "volcano && andeanVolcanicRealM + islandArcRealM >= hotspotRealM" },
  { name: "v_volcanoIslandArc", layer: "variant", expr: "v_volcanoArc && islandArcRealM > andeanVolcanicRealM" },
  { name: "v_volcanoShield", layer: "variant", expr: "volcano && !v_volcanoArc && continental === 0" },
  { name: "v_volcanoPlateau", layer: "variant", expr: "volcano && !v_volcanoArc && continental === 1" },
  { name: "v_volcanoActive", layer: "variant", expr: "volcano && (v_volcanoArc || hotspotStep === 0)" },
  { name: "v_volcanoIce", layer: "variant", expr: "volcano && biomeId === 'ice_sheet'" },
  { name: "alt_volcanoB500", layer: "alt", expr: "land && volcanicRealM >= 500" },

  // 2 열곡
  { name: "rift_valley", layer: "landform", expr: "land && riftRealM <= -250" },

  // 3 빙하 지대: 산악 빙하(고산 + 눈) | 빙하 균열(빙상 가장자리·험한 곳 + 노이즈)
  {
    name: "v_mountainGlacier",
    layer: "variant",
    expr: "biomeId === 'alpine' && ((temperatureC < -6 && precipitationMm >= 300) || (temperatureC < -3 && precipitationMm >= 800) || (temperatureC < 0 && precipitationMm >= 2000))",
  },
  { name: "aux_iceRough", layer: "aux", mask: reliefGate("aux_iceLand", (r) => r >= 600) },
  { name: "aux_crevasseBase", layer: "aux", expr: "aux_iceLand && (aux_iceRough || dist_aux_notIce <= 100)" },
  { name: "v_crevasse", layer: "variant", mask: noiseGate(STREAM.CREVASSE, 12, 0.2, "aux_crevasseBase") },
  { name: "alt_crevasse01", layer: "alt", mask: noiseGate(STREAM.CREVASSE, 12, 0.1, "aux_crevasseBase") },
  { name: "glacier", layer: "landform", expr: "v_mountainGlacier || v_crevasse" },

  // 4 협곡 지대: 반건조 고지대(강가 가산 뺀 습도 30~120)에서 강 80km 안 | 산악 협곡(큰 강이 험한 곳을 지남)
  { name: "aux_canyonDry", layer: "aux", expr: "land && humidityDry >= 30 && humidityDry < 120 && temperatureC >= 0 && realElevationM >= 500 && dist_riverCell <= 80" },
  { name: "v_gorge", layer: "variant", expr: "aux_river20 && realElevationM >= 1000 && aux_incision400" },
  { name: "canyon", layer: "landform", expr: "aux_canyonDry || v_gorge" },
  { name: "alt_canyonB", layer: "alt", expr: "land && humidity >= 30 && humidity < 120 && temperatureC >= 0 && realElevationM >= 500 && dist_riverCell <= 80" },

  // 5 피오르 해안
  { name: "fjord", layer: "landform", expr: "land && coast && absLatDeg >= 40 && temperatureC <= 5 && precipitationMm >= 300 && aux_peak50" },
  { name: "alt_fjordA", layer: "alt", expr: "land && coast && absLatDeg >= 45 && temperatureC <= 7 && precipitationMm >= 300 && aux_peak50" },

  // 6 삼각주: 큰 하구(유량 100 km³/년 이상) 반경 안의 낮은 땅. 반경 = clamp(60 × √(Q/100), 40, 150) km
  {
    name: "river_delta",
    layer: "landform",
    mask: (planet) => {
      const F = planet.fields;
      const ratio = nearMouthScaled(planet, 100, 60, 40, 150);
      return Uint8Array.from(ratio, (r, c) => (F.land[c] === 1 && (F.realElevationM[c] as number) <= 96 && r <= 1 ? 1 : 0));
    },
  },
  { name: "alt_deltaA100", layer: "alt", expr: "land && dist_aux_bigMouth100 <= 100 && realElevationM <= 96" },

  // 7 범람원: 큰 강(유량 100 이상, 500m 아래) 20km 안, 그 강보다 30m(실제) 이하로 높은 땅, 삼각주 제외
  {
    name: "floodplain",
    layer: "landform",
    mask: (planet, h) => {
      const F = planet.fields;
      const N = planet.grid.cellCount;
      const big = h.masks.get("aux_bigRiver");
      const delta = h.masks.get("river_delta");
      const d = distSource(planet, (c) => big[c] === 1, 20, "bigRiver");
      const out = new Uint8Array(N);
      for (let c = 0; c < N; c++) {
        if (!F.land[c] || delta[c]) continue;
        const s = d.source[c] as number;
        if (s < 0 || (d.km[c] as number) > 20) continue;
        if ((F.groundElevRealM[c] as number) - (F.groundElevRealM[s] as number) <= 30) out[c] = 1;
      }
      return out;
    },
  },

  // 8 갯벌: 낮은 해안(36m 이하) + 온대(2~21°C) + 큰 하구(유량 50 이상) 400km 안 + 심해에서 100km 이상
  { name: "tidal_flat", layer: "landform", expr: "land && coast && realElevationM <= 36 && temperatureC >= 2 && temperatureC < 21 && dist_aux_bigMouth50 <= 400 && dist_aux_deepSea >= 100" },

  // 9 소금 평원·염호: 마른 분지 바닥(웅덩이 깊이가 분지 최대의 절반 이상) + 건조 | 겨우 넘치는 호수(염호)
  { name: "v_saltFlat", layer: "variant", expr: "land && basinKind === BASIN.DRY && depressionDepthRealM >= 0.5 * basinMaxDepthRealM && humidityDry < 110" },
  { name: "v_salineLake", layer: "variant", expr: "lake && basinWaterRatio < 1.5" },
  { name: "salt_flat", layer: "landform", expr: "v_saltFlat || v_salineLake" },
  { name: "alt_saltWholeBasin", layer: "alt", expr: "(land && basinKind === BASIN.DRY && humidity < 100) || v_salineLake" },

  // 10 사구 지대(에르그): 사막 중 가장 건조하고 평평한 곳
  { name: "dune_sea", layer: "landform", expr: "biomeId === 'desert' && aridityIndex <= 0.12 && realElevationM <= 1500 && basinKind !== BASIN.DRY && slopeMPerKm <= 1.2" },
  { name: "alt_dune010", layer: "alt", expr: "biomeId === 'desert' && aridityIndex <= 0.10 && realElevationM <= 1500 && basinKind !== BASIN.DRY && slopeMPerKm <= 1.2" },

  // 11 황토 고원: 초지, 습도 120 미만, 실제 400~2500m, 바람 위쪽(upwindCell 사슬) 1000km 안에 사막·마른 분지
  {
    name: "aux_loessUpwind",
    layer: "aux",
    mask: (planet) => {
      const F = planet.fields;
      const desert = B(planet, "desert");
      return upwindHas(planet, (c) => F.biome[c] === desert || F.basinKind[c] === 3, 1000);
    },
  },
  {
    name: "loess_plateau",
    layer: "landform",
    mask: (planet, h) => {
      const F = planet.fields;
      const N = planet.grid.cellCount;
      const grass = B(planet, "grassland");
      const src = h.masks.get("aux_loessUpwind");
      const out = new Uint8Array(N);
      for (let c = 0; c < N; c++) {
        if (!F.land[c] || F.biome[c] !== grass || F.basinKind[c] === 3) continue;
        if ((F.humidity[c] as number) >= 120) continue;
        const e = F.realElevationM[c] as number;
        if (e < 400 || e >= 2500) continue;
        if (src[c]) out[c] = 1;
      }
      return out;
    },
  },

  // 12 동토 호수 지대(서모카르스트): 툰드라 기온(−11~−3°C)의 평평한 저지
  { name: "thermokarst", layer: "variant", expr: "land && temperatureC >= -11 && temperatureC < -3 && humidity >= 80 && realElevationM <= 300 && slopeMPerKm <= 1.2" },

  // 13 바위 언덕 평원(인젤베르크): 오래된 안정 지괴(대륙 안쪽, 판 경계 500km 밖) + 사바나·초지·사막 + 평평 + 노이즈
  { name: "aux_inselBase0", layer: "aux", expr: "land && continental && crustRank >= 0.6 && distToPlateBoundaryKm >= 500 && (biomeId === 'savanna' || biomeId === 'grassland' || biomeId === 'desert')" },
  { name: "aux_inselBase", layer: "aux", mask: reliefGate("aux_inselBase0", (r) => r < 500) },
  { name: "inselberg_plain", layer: "landform", mask: noiseGate(STREAM.INSELBERG, 16, 0.25, "aux_inselBase") },
  { name: "alt_insel015", layer: "alt", mask: noiseGate(STREAM.INSELBERG, 16, 0.15, "aux_inselBase") },

  // 14 크리스탈 맥: 변환 단층형 판 경계(전단 > 수렴) 60km 안 땅 + 맥 노이즈
  { name: "aux_crystalBase", layer: "aux", expr: "land && dist_aux_transform <= 60" },
  { name: "crystal_veins", layer: "landform", mask: noiseGate(STREAM.CRYSTAL, 24, 0, "aux_crystalBase") },

  // 15 카르스트: 탄산염 지대(새 암석 노이즈 fbm3 주파수 6·4옥타브, 대륙 지각 육지 면적의 위 15%) + 습윤(강수 700mm 이상) + 0°C 이상 + 3000m 미만
  { name: "aux_carbonate15", layer: "aux", mask: (planet) => carbonateMask(planet, 0.15) },
  { name: "karst", layer: "landform", expr: "aux_carbonate15 && precipitationMm >= 700 && temperatureC >= 0 && realElevationM < 3000" },
  { name: "aux_carbonate20", layer: "aux", mask: (planet) => carbonateMask(planet, 0.2, 3) },
  { name: "alt_karstA20", layer: "alt", expr: "aux_carbonate20 && precipitationMm >= 700 && temperatureC >= 0 && realElevationM < 3000" },
  { name: "aux_karstB", layer: "aux", expr: "land && temperatureC >= 2 && humidity >= 120 && realElevationM >= 50 && realElevationM < 2500 && biomeId !== 'wetland'" },
  { name: "alt_karstB", layer: "alt", mask: noiseGate(STREAM.KARST_B, 10, 0.2, "aux_karstB") },

  // 16 크레이터(시드 지점): 운석 구덩이 80곳 중 땅 + 가지치기 흔적(옛 문명 중심지 6곳 × 16개)
  {
    name: "crater",
    layer: "landform",
    mask: (planet) => {
      const F = planet.fields;
      const N = planet.grid.cellCount;
      const out = new Uint8Array(N);
      for (const s of seededSites(planet, STREAM.IMPACT, 80)) {
        if (F.land[s.c] !== 1) continue;
        // 반지름 4 × 25^a km(실제, 로그 균등 4~100km). 구현은 detExp(a × ln 25)
        const r = 4 * Math.exp(s.a * Math.log(25));
        stampDisc(planet, out, s.x, s.y, s.z, r);
      }
      const theatres = [];
      for (const s of seededSites(planet, STREAM.WAR_THEATRE, 256)) {
        const c = s.c;
        const heart = F.land[c] === 1 && F.temperatureC[c] >= 4 && F.temperatureC[c] <= 24 && F.humidity[c] >= 70 && F.humidity[c] <= 230 && F.realElevationM[c] < 1000 && F.distToOceanKm[c] < 900;
        if (heart) theatres.push(s);
        if (theatres.length >= 6) break;
      }
      const R = planet.G.util.REFERENCE_RADIUS_KM;
      const rng = planet.G.random.streamRng(planet.meta.seed, STREAM.WAR_CRATER);
      const U = () => planet.G.random.unitFloat(rng);
      for (const t of theatres) {
        const ax = Math.abs(t.z) < 0.9 ? [0, 0, 1] : [1, 0, 0];
        let ux = ax[1] * t.z - ax[2] * t.y, uy = ax[2] * t.x - ax[0] * t.z, uz = ax[0] * t.y - ax[1] * t.x;
        const ul = Math.hypot(ux, uy, uz); ux /= ul; uy /= ul; uz /= ul;
        const vx = t.y * uz - t.z * uy, vy = t.z * ux - t.x * uz, vz = t.x * uy - t.y * ux;
        for (let k = 0; k < 16; k++) {
          const d = (400 * Math.sqrt(U())) / R;
          const th = 2 * Math.PI * U();
          const rr = 3 + 22 * U() ** 2;
          const px = t.x + d * (Math.cos(th) * ux + Math.sin(th) * vx), py = t.y + d * (Math.cos(th) * uy + Math.sin(th) * vy), pz = t.z + d * (Math.cos(th) * uz + Math.sin(th) * vz);
          const l = Math.hypot(px, py, pz);
          const x = px / l, y = py / l, z = pz / l;
          // 땅에 떨어진 것만
          const cc = cellOfPoint(planet, x, y, z);
          if (F.land[cc] !== 1) continue;
          stampDisc(planet, out, x, y, z, rr);
        }
      }
      for (let c = 0; c < N; c++) if (!F.land[c]) out[c] = 0;
      return out;
    },
  },

  // ══ 생태 층 (ecology) ══
  // 17 해빙: 해수면 기온 + 5 × 노이즈 ≤ −8°C | 빙상 해안 100km 안 + 해수면 기온 ≤ −2°C (붙은 얼음·빙붕)
  {
    name: "sea_ice",
    layer: "ecology",
    mask: (planet, h) => {
      const F = planet.fields;
      const N = planet.grid.cellCount;
      const ice = h.masks.get("aux_iceLand");
      const dIce = distSource(planet, (c) => ice[c] === 1, 300, "iceLand");
      const n = patchNoise(planet, STREAM.SEA_ICE_EDGE, 8, 3, 0.5);
      const out = new Uint8Array(N);
      for (let c = 0; c < N; c++) {
        if (!F.ocean[c]) continue;
        const t = F.seaLevelTempC[c] as number;
        if (t + 5 * (n[c] as number) <= -8 || ((dIce.km[c] as number) <= 100 && t <= -2)) out[c] = 1;
      }
      return out;
    },
  },
  { name: "alt_seaIcePlain", layer: "alt", expr: "ocean && seaLevelTempC <= -8" },
  { name: "v_frozenLake", layer: "variant", expr: "lake && temperatureC <= -11" },

  // 18 산호초: 따뜻한 바다(해수면 기온 23°C 이상) + 큰 하구(유량 50 이상)에서 150km 넘게
  //   (a) 얕은 바다(연안 수심) (b) 땅에 붙은 바다(가장자리 산호초) (c) 환초: 대양 지각 열점의 오래된 화산(1~5단계) 위
  { name: "v_coralShallow", layer: "variant", expr: "ocean && depthClass === DEPTH.COASTAL && seaLevelTempC >= 23 && dist_aux_bigMouth50 > 150" },
  { name: "v_coralFringing", layer: "variant", expr: "ocean && adj_land >= 1 && depthClass !== DEPTH.COASTAL && seaLevelTempC >= 23 && dist_aux_bigMouth50 > 150" },
  { name: "v_atoll", layer: "variant", expr: "ocean && continental === 0 && hotspotStep >= 1 && hotspotStep <= 5 && hotspotRealM >= 1500 && oceanDepthRealM <= 1500 && seaLevelTempC >= 23" },
  { name: "coral_reef", layer: "variant", expr: "v_coralShallow || v_coralFringing || v_atoll" },
  // 19 해조 숲(찬 바다): 연안 수심 + 해수면 기온 3~17°C + 큰 하구 100km 밖 + 노이즈
  { name: "aux_kelpBase", layer: "aux", expr: "ocean && depthClass === DEPTH.COASTAL && seaLevelTempC >= 3 && seaLevelTempC <= 17 && dist_aux_bigMouth50 > 100" },
  { name: "v_kelp", layer: "variant", mask: noiseGate(STREAM.KELP, 16, 0, "aux_kelpBase") },
  { name: "reef_kelp", layer: "ecology", expr: "coral_reef || v_kelp" },

  // 20 맹그로브: 열대(21°C 이상) 낮은 해안(실제 60m 이하) + 습도 100 이상 + 얕은 바다(연안 수심)에 붙음
  { name: "aux_adjShallow", layer: "aux", expr: "ocean && depthClass === DEPTH.COASTAL" },
  { name: "mangrove", layer: "ecology", expr: "land && coast && temperatureC >= 21 && realElevationM <= 60 && humidity >= 100 && adj_aux_adjShallow >= 1" },
  { name: "alt_mangroveA", layer: "alt", expr: "land && coast && temperatureC >= 21 && realElevationM <= 60 && humidity >= 100" },

  // 21 운무림
  { name: "cloud_forest", layer: "ecology", expr: "land && absLatDeg <= 25 && realElevationM >= 1000 && realElevationM < 3300 && precipitationMm >= 1200 && temperatureC >= 6 && humidity >= 150" },

  // 22 이탄 습지: 서늘한(−3~5°C) 습한(170 이상) 평평한 저지(실제 400m 이하), 강 칸 아님
  { name: "peat_bog", layer: "variant", expr: "land && !riverCell && temperatureC >= -3 && temperatureC <= 5 && humidity >= 170 && realElevationM <= 400 && slopeMPerKm <= 1.5" },
  { name: "aux_coldWetBase", layer: "aux", expr: "peat_bog || thermokarst" },
  // 이탄 습지·동토 호수: 두 기반 중 하나 + 습지 노이즈(주파수 12, 약 절반만 남겨 조각 무늬)
  { name: "cold_wetland", layer: "ecology", mask: noiseGate(STREAM.BOG, 12, 0, "aux_coldWetBase") },
  { name: "alt_peat160", layer: "alt", expr: "land && !riverCell && temperatureC >= -3 && temperatureC <= 5 && humidity >= 160 && realElevationM <= 400 && slopeMPerKm <= 1.5" },

  // 23 고목림: 숲 바이옴(기본 숲 밀도 150 이상)에서 숲 밀도가 기본값의 95% 이상 + 노이즈
  {
    name: "aux_groveBase",
    layer: "aux",
    mask: (planet) => {
      const F = planet.fields;
      const base = planet.meta.biomeIds.map((id: string) => ({ taiga: 175, temperate_forest: 200, tropical_rainforest: 245 } as Record<string, number>)[id] ?? 0);
      const out = new Uint8Array(planet.grid.cellCount);
      for (let c = 0; c < out.length; c++) {
        const b = base[F.biome[c]] as number;
        out[c] = F.land[c] === 1 && b >= 150 && (F.forest[c] as number) >= 0.95 * b ? 1 : 0;
      }
      return out;
    },
  },
  { name: "ancient_grove", layer: "ecology", mask: noiseGate(STREAM.GROVE, 12, 0.1, "aux_groveBase") },

  // ══ 지점 층 (point): 1차맵 칸 띠 → 2차맵 안 지점 ══
  // 24 온천·지열 지대
  { name: "geothermal", layer: "point", expr: `land && ${HEAT} >= 60` },
  { name: "v_hotSpring", layer: "variant", expr: "geothermal && precipitationMm >= 250" },
  { name: "v_geyser", layer: "variant", expr: `geothermal && ${HEAT} >= 400 && precipitationMm >= 600` },
  { name: "v_fumarole", layer: "variant", expr: "geothermal && precipitationMm < 250" },
  // 25 오아시스: 사막 기후(강가 가산 뺀 습도 55 미만, 0°C 이상) + 물(강 칸, 호수 옆, 메운 웅덩이 = 얕은 지하수, 와디 유량 3 이상), 소금 평원 아님
  { name: "oasis", layer: "point", expr: "land && humidityDry < 55 && temperatureC >= 0 && biomeId !== 'ice_sheet' && !salt_flat && (riverCell || adj_lake >= 1 || basinKind === BASIN.FILLED || dischargeKm3 >= 3)" },
];


/** 최종 목록(측정 뒤 고른 것)과 층·우선순위. 지형 층은 앞이 이긴다(바이옴 표처럼) */
export const LANDFORM_PRIORITY = [
  "volcano", "glacier", "canyon", "fjord", "river_delta", "tidal_flat", "salt_flat", "dune_sea", "crystal_veins",
  "inselberg_plain", "loess_plateau", "karst",
] as const;
export const ECOLOGY_PRIORITY = ["sea_ice", "reef_kelp", "mangrove", "cold_wetland"] as const;
/** 목록 밖 예비(따로 잰다): 범람원·열곡·크레이터·운무림·고목림 */
export const RESERVE = ["floodplain", "rift_valley", "crater", "cloud_forest", "ancient_grove"] as const;
export const POINT_ZONES = ["geothermal", "oasis"] as const;
export { cellKmOf };
