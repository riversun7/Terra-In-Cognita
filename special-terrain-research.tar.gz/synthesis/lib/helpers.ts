// 특수 지형 종합안 측정 도우미 (스크래치, 저장소 밖, 읽기 전용) — 하네스(synthesis/harness, 생성기 c08f84f 사본) 위에서 쓴다.
// 단위: Km = 실제 환산 km(생성기 내부), RealM = 실제 환산 m(게임 m × 12). 게임 값 = ÷ 12.
// 여기 계산은 측정용이다. Math.sin 같은 초월함수는 측정 통계에만 쓰고, 조건 자체는 사칙연산·비교·생성기 함수(fbm3·distanceField·areaPercentile·streamSeed·mix32)만 쓴다.
import { pathToFileURL } from "node:url";

export const SYN = "/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/synthesis";
export const HARNESS = `${SYN}/harness`;
export const ROOT = `${HARNESS}/snapshot-c08f84f`;

const planetLib = await import(pathToFileURL(`${HARNESS}/lib/planet.ts`).href);
const analyzeLib = await import(pathToFileURL(`${HARNESS}/lib/analyze.ts`).href);
export const proj = await import(pathToFileURL(`${ROOT}/packages/planet/src/projection.ts`).href);
export const { loadPlanet } = planetLib;
export const { newContext, evaluateCondition, conditionStats, clustersOf, adjCount, distKm, dilate, neighborExtreme } = analyzeLib;
export type Planet = any;

export const cellKmOf = (planet: Planet): number => planet.grid.meanCellAngle * planet.G.util.REFERENCE_RADIUS_KM;

// ── 캐시 ──
const caches = new WeakMap<object, Map<string, any>>();
export function cached<T>(planet: Planet, key: string, make: () => T): T {
  let m = caches.get(planet);
  if (!m) { m = new Map(); caches.set(planet, m); }
  if (m.has(key)) return m.get(key) as T;
  const v = make();
  m.set(key, v);
  return v;
}

/** 패치 노이즈: 돌리지 않은 격자 좌표의 fbm3(새 스트림). 옥타브 수 고정이라 면 레벨과 무관하게 같은 무늬 */
export function patchNoise(planet: Planet, stream: number, frequency: number, octaves = 3, gain = 0.5): Float32Array {
  return cached(planet, `noise:${stream}:${frequency}:${octaves}:${gain}`, () => {
    const { G, grid } = planet;
    const seed = G.random.streamSeed(planet.meta.seed, stream);
    const out = new Float32Array(grid.cellCount);
    for (let c = 0; c < grid.cellCount; c++) out[c] = G.noise.fbm3(seed, grid.x[c], grid.y[c], grid.z[c], frequency, octaves, gain);
    return out;
  });
}

/** 반지름 km 안(칸 걸음 근사, 자기 칸 포함) 최댓값 — 걸음 수 = max(1, round(km ÷ 칸 크기)) */
export function maxWithinKm(planet: Planet, values: ArrayLike<number>, km: number, key?: string): Float64Array {
  const make = () => {
    const grid = planet.grid;
    const N = grid.cellCount;
    const steps = Math.max(1, Math.round(km / cellKmOf(planet)));
    let cur = Float64Array.from(values);
    const nb = new Int32Array(8);
    for (let s = 0; s < steps; s++) {
      const next = Float64Array.from(cur);
      for (let c = 0; c < N; c++) {
        planet.G.grid.neighbors8(grid, c, nb);
        let best = next[c] as number;
        for (let k = 0; k < 8; k++) { const o = nb[k] as number; if (o >= 0 && (cur[o] as number) > best) best = cur[o] as number; }
        next[c] = best;
      }
      cur = next;
    }
    return cur;
  };
  return key ? cached(planet, `maxw:${key}:${km}`, make) : make();
}

/** 반지름 km 안 기복(최댓값 − 최솟값), 바닥 고도(바다 = 해수면 0) */
export function reliefKm(planet: Planet, km: number): Float32Array {
  return cached(planet, `relief:${km}`, () => {
    const F = planet.fields;
    const grid = planet.grid;
    const N = grid.cellCount;
    const ground = new Float64Array(N);
    for (let c = 0; c < N; c++) ground[c] = F.ocean[c] ? 0 : (F.groundElevRealM[c] as number);
    const k = Math.max(1, Math.round(km / cellKmOf(planet)));
    let hi = Float64Array.from(ground);
    let lo = Float64Array.from(ground);
    const out = new Int32Array(8);
    for (let step = 0; step < k; step++) {
      const nh = Float64Array.from(hi);
      const nl = Float64Array.from(lo);
      for (let c = 0; c < N; c++) {
        planet.G.grid.neighbors8(grid, c, out);
        for (let e = 0; e < 8; e++) {
          const o = out[e] as number;
          if (o < 0) continue;
          if ((hi[o] as number) > (nh[c] as number)) nh[c] = hi[o] as number;
          if ((lo[o] as number) < (nl[c] as number)) nl[c] = lo[o] as number;
        }
      }
      hi = nh;
      lo = nl;
    }
    const r = new Float32Array(N);
    for (let c = 0; c < N; c++) r[c] = (hi[c] as number) - (lo[c] as number);
    return r;
  });
}

/** 바람이 오는 쪽(upwindCell 사슬)으로 maxKm 안에 pred 칸이 있으면 1 */
export function upwindHas(planet: Planet, pred: (c: number) => boolean, maxKm: number): Uint8Array {
  const F = planet.fields;
  const N = planet.grid.cellCount;
  const RKM: number = planet.G.util.REFERENCE_RADIUS_KM;
  const chord = planet.G.grid.chordBetween;
  const out = new Uint8Array(N);
  for (let c = 0; c < N; c++) {
    let cur = c;
    let travelled = 0;
    for (let step = 0; step < 4096; step++) {
      const up = F.upwindCell[cur] as number;
      if (up === cur || up < 0) break;
      travelled += chord(planet.grid, cur, up) * RKM;
      if (travelled > maxKm) break;
      if (pred(up)) { out[c] = 1; break; }
      cur = up;
    }
  }
  return out;
}

/** 거리장 + 가장 가까운 원천 칸(생성기 distanceField). 반환 km는 실제 환산 */
export function distSource(planet: Planet, isSource: (c: number) => boolean, capKm: number, key?: string): { km: Float32Array; source: Int32Array } {
  const make = () => {
    const { G, grid } = planet;
    const field = G.queues.distanceField(grid, isSource, G.util.km(capKm));
    const R: number = G.util.REFERENCE_RADIUS_KM;
    const kmArr = new Float32Array(grid.cellCount);
    for (let c = 0; c < grid.cellCount; c++) kmArr[c] = (field.angle[c] as number) * R;
    return { km: kmArr, source: Int32Array.from(field.source) };
  };
  return key ? cached(planet, `dist:${key}:${capKm}`, make) : make();
}

/** 면적 백분위 문턱(생성기 areaPercentile) */
export function areaThreshold(planet: Planet, values: Float32Array, fraction: number, include: (c: number) => boolean): number {
  return planet.G.util.areaPercentile(planet.grid, values, fraction, include);
}

/** 칸 해시 [0,1): mix32(streamSeed ^ 칸 번호 섞기). 실제 구현은 칸 번호 대신 셀 키(면 레벨 무관 위치)를 쓴다 */
export function cellHash01(planet: Planet, stream: number, c: number): number {
  const { G } = planet;
  const s = G.random.streamSeed(planet.meta.seed, stream);
  return G.random.mix32(s ^ Math.imul(c + 1, 0x9e3779b1)) / 4_294_967_296;
}

/** 단위 벡터 → 이 면 레벨 칸 번호 */
export function cellOfPoint(planet: Planet, x: number, y: number, z: number): number {
  const { face, u, v } = proj.xyzToFaceUV([x, y, z]);
  const n = planet.grid.n;
  const i = Math.min(n - 1, Math.floor(proj.uvToST(u) * n));
  const j = Math.min(n - 1, Math.floor(proj.uvToST(v) * n));
  return face * n * n + j * n + i;
}

/** 지점 고르기(결정적): 후보 칸을 해시 순서로 보며, 이미 고른 점에서 spacingKm 안이면 버린다. 점 수와 칸 목록 */
export function greedyPoints(planet: Planet, mask: ArrayLike<number>, spacingKm: number, stream: number): number[] {
  const grid = planet.grid;
  const N = grid.cellCount;
  const R: number = planet.G.util.REFERENCE_RADIUS_KM;
  const cand: { c: number; h: number }[] = [];
  for (let c = 0; c < N; c++) if (mask[c]) cand.push({ c, h: cellHash01(planet, stream, c) });
  cand.sort((a, b) => a.h - b.h || a.c - b.c);
  const chordMax = 2 * Math.sin(spacingKm / R / 2);
  const chord2 = chordMax * chordMax;
  // 3D 격자 버킷
  const cell = chordMax;
  const buckets = new Map<string, number[]>();
  const keyOf = (x: number, y: number, z: number) => `${Math.floor(x / cell)},${Math.floor(y / cell)},${Math.floor(z / cell)}`;
  const picked: number[] = [];
  for (const { c } of cand) {
    const x = grid.x[c], y = grid.y[c], z = grid.z[c];
    const bx = Math.floor(x / cell), by = Math.floor(y / cell), bz = Math.floor(z / cell);
    let ok = true;
    for (let dx = -1; dx <= 1 && ok; dx++) for (let dy = -1; dy <= 1 && ok; dy++) for (let dz = -1; dz <= 1 && ok; dz++) {
      const list = buckets.get(`${bx + dx},${by + dy},${bz + dz}`);
      if (!list) continue;
      for (const o of list) {
        const ex = grid.x[o] - x, ey = grid.y[o] - y, ez = grid.z[o] - z;
        if (ex * ex + ey * ey + ez * ez < chord2) { ok = false; break; }
      }
    }
    if (!ok) continue;
    picked.push(c);
    const k = keyOf(x, y, z);
    const list = buckets.get(k);
    if (list) list.push(c); else buckets.set(k, [c]);
  }
  return picked;
}

export interface Site { k: number; x: number; y: number; z: number; c: number; a: number; b: number }
/** 시드 지점(열점과 같은 방식, 해상도 무관): streamRng → randomUnitVector + 값 두 개 */
export function seededSites(planet: Planet, stream: number, count: number): Site[] {
  const { G } = planet;
  const rng = G.random.streamRng(planet.meta.seed, stream);
  const sites: Site[] = [];
  for (let k = 0; k < count; k++) {
    const [x, y, z] = G.random.randomUnitVector(rng);
    const a = G.random.unitFloat(rng);
    const b = G.random.unitFloat(rng);
    sites.push({ k, x, y, z, c: cellOfPoint(planet, x, y, z), a, b });
  }
  return sites;
}

/** 원(반지름 km) 안 칸 표시 */
export function stampDisc(planet: Planet, mask: Uint8Array, x: number, y: number, z: number, radiusKm: number): void {
  const { grid } = planet;
  const R = planet.G.util.REFERENCE_RADIUS_KM;
  const chord = 2 * Math.sin(radiusKm / R / 2);
  const chord2 = chord * chord;
  const c0 = cellOfPoint(planet, x, y, z);
  const seen = new Set<number>([c0]);
  const queue = [c0];
  const out = new Int32Array(8);
  mask[c0] = 1;
  while (queue.length) {
    const c = queue.pop() as number;
    planet.G.grid.neighbors8(grid, c, out);
    for (let e = 0; e < 8; e++) {
      const nb = out[e] as number;
      if (nb < 0 || seen.has(nb)) continue;
      seen.add(nb);
      const dx = grid.x[nb] - x, dy = grid.y[nb] - y, dz = grid.z[nb] - z;
      if (dx * dx + dy * dy + dz * dz <= chord2) { mask[nb] = 1; queue.push(nb); }
    }
  }
}

export function quantiles(values: ArrayLike<number>, qs = [0, 0.1, 0.5, 0.9, 1]): number[] {
  const s = Float64Array.from(values).sort();
  if (s.length === 0) return qs.map(() => Number.NaN);
  return qs.map((q) => {
    const pos = (s.length - 1) * q;
    const lo = Math.floor(pos), hi = Math.ceil(pos);
    return (s[lo] as number) + ((s[hi] as number) - (s[lo] as number)) * (pos - lo);
  });
}
