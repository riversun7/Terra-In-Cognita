// 정보창용 규칙 표(조건 = 조항들의 AND, 변형 = 조항 묶음의 OR) — cands.ts와 같은 판정을 조항 단위로 다시 쓴 것.
// 정보창이 보여 줄 것: 조항마다 이 칸의 값(실제 단위)·문턱·통과 여부·모자란 양. 측정 스크립트가 cands.ts 마스크와 전 칸 대조한다.
import { patchNoise, reliefKm, maxWithinKm, distSource, areaThreshold, type Planet } from "./helpers.ts";
import { STREAM } from "./cands.ts";

export type Op = ">=" | ">" | "<=" | "<" | "==" | "!=" | "is";
export interface Clause {
  readonly ko: string;
  readonly unit: string;
  readonly op: Op;
  readonly limit: number;
  /** 이 칸 값. is 조항은 0/1 */
  readonly value: (c: number) => number;
  /** 모자란 양을 보는 눈금(근접 실패 판단, 1 = 이만큼 모자라면 '거의') */
  readonly near?: number;
}
export interface Branch { readonly ko: string; readonly clauses: readonly Clause[] }
export interface Rule { readonly id: string; readonly ko: string; readonly en: string; readonly layer: string; readonly branches: readonly Branch[] }

export function passes(cl: Clause, c: number): boolean {
  const v = cl.value(c);
  switch (cl.op) {
    case ">=": return v >= cl.limit;
    case ">": return v > cl.limit;
    case "<=": return v <= cl.limit;
    case "<": return v < cl.limit;
    case "==": return v === cl.limit;
    case "!=": return v !== cl.limit;
    case "is": return v === 1;
  }
}
/** 모자란 양(통과면 0). is 조항은 1 */
export function shortfall(cl: Clause, c: number): number {
  if (passes(cl, c)) return 0;
  const v = cl.value(c);
  if (cl.op === "is" || cl.op === "==" || cl.op === "!=") return Number.POSITIVE_INFINITY;
  return Math.abs(v - cl.limit) / (cl.near ?? 1);
}

export function buildRules(planet: Planet, masks: Map<string, Uint8Array>, derived: Map<string, ArrayLike<number>>): Rule[] {
  const F = planet.fields;
  const ids: string[] = planet.meta.biomeIds;
  const bi = (id: string) => ids.indexOf(id);
  const m = (name: string) => { const x = masks.get(name); if (!x) throw new Error(`mask ${name}`); return x; };
  const d = (name: string) => { const x = derived.get(name); if (!x) throw new Error(`derived ${name}`); return x; };
  const is = (ko: string, f: (c: number) => boolean): Clause => ({ ko, unit: "", op: "is", limit: 1, value: (c) => (f(c) ? 1 : 0) });
  const cmp = (ko: string, unit: string, op: Op, limit: number, value: (c: number) => number, near?: number): Clause => ({ ko, unit, op, limit, value, near });
  const T = (op: Op, t: number) => cmp("연평균 기온", "°C", op, t, (c) => F.temperatureC[c], 2);
  const H = (op: Op, h: number) => cmp("습도", "/255", op, h, (c) => F.humidity[c], 10);
  const Hd = (op: Op, h: number) => cmp("습도(강가 가산 뺌)", "/255", op, h, (c) => F.humidityDry[c], 10);
  const P = (op: Op, p: number) => cmp("연강수", "mm", op, p, (c) => F.precipitationMm[c], p * 0.15);
  const E = (op: Op, realM: number) => cmp("고도(실제 환산)", "m", op, realM, (c) => F.realElevationM[c], 100);
  const land = is("땅(바다·호수 아님)", (c) => F.land[c] === 1);
  const coast = is("해안(8이웃에 바다)", (c) => F.coast[c] === 1);
  const biome = (id: string, ko: string) => is(`바이옴 = ${ko}`, (c) => F.biome[c] === bi(id));

  const relief100 = reliefKm(planet, 100);
  const peak50 = maxWithinKm(planet, F.realElevationM, 50, "elev");
  const ground50 = maxWithinKm(planet, F.groundElevRealM, 50, "ground");
  const crevNoise = patchNoise(planet, STREAM.CREVASSE, 12);
  const inselNoise = patchNoise(planet, STREAM.INSELBERG, 16);
  const crystalNoise = patchNoise(planet, STREAM.CRYSTAL, 24);
  const kelpNoise = patchNoise(planet, STREAM.KELP, 16);
  const bogNoise = patchNoise(planet, STREAM.BOG, 12);
  const seaIceNoise = patchNoise(planet, STREAM.SEA_ICE_EDGE, 8, 3, 0.5);
  const lith = patchNoise(planet, STREAM.LITHOLOGY, 6, 4, 0.5);
  const lithInclude = (c: number) => F.land[c] === 1 && F.continental[c] === 1;
  const lithT = areaThreshold(planet, lith, 1 - 0.15, lithInclude);
  const iceLand = m("aux_iceLand");
  const dIce = distSource(planet, (c) => iceLand[c] === 1, 300, "iceLand");
  // 삼각주 반경 몫
  const mouth = distSource(planet, (c) => F.riverMouth[c] === 1 && (F.dischargeKm3[c] as number) >= 100, 200, "mouth100");
  const deltaRatio = (c: number) => {
    const s = mouth.source[c] as number;
    if (s < 0) return 99;
    const q = F.dischargeKm3[s] as number;
    return (mouth.km[c] as number) / Math.min(150, Math.max(40, 60 * Math.sqrt(q / 100)));
  };
  const heat = (c: number) => (F.andeanVolcanicRealM[c] as number) + (F.islandArcRealM[c] as number) + 2 * Math.max(0, -(F.riftRealM[c] as number)) + ((F.hotspotStep[c] as number) <= 1 ? (F.hotspotRealM[c] as number) : 0);

  return [
    { id: "volcano", ko: "화산 지대", en: "Volcanic field", layer: "landform", branches: [
      { ko: "화산호", clauses: [land, cmp("화산호 고도 기여(안데스형 + 섬 호)", "m 실제", ">=", 300, (c) => (F.andeanVolcanicRealM[c] as number) + (F.islandArcRealM[c] as number), 60)] },
      { ko: "열점", clauses: [land, cmp("열점 화산 고도 기여", "m 실제", ">=", 300, (c) => F.hotspotRealM[c], 60)] },
    ] },
    { id: "glacier", ko: "빙하 지대", en: "Glacier terrain", layer: "landform", branches: [
      { ko: "산악 빙하(추움·눈 300mm)", clauses: [biome("alpine", "고산"), T("<", -6), P(">=", 300)] },
      { ko: "산악 빙하(서늘·눈 800mm)", clauses: [biome("alpine", "고산"), T("<", -3), P(">=", 800)] },
      { ko: "산악 빙하(0°C 아래·눈 2000mm)", clauses: [biome("alpine", "고산"), T("<", 0), P(">=", 2000)] },
      { ko: "빙하 균열(빙상 가장자리)", clauses: [is("빙상 땅", (c) => iceLand[c] === 1), cmp("빙상 아닌 곳까지", "km 실제", "<=", 100, (c) => d("dist_aux_notIce")[c] as number, 20), cmp("균열 노이즈", "", ">", 0.2, (c) => crevNoise[c] as number, 0.05)] },
      { ko: "빙하 균열(험한 빙상)", clauses: [is("빙상 땅", (c) => iceLand[c] === 1), cmp("100km 안 기복", "m 실제", ">=", 600, (c) => relief100[c] as number, 100), cmp("균열 노이즈", "", ">", 0.2, (c) => crevNoise[c] as number, 0.05)] },
    ] },
    { id: "canyon", ko: "협곡 지대", en: "Canyon lands", layer: "landform", branches: [
      { ko: "메사·협곡(반건조 고지대)", clauses: [land, Hd(">=", 30), Hd("<", 120), T(">=", 0), E(">=", 500), cmp("강까지", "km 실제", "<=", 80, (c) => d("dist_riverCell")[c] as number, 20)] },
      { ko: "산악 협곡(큰 강이 험한 곳)", clauses: [is("강 칸", (c) => F.riverCell[c] === 1), cmp("유량", "km³/년", ">=", 20, (c) => F.dischargeKm3[c] as number, 5), E(">=", 1000), cmp("50km 안 최고 땅 − 이 땅", "m 실제", ">=", 400, (c) => (ground50[c] as number) - (F.groundElevRealM[c] as number), 100)] },
    ] },
    { id: "fjord", ko: "피오르 해안", en: "Fjord coast", layer: "landform", branches: [
      { ko: "", clauses: [land, coast, cmp("|위도|", "°", ">=", 40, (c) => F.absLatDeg[c] as number, 3), T("<=", 5), P(">=", 300), cmp("50km 안 최고 고도", "m 실제", ">=", 1000, (c) => peak50[c] as number, 150)] },
    ] },
    { id: "river_delta", ko: "삼각주", en: "River delta", layer: "landform", branches: [
      { ko: "", clauses: [land, E("<=", 96), cmp("큰 하구(유량 100 이상)까지 ÷ 그 하구 반경", "", "<=", 1, deltaRatio, 0.2)] },
    ] },
    { id: "tidal_flat", ko: "갯벌", en: "Tidal flat", layer: "landform", branches: [
      { ko: "", clauses: [land, coast, E("<=", 36), T(">=", 2), T("<", 21), cmp("하구(유량 50 이상)까지", "km 실제", "<=", 400, (c) => d("dist_aux_bigMouth50")[c] as number, 80), cmp("심해까지", "km 실제", ">=", 100, (c) => d("dist_aux_deepSea")[c] as number, 20)] },
    ] },
    { id: "salt_flat", ko: "소금 평원·염호", en: "Salt flat & saline lake", layer: "landform", branches: [
      { ko: "소금 평원(마른 분지 바닥)", clauses: [land, is("마른 분지(물이 나가지 않음)", (c) => F.basinKind[c] === 3), cmp("웅덩이 깊이 ÷ 분지 최대 깊이", "", ">=", 0.5, (c) => (F.basinMaxDepthRealM[c] as number) > 0 ? (F.depressionDepthRealM[c] as number) / (F.basinMaxDepthRealM[c] as number) : 0, 0.1), Hd("<", 110)] },
      { ko: "염호(겨우 넘치는 호수)", clauses: [is("호수", (c) => F.lake[c] === 1), cmp("들어온 물 ÷ 수면 증발", "", "<", 1.5, (c) => F.basinWaterRatio[c] as number, 0.2)] },
    ] },
    { id: "dune_sea", ko: "사구 지대", en: "Dune sea (erg)", layer: "landform", branches: [
      { ko: "", clauses: [biome("desert", "사막"), cmp("건조 지수(강수 ÷ 증발 가능량)", "", "<=", 0.12, (c) => F.aridityIndex[c] as number, 0.02), E("<=", 1500), is("마른 분지 아님", (c) => F.basinKind[c] !== 3), cmp("최대 경사", "m/km", "<=", 1.2, (c) => F.slopeMPerKm[c] as number, 0.3)] },
    ] },
    { id: "crystal_veins", ko: "크리스탈 맥", en: "Crystal veins", layer: "landform", branches: [
      { ko: "", clauses: [land, cmp("변환 단층형 판 경계까지", "km 실제", "<=", 60, (c) => d("dist_aux_transform")[c] as number, 15), cmp("맥 노이즈", "", ">", 0, (c) => crystalNoise[c] as number, 0.05)] },
    ] },
    { id: "inselberg_plain", ko: "바위 언덕 평원", en: "Inselberg plain", layer: "landform", branches: [
      { ko: "", clauses: [land, is("대륙 지각", (c) => F.continental[c] === 1), cmp("지각 안쪽 정도", "0~1", ">=", 0.6, (c) => F.crustRank[c] as number, 0.05), cmp("판 경계까지", "km 실제", ">=", 500, (c) => F.distToPlateBoundaryKm[c] as number, 50), is("바이옴 = 사바나·초지·사막", (c) => F.biome[c] === bi("savanna") || F.biome[c] === bi("grassland") || F.biome[c] === bi("desert")), cmp("100km 안 기복", "m 실제", "<", 500, (c) => relief100[c] as number, 100), cmp("바위 언덕 노이즈", "", ">", 0.25, (c) => inselNoise[c] as number, 0.05)] },
    ] },
    { id: "loess_plateau", ko: "황토 고원", en: "Loess plateau", layer: "landform", branches: [
      { ko: "", clauses: [land, biome("grassland", "초지"), is("마른 분지 아님", (c) => F.basinKind[c] !== 3), H("<", 120), E(">=", 400), E("<", 2500), is("바람 위쪽 1000km 안에 사막·마른 분지", (c) => m("aux_loessUpwind")[c] === 1)] },
    ] },
    { id: "karst", ko: "카르스트 지대", en: "Karst", layer: "landform", branches: [
      { ko: "", clauses: [is("대륙 지각 땅", lithInclude), cmp("암석 노이즈(탄산염 문턱 = 대륙 땅 위 15%)", "", ">", lithT, (c) => lith[c] as number, 0.05), P(">=", 700), T(">=", 0), E("<", 3000)] },
    ] },
    { id: "sea_ice", ko: "해빙", en: "Sea ice", layer: "ecology", branches: [
      { ko: "부빙(극 바다)", clauses: [is("바다", (c) => F.ocean[c] === 1), cmp("해수면 기온 + 5 × 가장자리 노이즈", "°C", "<=", -8, (c) => (F.seaLevelTempC[c] as number) + 5 * (seaIceNoise[c] as number), 1.5)] },
      { ko: "붙은 얼음·빙붕(빙상 해안)", clauses: [is("바다", (c) => F.ocean[c] === 1), cmp("빙상 땅까지", "km 실제", "<=", 100, (c) => dIce.km[c] as number, 20), cmp("해수면 기온", "°C", "<=", -2, (c) => F.seaLevelTempC[c] as number, 1.5)] },
    ] },
    { id: "reef_kelp", ko: "산호초·해조 숲", en: "Coral reef & kelp forest", layer: "ecology", branches: [
      { ko: "산호초(얕은 바다)", clauses: [is("바다", (c) => F.ocean[c] === 1), is("수심 연안(실제 60m 미만)", (c) => F.depthClass[c] === 1), cmp("해수면 기온", "°C", ">=", 23, (c) => F.seaLevelTempC[c] as number, 1), cmp("큰 하구(유량 50 이상)까지", "km 실제", ">", 150, (c) => d("dist_aux_bigMouth50")[c] as number, 30)] },
      { ko: "가장자리 산호초(땅에 붙은 깊은 바다)", clauses: [is("바다", (c) => F.ocean[c] === 1), cmp("8이웃 땅 칸 수", "칸", ">=", 1, (c) => d("adj_land")[c] as number, 1), is("수심 연안 아님", (c) => F.depthClass[c] !== 1), cmp("해수면 기온", "°C", ">=", 23, (c) => F.seaLevelTempC[c] as number, 1), cmp("큰 하구(유량 50 이상)까지", "km 실제", ">", 150, (c) => d("dist_aux_bigMouth50")[c] as number, 30)] },
      { ko: "환초(가라앉는 열점 화산)", clauses: [is("바다", (c) => F.ocean[c] === 1), is("대양 지각", (c) => F.continental[c] === 0), cmp("열점 단계(0 = 활동)", "", ">=", 1, (c) => F.hotspotStep[c] as number, 1), cmp("열점 단계", "", "<=", 5, (c) => F.hotspotStep[c] as number, 1), cmp("열점 화산 고도 기여", "m 실제", ">=", 1500, (c) => F.hotspotRealM[c] as number, 200), cmp("수심", "m 실제", "<=", 1500, (c) => F.oceanDepthRealM[c] as number, 200), cmp("해수면 기온", "°C", ">=", 23, (c) => F.seaLevelTempC[c] as number, 1)] },
      { ko: "해조 숲(찬 바다)", clauses: [is("바다", (c) => F.ocean[c] === 1), is("수심 연안(실제 60m 미만)", (c) => F.depthClass[c] === 1), cmp("해수면 기온", "°C", ">=", 3, (c) => F.seaLevelTempC[c] as number, 1), cmp("해수면 기온", "°C", "<=", 17, (c) => F.seaLevelTempC[c] as number, 1), cmp("큰 하구(유량 50 이상)까지", "km 실제", ">", 100, (c) => d("dist_aux_bigMouth50")[c] as number, 30), cmp("해조 노이즈", "", ">", 0, (c) => kelpNoise[c] as number, 0.05)] },
    ] },
    { id: "mangrove", ko: "맹그로브 숲", en: "Mangrove", layer: "ecology", branches: [
      { ko: "", clauses: [land, coast, T(">=", 21), E("<=", 60), H(">=", 100), cmp("8이웃 얕은 바다(연안 수심) 칸 수", "칸", ">=", 1, (c) => d("adj_aux_adjShallow")[c] as number, 1)] },
    ] },
    { id: "cold_wetland", ko: "이탄 습지·동토 호수 지대", en: "Peat bog & thermokarst lakes", layer: "ecology", branches: [
      { ko: "이탄 습지(타이가 저지)", clauses: [land, is("강 칸 아님", (c) => F.riverCell[c] === 0), T(">=", -3), T("<=", 5), H(">=", 170), E("<=", 400), cmp("최대 경사", "m/km", "<=", 1.5, (c) => F.slopeMPerKm[c] as number, 0.3), cmp("습지 노이즈", "", ">", 0, (c) => bogNoise[c] as number, 0.05)] },
      { ko: "동토 호수(툰드라 저지)", clauses: [land, T(">=", -11), T("<", -3), H(">=", 80), E("<=", 300), cmp("최대 경사", "m/km", "<=", 1.2, (c) => F.slopeMPerKm[c] as number, 0.3), cmp("습지 노이즈", "", ">", 0, (c) => bogNoise[c] as number, 0.05)] },
    ] },
    { id: "geothermal", ko: "온천·지열 지대", en: "Hot springs & geothermal", layer: "point", branches: [
      { ko: "", clauses: [land, cmp("열 대용값(화산호 + 섬 호 + 2 × 열곡 깊이 + 젊은 열점)", "m 실제", ">=", 60, heat, 20)] },
    ] },
    { id: "oasis", ko: "오아시스", en: "Oasis", layer: "point", branches: [
      { ko: "강·호수·지하수 오아시스", clauses: [land, Hd("<", 55), T(">=", 0), is("빙상 아님", (c) => F.biome[c] !== bi("ice_sheet")), is("소금 평원·염호 아님", (c) => m("salt_flat")[c] === 0), is("물: 강 칸·호수 옆·메운 웅덩이·와디(유량 3 이상)", (c) => F.riverCell[c] === 1 || (d("adj_lake")[c] as number) >= 1 || F.basinKind[c] === 2 || (F.dischargeKm3[c] as number) >= 3)] },
    ] },
  ];
}

/** 규칙 하나를 칸 하나에: 통과한 갈래, 갈래마다 조항 결과 */
export function evalRule(rule: Rule, c: number) {
  const branches = rule.branches.map((b) => {
    const results = b.clauses.map((cl) => ({ cl, pass: passes(cl, c), value: cl.value(c), short: shortfall(cl, c) }));
    return { branch: b, pass: results.every((r) => r.pass), results, failing: results.filter((r) => !r.pass) };
  });
  return { rule, pass: branches.some((b) => b.pass), branches };
}
