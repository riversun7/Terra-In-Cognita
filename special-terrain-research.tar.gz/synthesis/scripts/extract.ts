import { readFileSync } from "node:fs";
const S = "/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/synthesis/out";
for (const F of [7, 9]) {
  const rs = JSON.parse(readFileSync(`${S}/measure-F${F}.json`, "utf8")).results;
  console.log(`== F${F}`);
  // 겹침(시드 평균, 행 기준 %)
  const pairs = [["volcano","geothermal"],["geothermal","volcano"],["glacier","volcano"],["volcano","glacier"],["mangrove","river_delta"],["mangrove","karst"],["tidal_flat","river_delta"],["river_delta","mangrove"],["karst","inselberg_plain"],["inselberg_plain","karst"],["crystal_veins","volcano"],["crystal_veins","glacier"],["loess_plateau","inselberg_plain"],["loess_plateau","canyon"],["canyon","glacier"],["canyon","loess_plateau"],["canyon","inselberg_plain"],["fjord","glacier"],["fjord","volcano"],["cold_wetland","karst"],["cold_wetland","tidal_flat"],["oasis","dune_sea"],["oasis","salt_flat"],["dune_sea","inselberg_plain"],["salt_flat","dune_sea"],["geothermal","glacier"],["karst","mangrove"],["karst","river_delta"]];
  for (const [a,b] of pairs) { const v = rs.map((r: any) => r.layered.overlap[a]?.[b] ?? 0); console.log(`  ${a} ∩ ${b}: ${v.map((x: number) => x.toFixed(1)).join("/")} % of ${a}`); }
  console.log(`  effective landform % of land: ${rs.map((r: any) => JSON.stringify(Object.fromEntries(Object.entries(r.layered.effectiveLandformPctOfLand).map(([k, v]: any) => [k, +v.toFixed(2)])))).join("\n    ")}`);
  const pb = rs[0].layered.perBiome; const landCells = rs.map((r: any) => r.layered.landCells);
  console.log(`  biome % of land (per seed): ${Object.keys(pb).filter((k) => !k.startsWith("ocean") && k !== "lake").map((k) => `${k} ${rs.map((r: any, i: number) => (100 * r.layered.perBiome[k].cells / landCells[i]).toFixed(1)).join("/")}`).join("; ")}`);
  console.log(`  landCells ${landCells.join("/")} oceanCells ${rs.map((r: any) => r.layered.oceanCells).join("/")}`);
  // 시간: 최종 18개에 필요한 것만
  const t = rs[0].timings; const skip = (k: string) => k.startsWith("alt_") || ["floodplain","rift_valley","crater","cloud_forest","ancient_grove","aux_groveBase","aux_carbonate20","aux_karstB","layered","points","repetition"].includes(k);
  const sum = Object.entries(t).filter(([k]) => !skip(k)).reduce((a: number, [, v]: any) => a + v, 0);
  const all = Object.entries(t).filter(([k]) => !["layered","points","repetition"].includes(k)).reduce((a: number, [, v]: any) => a + v, 0);
  console.log(`  timing final-18 masks ${sum} ms (all candidate masks ${all} ms), top: ${Object.entries(t).filter(([k]) => !skip(k)).sort((a: any, b: any) => b[1] - a[1]).slice(0, 12).map(([k, v]) => `${k} ${v}`).join(", ")}`);
}
