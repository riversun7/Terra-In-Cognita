import { readFileSync } from "node:fs";
const S = "/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/synthesis/out";
for (const F of [7, 9]) {
  const rs = JSON.parse(readFileSync(`${S}/measure-F${F}.json`, "utf8")).results;
  const names = Object.keys(rs[0].layered.lostToPriority);
  console.log(`F${F} lost share (% of that candidate's cells): ${names.map((n) => `${n} ${rs.map((r: any) => (100 * r.layered.lostToPriority[n] / Math.max(1, r.cand[n].allMatched)).toFixed(0)).join("/")}`).join("; ")}`);
}
