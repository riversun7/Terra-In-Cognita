// 종합안 측정: 후보마다 비율·덩어리·위도·바이옴, 층 우선순위 적용 뒤 덮는 비율, 바이옴별 덮음, 겹침, 지점 수, 반복 지표.
// 실행: node scripts/measure.ts <면 레벨> [시드 목록=pack,1,42] [--json 파일]
// F9는 캐시 없이(시드당 약 50초, RSS 약 1.2GiB) 하나씩 돈다.
import { writeFileSync } from "node:fs";
import {
  ROOT, cellKmOf, clustersOf, conditionStats, distSource, evaluateCondition, greedyPoints, loadPlanet, newContext, quantiles,
  type Planet,
} from "../lib/helpers.ts";
import { CANDS, ECOLOGY_PRIORITY, LANDFORM_PRIORITY, POINT_ZONES, RESERVE } from "../lib/cands.ts";

const args = process.argv.slice(2);
const flag = (name: string) => { const k = args.indexOf(name); return k >= 0 ? args.splice(k, 2)[1] : undefined; };
const jsonOut = flag("--json");
const only = flag("--only"); // 쉼표 목록: 이 후보만 표에 (계산은 모두)
const F = Number(args[0] ?? 7);
const seedArg = args[1] ?? "pack,1,42";
const PACK_SEED = 20261029;
const seeds = seedArg.split(",").map((s) => (s === "pack" ? PACK_SEED : Number(s)));
const SCALE = 12;

const f1 = (v: number, d = 2) => (Number.isFinite(v) ? v.toFixed(d) : "-");

interface SeedResult {
  seed: number;
  hash: string;
  verification: any;
  cand: Record<string, any>;
  layered: any;
  points: any;
  repetition: any;
  timings: Record<string, number>;
}

function compactStats(s: any) {
  const c = s.clusters;
  return {
    allMatched: s.all.matched,
    landPct: s.land.pct, landMatched: s.land.matched, landTotal: s.land.total,
    oceanPct: s.ocean.pct, oceanMatched: s.ocean.matched, oceanTotal: s.ocean.total,
    lakePct: s.lake.pct, lakeMatched: s.lake.matched, lakeTotal: s.lake.total,
    areaPctAll: s.areaPctAll,
    clusters: c.count, singletons: c.singletons, sizeMedian: c.sizeMedian, sizeP90: c.sizeP90, sizeMax: c.sizeMax,
    f9MapsMedian: c.f9MapsMedian, f9MapsMax: c.f9MapsMax, largestShare: c.largestShareOfMatched,
    nearestCentroidKm: c.nearestCentroidKm,
    absLat: { p10: s.latitude.absP10, p50: s.latitude.absP50, p90: s.latitude.absP90 },
    north: s.latitude.north, south: s.latitude.south,
    biomes: s.biomes.slice(0, 8).map((b: any) => ({ id: b.id, pct: b.pctOfMatched, n: b.matched })),
  };
}

function measureSeed(planet: Planet): SeedResult {
  const t0 = performance.now();
  const timings: Record<string, number> = {};
  const F_ = planet.fields;
  const N: number = planet.grid.cellCount;
  const ctx = newContext(planet);
  const cand: Record<string, any> = {};
  for (const spec of CANDS) {
    const ts = performance.now();
    const mask = evaluateCondition(ctx, spec);
    timings[spec.name] = Math.round(performance.now() - ts);
    if (spec.layer === "aux") continue;
    cand[spec.name] = { layer: spec.layer, ...compactStats(conditionStats(planet, spec.name, spec.expr ?? null, mask)) };
  }
  const masks: Map<string, Uint8Array> = ctx.masks;
  const biomeIds: string[] = planet.meta.biomeIds;
  const land = (c: number) => F_.land[c] === 1;

  // ── 층 우선순위 ──
  const landform = new Int16Array(N).fill(-1);
  const ecology = new Int16Array(N).fill(-1);
  const lost: Record<string, number> = {};
  for (const [k, name] of LANDFORM_PRIORITY.entries()) {
    const m = masks.get(name) as Uint8Array;
    let l = 0;
    for (let c = 0; c < N; c++) if (m[c]) { if (landform[c] < 0) landform[c] = k; else l++; }
    lost[name] = l;
  }
  for (const [k, name] of ECOLOGY_PRIORITY.entries()) {
    const m = masks.get(name) as Uint8Array;
    let l = 0;
    for (let c = 0; c < N; c++) if (m[c]) { if (ecology[c] < 0) ecology[c] = k; else l++; }
    lost[name] = l;
  }
  const pointAny = new Uint8Array(N);
  for (const name of POINT_ZONES) { const m = masks.get(name) as Uint8Array; for (let c = 0; c < N; c++) if (m[c]) pointAny[c] = 1; }
  let landN = 0, oceanN = 0, lakeN = 0;
  let landCov = 0, landCovPts = 0, landTwoPlus = 0, oceanCov = 0, lakeCov = 0, landLandform = 0, landEco = 0;
  const effLandform: Record<string, number> = {};
  for (let c = 0; c < N; c++) {
    const any = landform[c] >= 0 || ecology[c] >= 0;
    if (F_.ocean[c]) { oceanN++; if (any) oceanCov++; }
    else if (F_.lake[c]) { lakeN++; if (any) lakeCov++; }
    else {
      landN++;
      if (any) landCov++;
      if (any || pointAny[c]) landCovPts++;
      if (landform[c] >= 0) landLandform++;
      if (ecology[c] >= 0) landEco++;
      let k = 0;
      for (const name of [...LANDFORM_PRIORITY, ...ECOLOGY_PRIORITY, ...POINT_ZONES]) if ((masks.get(name) as Uint8Array)[c]) k++;
      if (k >= 2) landTwoPlus++;
    }
    if (landform[c] >= 0) { const nm = LANDFORM_PRIORITY[landform[c]] as string; effLandform[nm] = (effLandform[nm] ?? 0) + 1; }
  }
  // 바이옴별 덮음(지형·생태 층), 덮이지 않은 같은 바이옴 덩어리 최대(2차맵 수)
  const scale = 4 ** (9 - F);
  const perBiome: Record<string, any> = {};
  for (const [b, id] of biomeIds.entries()) {
    let n = 0, cov = 0, covPts = 0;
    for (let c = 0; c < N; c++) if (F_.biome[c] === b) { n++; if (landform[c] >= 0 || ecology[c] >= 0) cov++; if (landform[c] >= 0 || ecology[c] >= 0 || pointAny[c]) covPts++; }
    const before = clustersOf(planet, Uint8Array.from({ length: N }, (_, c) => (F_.biome[c] === b ? 1 : 0)));
    const after = clustersOf(planet, Uint8Array.from({ length: N }, (_, c) => (F_.biome[c] === b && landform[c] < 0 && ecology[c] < 0 ? 1 : 0)));
    perBiome[id] = { cells: n, coveredPct: n ? (100 * cov) / n : 0, coveredWithPointsPct: n ? (100 * covPts) / n : 0, largestBeforeMaps: before.sizeMax * scale, largestAfterMaps: after.sizeMax * scale };
  }
  // 겹침: 최종 후보 쌍(행 기준 %)
  const finals = [...LANDFORM_PRIORITY, ...ECOLOGY_PRIORITY, ...POINT_ZONES];
  const overlap: Record<string, Record<string, number>> = {};
  for (const a of finals) {
    const ma = masks.get(a) as Uint8Array;
    let na = 0; for (let c = 0; c < N; c++) if (ma[c]) na++;
    overlap[a] = {};
    for (const b of finals) {
      if (a === b) continue;
      const mb = masks.get(b) as Uint8Array;
      let nab = 0; for (let c = 0; c < N; c++) if (ma[c] && mb[c]) nab++;
      if (nab > 0) overlap[a][b] = na ? (100 * nab) / na : 0;
    }
  }
  // 예비까지 넣으면 덮는 비율
  let landCovRes = 0;
  {
    const res = RESERVE.map((nm) => masks.get(nm) as Uint8Array);
    for (let c = 0; c < N; c++) {
      if (!land(c)) continue;
      if (landform[c] >= 0 || ecology[c] >= 0 || pointAny[c] || res.some((m) => m[c])) landCovRes++;
    }
  }
  const layered = {
    landCoveredWithReservesPct: (100 * landCovRes) / landN,
    landCells: landN, oceanCells: oceanN, lakeCells: lakeN,
    landCoveredPct: (100 * landCov) / landN, landCoveredWithPointZonesPct: (100 * landCovPts) / landN,
    landLandformPct: (100 * landLandform) / landN, landEcologyPct: (100 * landEco) / landN,
    landTwoPlusPct: (100 * landTwoPlus) / landN,
    oceanCoveredPct: (100 * oceanCov) / oceanN, lakeCoveredPct: (100 * lakeCov) / Math.max(1, lakeN),
    lostToPriority: lost, effectiveLandformPctOfLand: Object.fromEntries(Object.entries(effLandform).map(([k, v]) => [k, (100 * v) / landN])),
    perBiome, overlap,
  };
  timings.layered = Math.round(performance.now() - t0);

  // ── 지점 수(F9 칸 = 2차맵 기준이 정확, F7은 근사) ──
  const pts: Record<string, any> = {};
  const count = (name: string) => { const m = masks.get(name) as Uint8Array; let k = 0; for (let c = 0; c < N; c++) if (m[c]) k++; return k; };
  pts.hotSpring40km = greedyPoints(planet, masks.get("v_hotSpring") as Uint8Array, 40, 120).length;
  pts.geyser80km = greedyPoints(planet, masks.get("v_geyser") as Uint8Array, 80, 122).length;
  pts.fumarole60km = greedyPoints(planet, masks.get("v_fumarole") as Uint8Array, 60, 123).length;
  pts.oasis50km = greedyPoints(planet, masks.get("oasis") as Uint8Array, 50, 121).length;
  pts.geothermalZoneCells = count("geothermal");
  pts.oasisZoneCells = count("oasis");
  // 화산 봉우리: 화산 지대 안 volcanicRealM 국소 최대
  {
    const v = masks.get("volcano") as Uint8Array;
    const vol = F_.volcanicRealM as Float32Array;
    const out = new Int32Array(8);
    let cones = 0;
    for (let c = 0; c < N; c++) {
      if (!v[c]) continue;
      planet.G.grid.neighbors8(planet.grid, c, out);
      let top = true;
      for (let e = 0; e < 8; e++) { const o = out[e] as number; if (o >= 0 && (vol[o] as number) > (vol[c] as number)) { top = false; break; } }
      if (top) cones++;
    }
    pts.volcanoConesLocalMax = cones;
    pts.volcanoVents60km = greedyPoints(planet, v, 60, 124).length;
  }
  pts.atollCells = count("v_atoll");
  { const cl = clustersOf(planet, masks.get("v_atoll") as Uint8Array); pts.atollClusters = cl.count; }
  { const cl = clustersOf(planet, masks.get("crater") as Uint8Array); pts.craterClusters = cl.count; }
  { const cl = clustersOf(planet, masks.get("river_delta") as Uint8Array); pts.deltaClusters = cl.count; }
  { let k = 0; for (let c = 0; c < N; c++) if (F_.riverMouth[c] === 1 && (F_.dischargeKm3[c] as number) >= 100) k++; pts.bigMouths100 = k; }
  timings.points = Math.round(performance.now() - t0 - timings.layered);

  // ── 반복 지표: 바이옴만 vs 바이옴 + 특수 지형(지형·생태 층 칸은 그 특수 지형 이름으로) ──
  const rep: any = {};
  {
    const labelBiome = (c: number) => F_.biome[c] as number;
    const labelSpecial = (c: number) => (landform[c] >= 0 ? 1000 + landform[c] : ecology[c] >= 0 ? 2000 + ecology[c] : (F_.biome[c] as number));
    const comps = (label: (c: number) => number) => {
      const lab = new Int32Array(N).fill(-1);
      const q = new Int32Array(N);
      const out = new Int32Array(8);
      const areas: number[] = [];
      let tot = 0;
      for (let s = 0; s < N; s++) {
        if (lab[s] !== -1 || !land(s)) continue;
        const id = areas.length;
        let h = 0, t = 0; q[t++] = s; lab[s] = id; let a = 0;
        const L = label(s);
        while (h < t) {
          const c = q[h++] as number; a += F_.cellAreaKm2[c] as number;
          planet.G.grid.neighbors8(planet.grid, c, out);
          for (let e = 0; e < 8; e++) { const o = out[e] as number; if (o >= 0 && lab[o] === -1 && land(o) && label(o) === L) { lab[o] = id; q[t++] = o; } }
        }
        areas.push(a); tot += a;
      }
      areas.sort((x, y) => y - x);
      return { patches: areas.length, top10Share: areas.slice(0, 10).reduce((x, y) => x + y, 0) / tot, largestKm2Real: areas[0] };
    };
    rep.patchesBiomeOnly = comps(labelBiome);
    rep.patchesWithSpecial = comps(labelSpecial);
    // 24 게임 km 창 안 라벨이 하나뿐인 창 비율
    const n = planet.grid.n;
    const win = Math.max(1, Math.round((24 * SCALE) / cellKmOf(planet)));
    const m = Math.floor(n / win);
    const windows = (label: (c: number) => number) => {
      let full = 0, single = 0;
      for (let f = 0; f < 6; f++) for (let bj = 0; bj < m; bj++) for (let bi = 0; bi < m; bi++) {
        let landCells = 0; const seen = new Set<number>();
        for (let j = bj * win; j < (bj + 1) * win; j++) for (let i = bi * win; i < (bi + 1) * win; i++) { const c = f * n * n + j * n + i; if (land(c)) { landCells++; seen.add(label(c)); } }
        if (landCells >= 0.9 * win * win) { full++; if (seen.size === 1) single++; }
      }
      return single / Math.max(1, full);
    };
    rep.singleLabelWindowBiomeOnly = windows(labelBiome);
    rep.singleLabelWindowWithSpecial = windows(labelSpecial);
    // 가장 가까운 특수 지형(지형·생태·지점 띠)까지 거리, 게임 km
    const isSpecial = (c: number) => landform[c] >= 0 || ecology[c] >= 0 || pointAny[c] === 1;
    const d = distSource(planet, isSpecial, 3000);
    const vals: number[] = [];
    for (let c = 0; c < N; c++) if (land(c)) vals.push((d.km[c] as number) / SCALE);
    const q = quantiles(vals, [0.5, 0.9, 0.99, 1]);
    rep.distToSpecialGameKm = { p50: q[0], p90: q[1], p99: q[2], max: q[3] };
    // variety-check와 같은 '특징' + 특수 지형 경계·칸
    const out = new Int32Array(8);
    const isFeatureBase = (c: number) => {
      if (!land(c)) return F_.lake[c] === 1;
      if ((F_.river[c] as number) > 0 || F_.coast[c] || F_.basinKind[c] === 3) return true;
      planet.G.grid.neighbors8(planet.grid, c, out);
      for (let e = 0; e < 8; e++) {
        const o = out[e] as number; if (o < 0) continue;
        if (land(o) && F_.biome[o] !== F_.biome[c]) return true;
        const dkm = Math.hypot(planet.grid.x[o] - planet.grid.x[c], planet.grid.y[o] - planet.grid.y[c], planet.grid.z[o] - planet.grid.z[c]) * 6371.0088;
        if ((Math.abs((F_.elevationM[o] as number) - (F_.elevationM[c] as number)) * SCALE) / dkm > 20) return true;
      }
      return false;
    };
    const dBase = distSource(planet, isFeatureBase, 3000);
    const dWith = distSource(planet, (c) => isFeatureBase(c) || isSpecial(c), 3000);
    const vb: number[] = [], vw: number[] = [];
    for (let c = 0; c < N; c++) if (land(c)) { vb.push((dBase.km[c] as number) / SCALE); vw.push((dWith.km[c] as number) / SCALE); }
    rep.featureGapP90GameKm = { base: quantiles(vb, [0.9])[0], withSpecial: quantiles(vw, [0.9])[0], baseP50: quantiles(vb, [0.5])[0], withP50: quantiles(vw, [0.5])[0] };
  }
  timings.repetition = Math.round(performance.now() - t0 - timings.layered - timings.points);
  return { seed: planet.meta.seed, hash: planet.meta.hash, verification: planet.meta.verification, cand, layered, points: pts, repetition: rep, timings };
}

const results: SeedResult[] = [];
for (const seed of seeds) {
  const t = performance.now();
  let planet = await loadPlanet({ root: ROOT, planetId: "s2_test_planet", faceLevel: F, seed, cache: F < 9, verify: true, log: (l: string) => console.error(`[harness] ${l}`) });
  const v = planet.meta.verification;
  console.error(`seed ${seed} F${F}: hash ${v.stagedHash} official ${v.officialHash} known ${v.knownHash} replicas ${v.tectonicsElevationMismatches}/${v.climateTemperatureMismatches}/${v.hydrologyDischargeMismatches}/${v.humidityReplicaMismatches} loaded ${Math.round(performance.now() - t)} ms`);
  results.push(measureSeed(planet));
  console.error(`  measured in ${Math.round(performance.now() - t)} ms, RSS ${Math.round(process.memoryUsage().rss / 1048576)} MiB`);
  planet = null;
  (globalThis as any).gc?.();
}

// ── 표 ──
const names = Object.keys(results[0]!.cand).filter((n) => !only || only.split(",").includes(n));
console.log(`F${F} seeds ${seeds.join(",")} hashes ${results.map((r) => r.hash).join(",")}`);
console.log("name                  layer     | %land pooled (per seed)        | %ocean | %lake | clusters/seed (single) | med p90 max cells | F9 maps med/max | |lat| p50 | top biomes");
for (const name of names) {
  const rs = results.map((r) => r.cand[name]);
  const sum = (k: string) => rs.reduce((a: number, s: any) => a + s[k], 0);
  const landP = (100 * sum("landMatched")) / sum("landTotal");
  const oceanP = (100 * sum("oceanMatched")) / sum("oceanTotal");
  const lakeP = (100 * sum("lakeMatched")) / Math.max(1, sum("lakeTotal"));
  const per = rs.map((s: any) => f1(s.landPct)).join("/");
  const perO = rs.map((s: any) => f1(s.oceanPct)).join("/");
  const biomeTotals = new Map<string, number>();
  for (const s of rs) for (const b of s.biomes) biomeTotals.set(b.id, (biomeTotals.get(b.id) ?? 0) + b.n);
  const tot = rs.reduce((a: number, s: any) => a + s.allMatched, 0);
  const top = [...biomeTotals.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4).map(([id, m]) => `${id} ${f1((100 * m) / Math.max(1, tot), 0)}`).join(", ");
  console.log(
    `${name.padEnd(21)} ${rs[0].layer.padEnd(9)} | ${f1(landP).padStart(5)} (${per}) | ${f1(oceanP).padStart(5)} (${perO}) | ${f1(lakeP).padStart(5)} | ${rs.map((s: any) => `${s.clusters}(${s.singletons})`).join(" ")} | ${rs.map((s: any) => `${f1(s.sizeMedian, 0)}/${f1(s.sizeP90, 0)}/${s.sizeMax}`).join(" ")} | ${rs.map((s: any) => `${f1(s.f9MapsMedian, 0)}/${f1(s.f9MapsMax, 0)}`).join(" ")} | ${rs.map((s: any) => f1(s.absLat.p50, 0)).join("/")} | ${top}`,
  );
}
console.log("\nlayered (per seed): land covered % (with point zones) | 2+ % | ocean % | lake %");
for (const r of results) {
  const L = r.layered;
  console.log(`  seed ${r.seed}: land ${f1(L.landCoveredPct)} (${f1(L.landCoveredWithPointZonesPct)}; +reserves ${f1(L.landCoveredWithReservesPct)}) landform ${f1(L.landLandformPct)} eco ${f1(L.landEcologyPct)} | 2+ ${f1(L.landTwoPlusPct)} | ocean ${f1(L.oceanCoveredPct)} | lake ${f1(L.lakeCoveredPct)}`);
}
console.log("\nper biome covered % (landform+ecology / +points) | largest same-biome patch before → after (F9 maps), per seed");
for (const id of Object.keys(results[0]!.layered.perBiome)) {
  console.log(`  ${id.padEnd(20)} ${results.map((r) => { const b = r.layered.perBiome[id]; return `${f1(b.coveredPct, 1)}/${f1(b.coveredWithPointsPct, 1)} ${b.largestBeforeMaps}→${b.largestAfterMaps}`; }).join(" | ")}`);
}
console.log("\npoints per seed");
for (const r of results) console.log(`  seed ${r.seed}: ${JSON.stringify(r.points)}`);
console.log("\nrepetition per seed");
for (const r of results) console.log(`  seed ${r.seed}: ${JSON.stringify(r.repetition)}`);
console.log("\nlost to priority (cells) per seed");
for (const r of results) console.log(`  seed ${r.seed}: ${JSON.stringify(r.layered.lostToPriority)}`);
console.log("\ntimings ms (seed 1st)");
console.log(`  ${JSON.stringify(results[0]!.timings)}`);
if (jsonOut) writeFileSync(jsonOut, `${JSON.stringify({ F, seeds, results }, null, 1)}\n`);
