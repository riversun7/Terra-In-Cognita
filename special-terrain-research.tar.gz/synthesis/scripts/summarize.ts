// measure-F7.json·measure-F9.json → 후보별 한 줄 요약(문서용)
import { readFileSync } from "node:fs";
const S = "/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/synthesis/out";
const r7 = JSON.parse(readFileSync(`${S}/measure-F7.json`, "utf8")).results;
const r9 = JSON.parse(readFileSync(`${S}/measure-F9.json`, "utf8")).results;
const names = process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(r7[0].cand);
const f = (v: number, d = 2) => (Number.isFinite(v) ? v.toFixed(d) : "-");
function pooled(rs: any[], name: string) {
  const s = rs.map((r) => r.cand[name]);
  const sum = (k: string) => s.reduce((a: number, x: any) => a + x[k], 0);
  const domain = sum("landMatched") >= sum("oceanMatched") + sum("lakeMatched") ? "land" : sum("oceanMatched") >= sum("lakeMatched") ? "ocean" : "lake";
  const M = sum(`${domain}Matched`), T = sum(`${domain}Total`);
  const per = s.map((x: any) => x[`${domain}Pct`]);
  const tot = s.reduce((a: number, x: any) => a + x.allMatched, 0);
  const bt = new Map<string, number>();
  for (const x of s) for (const b of x.biomes) bt.set(b.id, (bt.get(b.id) ?? 0) + b.n);
  const top = [...bt.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4).map(([id, m]) => `${id} ${f((100 * m) / Math.max(1, tot), 0)}%`).join(", ");
  return {
    domain, pct: (100 * M) / T, min: Math.min(...per), max: Math.max(...per),
    clusters: s.map((x: any) => x.clusters), single: s.map((x: any) => x.singletons),
    mapsMed: s.map((x: any) => x.f9MapsMedian), mapsMax: s.map((x: any) => x.f9MapsMax),
    lat50: s.map((x: any) => x.absLat.p50), lat10: s.map((x: any) => x.absLat.p10), lat90: s.map((x: any) => x.absLat.p90),
    near: s.map((x: any) => x.nearestCentroidKm?.median ?? NaN), top,
  };
}
for (const name of names) {
  if (!r7[0].cand[name]) continue;
  const a = pooled(r7, name), b = pooled(r9, name);
  console.log(`${name} [${a.domain}] F7 ${f(a.pct)}% (${f(a.min)}~${f(a.max)}) clusters ${a.clusters.join("/")} (single ${a.single.join("/")}) | F9 ${f(b.pct)}% (${f(b.min)}~${f(b.max)}) clusters ${b.clusters.join("/")} (single ${b.single.join("/")}) maps med ${b.mapsMed.map((v: number) => f(v, 0)).join("/")} max ${b.mapsMax.map((v: number) => f(v, 0)).join("/")} nearest ${b.near.map((v: number) => f(v, 0)).join("/")}km |lat| p10/50/90 ${b.lat10.map((v: number) => f(v, 0)).join("/")}|${b.lat50.map((v: number) => f(v, 0)).join("/")}|${b.lat90.map((v: number) => f(v, 0)).join("/")} | F9 biomes ${b.top}`);
}
