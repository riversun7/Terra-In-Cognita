// 타일 비용 추정: 특수 지형 3필드(지형 층 ID, 생태 층 ID, 변형)를 TCPT 타일(32×32칸)마다 붙이면 gzip이 얼마나 느는지.
// 맵 레벨 F−4 ~ F 모두. 윗 레벨 값은 아래 2×2에서 모은다: 규칙 A = 0이 아닌 것 중 가장 많은 것(동점은 작은 번호, 1칸이라도 있으면),
// 규칙 B = 0을 포함해 가장 많은 것(바이옴과 같은 규칙). 두 규칙의 남는 비율도 잰다.
// 실행: node scripts/tilecost.ts [면 레벨=9] [시드=pack]
import { gzipSync } from "node:zlib";
import { ROOT, evaluateCondition, loadPlanet, newContext } from "../lib/helpers.ts";
import { CANDS, ECOLOGY_PRIORITY, LANDFORM_PRIORITY } from "../lib/cands.ts";

const F = Number(process.argv[2] ?? 9);
const seed = process.argv[3] && process.argv[3] !== "pack" ? Number(process.argv[3]) : 20261029;
const t0 = performance.now();
const planet = await loadPlanet({ root: ROOT, planetId: "s2_test_planet", faceLevel: F, seed, cache: F < 9, verify: false, log: () => {} });
const tLoad = performance.now() - t0;
const ctx = newContext(planet);
const t1 = performance.now();
for (const spec of CANDS) evaluateCondition(ctx, spec);
const tEval = performance.now() - t1;
const masks: Map<string, Uint8Array> = ctx.masks;
const N: number = planet.grid.cellCount;
const n: number = planet.grid.n;
const landform = new Uint8Array(N);
const ecology = new Uint8Array(N);
const variant = new Uint8Array(N);
for (let c = 0; c < N; c++) {
  for (const [k, id] of LANDFORM_PRIORITY.entries()) if (masks.get(id)![c]) { landform[c] = k + 1; break; }
  for (const [k, id] of ECOLOGY_PRIORITY.entries()) if (masks.get(id)![c]) { ecology[c] = k + 1; break; }
  // 변형 예: 화산호/열점, 산악 빙하/균열, 협곡 종류, 소금 평원/염호, 산호/해조, 이탄/동토 — 4비트씩(지형 | 생태 << 4)
  let lv = 0;
  if (landform[c] === 1) lv = masks.get("v_volcanoArc")![c] ? 1 : 2;
  else if (landform[c] === 2) lv = masks.get("v_mountainGlacier")![c] ? 1 : 2;
  else if (landform[c] === 3) lv = masks.get("v_gorge")![c] ? 2 : 1;
  else if (landform[c] === 7) lv = masks.get("v_salineLake")![c] ? 2 : 1;
  let ev = 0;
  if (ecology[c] === 2) ev = masks.get("v_kelp")![c] && !masks.get("coral_reef")![c] ? 2 : 1;
  else if (ecology[c] === 4) ev = masks.get("thermokarst")![c] ? 2 : 1;
  variant[c] = lv | (ev << 4);
}
// 모으기
type Agg = "nonzeroMode" | "mode" | "twoOfFour";
function aggregate(src: Uint8Array, size: number, rule: Agg): Uint8Array {
  const half = size / 2;
  const out = new Uint8Array(6 * half * half);
  for (let f = 0; f < 6; f++) for (let j = 0; j < half; j++) for (let i = 0; i < half; i++) {
    const vals = [src[f * size * size + 2 * j * size + 2 * i]!, src[f * size * size + 2 * j * size + 2 * i + 1]!, src[f * size * size + (2 * j + 1) * size + 2 * i]!, src[f * size * size + (2 * j + 1) * size + 2 * i + 1]!];
    const counts = new Map<number, number>();
    for (const v of vals) if (rule === "mode" || v !== 0) counts.set(v, (counts.get(v) ?? 0) + 1);
    let best = 0, bestN = 0;
    for (const [v, k] of [...counts.entries()].sort((a, b) => a[0] - b[0])) if (k > bestN) { best = v; bestN = k; }
    if (rule === "twoOfFour" && bestN < 2) best = 0;
    out[f * half * half + j * half + i] = best;
  }
  return out;
}
const levels: { L: number; size: number; lf: Uint8Array; ec: Uint8Array; va: Uint8Array }[] = [{ L: F, size: n, lf: landform, ec: ecology, va: variant }];
for (let L = F - 1; L >= F - 4; L--) {
  const prev = levels[levels.length - 1]!;
  levels.push({ L, size: prev.size / 2, lf: aggregate(prev.lf, prev.size, "nonzeroMode"), ec: aggregate(prev.ec, prev.size, "nonzeroMode"), va: aggregate(prev.va, prev.size, "nonzeroMode") });
}
// 남는 비율: 레벨마다 특수 지형 칸의 면적 몫(칸 수 비율)
const shareOf = (a: Uint8Array) => { let k = 0; for (const v of a) if (v) k++; return k / a.length; };
const modeLevels: Uint8Array[] = [landform];
for (let L = F - 1; L >= F - 4; L--) { const prev = modeLevels[modeLevels.length - 1]!; modeLevels.push(aggregate(prev, Math.sqrt(prev.length / 6), "mode")); }
const twoLevels: Uint8Array[] = [landform];
for (let L = F - 1; L >= F - 4; L--) { const prev = twoLevels[twoLevels.length - 1]!; twoLevels.push(aggregate(prev, Math.sqrt(prev.length / 6), "twoOfFour")); }
// 타일 gzip
let tiles = 0, rawBytes = 0, gzBytes = 0, gzEmpty = 0;
const perLevel: string[] = [];
for (const lv of levels) {
  const tileCells = Math.min(32, lv.size);
  const per = lv.size / tileCells;
  let lvGz = 0, lvTiles = 0;
  for (let f = 0; f < 6; f++) for (let tj = 0; tj < per; tj++) for (let ti = 0; ti < per; ti++) {
    const block = new Uint8Array(3 * tileCells * tileCells);
    let o = 0;
    for (const arr of [lv.lf, lv.ec, lv.va]) for (let j = 0; j < tileCells; j++) for (let i = 0; i < tileCells; i++) block[o++] = arr[f * lv.size * lv.size + (tj * tileCells + j) * lv.size + ti * tileCells + i]!;
    const gz = gzipSync(block, { level: 6 }).length;
    lvGz += gz; lvTiles++;
    rawBytes += block.length; gzBytes += gz;
    gzEmpty += gzipSync(new Uint8Array(block.length), { level: 6 }).length;
  }
  tiles += lvTiles;
  perLevel.push(`L${lv.L}: tiles ${lvTiles}, feature share (nonzero-mode) landform ${(100 * shareOf(lv.lf)).toFixed(2)}% ecology ${(100 * shareOf(lv.ec)).toFixed(2)}%, gzip ${lvGz} B`);
}
console.log(`F${F} seed ${seed} hash ${planet.meta.hash}: load ${Math.round(tLoad)} ms, evaluate all candidate masks ${Math.round(tEval)} ms`);
for (const l of perLevel) console.log(`  ${l}`);
console.log(`  'two of four' landform share by level: ${twoLevels.map((a, k) => `L${F - k} ${(100 * shareOf(a)).toFixed(2)}%`).join(", ")}`);
console.log(`  'mode incl. 0' landform share by level: ${modeLevels.map((a, k) => `L${F - k} ${(100 * shareOf(a)).toFixed(2)}%`).join(", ")}`);
console.log(`  total: tiles ${tiles}, raw feature bytes ${rawBytes}, gzip ${gzBytes} B (all-zero blocks would gzip to ${gzEmpty} B)`);
// 해안 특수 지형이 해안 칸에서 차지하는 몫
{
  const Fd = planet.fields;
  let coast = 0, land = 0;
  const k: Record<string, number> = { fjord: 0, mangrove: 0, tidal_flat: 0 };
  for (let c = 0; c < N; c++) { if (Fd.land[c]) land++; if (Fd.land[c] && Fd.coast[c]) { coast++; for (const id of Object.keys(k)) if (masks.get(id)![c]) k[id]++; } }
  console.log(`  coast cells ${coast} = ${(100 * coast / land).toFixed(2)}% of land; share of coast cells: ${Object.entries(k).map(([id, v]) => `${id} ${(100 * v / coast).toFixed(1)}%`).join(", ")}`);
}
