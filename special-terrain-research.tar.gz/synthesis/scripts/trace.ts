// 정보창 예시: 칸 하나의 값(실제 단위), 바이옴 규칙 차례(처음 맞는 것), 특수 지형 규칙(조항별 통과·모자람), 근접 실패.
// 그리고 rules.ts 조항 판정이 cands.ts 마스크와 모든 칸에서 같은지 대조한다.
// 실행: node scripts/trace.ts [면 레벨=7] [시드=pack]
import { readFileSync, writeFileSync } from "node:fs";
import { ROOT, evaluateCondition, loadPlanet, newContext } from "../lib/helpers.ts";
import { CANDS, ECOLOGY_PRIORITY, LANDFORM_PRIORITY } from "../lib/cands.ts";
import { buildRules, evalRule } from "../lib/rules.ts";

const F = Number(process.argv[2] ?? 7);
const seed = process.argv[3] && process.argv[3] !== "pack" ? Number(process.argv[3]) : 20261029;
const planet = await loadPlanet({ root: ROOT, planetId: "s2_test_planet", faceLevel: F, seed, cache: F < 9, verify: F < 9, log: () => {} });
const ctx = newContext(planet);
for (const spec of CANDS) evaluateCondition(ctx, spec);
const masks: Map<string, Uint8Array> = ctx.masks;
const rules = buildRules(planet, masks, ctx.derived);
const Fd = planet.fields;
const N: number = planet.grid.cellCount;
const lines: string[] = [];
const out = (s: string) => { lines.push(s); console.log(s); };

// ── 대조 ──
out(`F${F} seed ${seed} hash ${planet.meta.hash}`);
for (const rule of rules) {
  const mask = masks.get(rule.id) as Uint8Array;
  let mismatch = 0, matched = 0;
  for (let c = 0; c < N; c++) { const p = evalRule(rule, c).pass; if (p !== (mask[c] === 1)) mismatch++; if (p) matched++; }
  out(`check ${rule.id.padEnd(16)} matched ${String(matched).padStart(7)} mismatches vs cands.ts ${mismatch}`);
}

// ── 바이옴 규칙 ──
const biomeEntries = JSON.parse(readFileSync(`${ROOT}/content/core/biomes.json`, "utf8")).entries as any[];
const order: string[] = planet.meta.biomeIds;
const rangeText = (r: any, unit: string) => `${r.min !== undefined ? `${r.min} 이상` : ""}${r.min !== undefined && r.max !== undefined ? " " : ""}${r.max !== undefined ? `${r.max} 미만` : ""}${unit}`;
function biomeTrace(c: number): string[] {
  const res: string[] = [];
  if (Fd.ocean[c]) { res.push(`  바다 칸: 수심 등급 ${["-", "연안", "대륙붕", "심해"][Fd.depthClass[c]]} → 바이옴 ${order[Fd.biome[c]]}`); return res; }
  if (Fd.lake[c]) { res.push(`  호수 칸 → 바이옴 lake`); return res; }
  const t = Fd.temperatureC[c], h = Fd.humidity[c], e = Fd.realElevationM[c];
  let winner = -1;
  for (const [k, id] of order.entries()) {
    const entry = biomeEntries.find((b) => b.id === id);
    if (!entry || entry.rule.kind !== "land") continue;
    const r = entry.rule;
    const parts: string[] = [];
    let ok = true;
    const test = (name: string, range: any, v: number, unit: string) => {
      if (!range) return;
      const pass = (range.min === undefined || v >= range.min) && (range.max === undefined || v < range.max);
      if (!pass) ok = false;
      parts.push(`${name} ${v} (${rangeText(range, unit)}) ${pass ? "통과" : "실패"}`);
    };
    test("기온", r.temperatureC, t, "°C");
    test("습도", r.humidity, h, "");
    test("고도(실제)", r.realElevationM, e, "m");
    if (parts.length === 0) parts.push("조건 없음(남은 땅 전부)");
    res.push(`  ${k}. ${entry.name.ko}(${id}): ${parts.join(" · ")} → ${ok ? "맞음" : "아님"}${ok && winner < 0 ? "  ← 처음 맞은 규칙" : ""}`);
    if (ok && winner < 0) { winner = k; break; }
  }
  res.push(`  저장 바이옴 = ${order[Fd.biome[c]]} (재판정 ${winner >= 0 ? order[winner] : "마지막 육지 바이옴"}, ${order[Fd.biome[c]] === (winner >= 0 ? order[winner] : "") ? "같음" : "다름"})`);
  return res;
}

function fmt(v: number): string { return Number.isInteger(v) ? String(v) : Math.abs(v) >= 100 ? v.toFixed(0) : Math.abs(v) >= 1 ? v.toFixed(2) : v.toFixed(3); }
function cellReport(c: number, title: string) {
  out(`\n### ${title} — 칸 ${c} (면 ${Fd.face[c]}, i ${Fd.i[c]}, j ${Fd.j[c]})`);
  out(`  위도 ${fmt(Fd.latitudeDeg[c])}°, 경도 ${fmt(Fd.longitudeDeg[c])}°, 고도 ${Fd.elevationM[c]} 게임 m (실제 ${Fd.realElevationM[c]} m), 기온 ${Fd.temperatureC[c]}°C, 강수 ${Fd.precipitationMm[c]} mm, 습도 ${Fd.humidity[c]} (강가 가산 ${fmt(Fd.nearWaterBonus[c])}), 숲 ${Fd.forest[c]}, 하천 등급 ${Fd.river[c]}, 물 비트 ${Fd.water[c]}`);
  for (const l of biomeTrace(c)) out(l);
  const results = rules.map((r) => evalRule(r, c));
  const hit = results.filter((r) => r.pass);
  const lf = LANDFORM_PRIORITY.find((id) => masks.get(id)?.[c]);
  const ec = ECOLOGY_PRIORITY.find((id) => masks.get(id)?.[c]);
  out(`  특수 지형: 지형 층 ${lf ?? "없음"}, 생태 층 ${ec ?? "없음"}, 지점 띠 ${["geothermal", "oasis"].filter((id) => masks.get(id)?.[c]).join(", ") || "없음"}; 맞은 규칙 전부 ${hit.map((r) => r.rule.id).join(", ") || "없음"}`);
  for (const r of hit) {
    for (const b of r.branches.filter((b) => b.pass)) {
      out(`  [맞음] ${r.rule.ko}${b.branch.ko ? ` / ${b.branch.ko}` : ""}: ${b.results.map((x) => `${x.cl.ko} ${x.cl.op === "is" ? "" : `${fmt(x.value)}${x.cl.unit ? ` ${x.cl.unit}` : ""} ${x.cl.op} ${fmt(x.cl.limit)}`} 통과`).join(" | ")}`);
    }
  }
  // 근접 실패: 갈래 중 실패 조항이 하나뿐이고 모자람 ≤ 1눈금
  const near: string[] = [];
  for (const r of results) {
    if (r.pass) continue;
    for (const b of r.branches) {
      if (b.failing.length !== 1) continue;
      const f = b.failing[0]!;
      if (!(f.short <= 1)) continue;
      near.push(`  [거의] ${r.rule.ko}${b.branch.ko ? ` / ${b.branch.ko}` : ""}: ${f.cl.ko} ${fmt(f.value)}${f.cl.unit ? ` ${f.cl.unit}` : ""} (필요 ${f.cl.op} ${fmt(f.cl.limit)})만 모자람`);
    }
  }
  for (const l of near.slice(0, 4)) out(l);
}

function pick(pred: (c: number) => boolean, nth = 0): number {
  let k = 0;
  for (let c = 0; c < N; c++) if (pred(c)) { if (k === nth) return c; k++; }
  return -1;
}
const M = (id: string) => masks.get(id) as Uint8Array;
const picks: [string, number][] = [
  ["카르스트 칸", pick((c) => M("karst")[c] === 1 && !LANDFORM_PRIORITY.slice(0, -1).some((id) => M(id)[c]), 40)],
  ["빙하 덮인 화산 칸", pick((c) => M("volcano")[c] === 1 && M("v_volcanoIce")[c] === 1, 10)],
  ["맹그로브 + 삼각주 칸", pick((c) => M("mangrove")[c] === 1 && M("river_delta")[c] === 1)],
  ["사구 지대 근접 실패 칸(사막)", pick((c) => Fd.biome[c] === order.indexOf("desert") && M("dune_sea")[c] === 0 && (Fd.aridityIndex[c] as number) <= 0.13 && (Fd.aridityIndex[c] as number) > 0.12 && Fd.basinKind[c] !== 3, 3)],
  ["특수 지형 없는 사바나 칸", pick((c) => Fd.biome[c] === order.indexOf("savanna") && !rules.some((r) => M(r.id)[c]), 500)],
];
for (const [title, c] of picks) if (c >= 0) cellReport(c, title);

// ── 거친 타일 모으기 예: 맵 레벨 F−2(4×4칸 → 1칸) 한 칸 아래 칸들의 바이옴·특수 지형 분포 ──
{
  const n = planet.grid.n;
  const c0 = picks[0]![1];
  if (c0 >= 0) {
    const f = Fd.face[c0], i = Fd.i[c0], j = Fd.j[c0];
    const bi = Math.floor(i / 4) * 4, bj = Math.floor(j / 4) * 4;
    const biomeCount = new Map<string, number>();
    const featCount = new Map<string, number>();
    for (let y = bj; y < bj + 4; y++) for (let x = bi; x < bi + 4; x++) {
      const c = f * n * n + y * n + x;
      biomeCount.set(order[Fd.biome[c]] as string, (biomeCount.get(order[Fd.biome[c]] as string) ?? 0) + 1);
      const lf = LANDFORM_PRIORITY.find((id) => M(id)[c]) ?? ECOLOGY_PRIORITY.find((id) => M(id)[c]) ?? "none";
      featCount.set(lf, (featCount.get(lf) ?? 0) + 1);
    }
    out(`\n### 거친 타일 예: 맵 레벨 ${F - 2}의 한 칸(= 맵 레벨 ${F} 칸 16개, 면 ${f}, i ${bi}~${bi + 3}, j ${bj}~${bj + 3})`);
    out(`  바이옴 분포 ${[...biomeCount.entries()].map(([k, v]) => `${k} ${v}`).join(", ")}; 특수 지형 분포 ${[...featCount.entries()].map(([k, v]) => `${k} ${v}`).join(", ")}`);
  }
}
writeFileSync(`/tmp/claude-0/-home-user/cb0728c6-6627-53f8-b5b7-9c38043bcdcc/scratchpad/special-terrain/synthesis/out/trace-F${F}-s${seed}.txt`, `${lines.join("\n")}\n`);
