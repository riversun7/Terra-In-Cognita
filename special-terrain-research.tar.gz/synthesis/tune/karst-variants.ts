// 카르스트·사구·황토 문턱 비교(측정용)
import { areaThreshold, patchNoise, upwindHas } from "../lib/helpers.ts";
function carbonate(planet: any, freq: number, oct: number, share: number, stream = 9) {
  const F = planet.fields; const N = planet.grid.cellCount;
  const v = patchNoise(planet, stream, freq, oct, 0.5);
  const inc = (c: number) => F.land[c] === 1 && F.continental[c] === 1;
  const t = areaThreshold(planet, v, 1 - share, inc);
  return Uint8Array.from({ length: N }, (_, c) => (inc(c) && v[c] > t ? 1 : 0));
}
const karstOf = (freq: number, oct: number, share: number) => (planet: any) => {
  const F = planet.fields; const m = carbonate(planet, freq, oct, share);
  return Uint8Array.from(m, (x, c) => (x && F.precipitationMm[c] >= 700 && F.temperatureC[c] >= 0 && F.realElevationM[c] < 3000 ? 1 : 0));
};
export const conditions = [
  { name: "karst_f3_s15", mask: karstOf(3, 4, 0.15) },
  { name: "karst_f6_s15", mask: karstOf(6, 4, 0.15) },
  { name: "karst_f6_s20", mask: karstOf(6, 4, 0.20) },
  { name: "karst_f8_s20", mask: karstOf(8, 3, 0.20) },
  { name: "karst_f10_s20", mask: karstOf(10, 3, 0.20) },
  { name: "dune_A12", expr: "biomeId === 'desert' && aridityIndex <= 0.12 && realElevationM <= 1500 && basinKind !== BASIN.DRY && slopeMPerKm <= 1.2" },
  { name: "dune_A11", expr: "biomeId === 'desert' && aridityIndex <= 0.11 && realElevationM <= 1500 && basinKind !== BASIN.DRY && slopeMPerKm <= 1.2" },
  { name: "dune_A12_noise", mask: (planet: any, h: any) => { const n = patchNoise(planet, 102, 8); const m = h.mask("dune_A12"); return Uint8Array.from(m, (x, c) => (x && n[c] > -0.15 ? 1 : 0)); } },
  { name: "loess_grass", mask: (planet: any) => {
      const F = planet.fields; const N = planet.grid.cellCount; const ids = planet.meta.biomeIds;
      const desert = ids.indexOf("desert"), grass = ids.indexOf("grassland");
      const src = upwindHas(planet, (c) => F.biome[c] === desert || F.basinKind[c] === 3, 1000);
      return Uint8Array.from({ length: N }, (_, c) => (F.land[c] && F.biome[c] === grass && F.basinKind[c] !== 3 && F.humidity[c] < 120 && F.realElevationM[c] >= 400 && F.realElevationM[c] < 2500 && src[c] ? 1 : 0));
  } },
  { name: "peat165", expr: "land && !riverCell && temperatureC >= -3 && temperatureC <= 5 && humidity >= 165 && realElevationM <= 400 && slopeMPerKm <= 1.5" },
];
