import { patchNoise } from "../lib/helpers.ts";
const gate = (stream: number, f: number, t: number, base: string) => (planet: any, h: any) => { const n = patchNoise(planet, stream, f); const m = h.mask(base); return Uint8Array.from(m, (x, c) => (x && n[c] > t ? 1 : 0)); };
export const conditions = [
  { name: "peat170", expr: "land && !riverCell && temperatureC >= -3 && temperatureC <= 5 && humidity >= 170 && realElevationM <= 400 && slopeMPerKm <= 1.5" },
  { name: "peat180", expr: "land && !riverCell && temperatureC >= -3 && temperatureC <= 5 && humidity >= 180 && realElevationM <= 400 && slopeMPerKm <= 1.5" },
  { name: "peat175_e300_s1", expr: "land && !riverCell && temperatureC >= -3 && temperatureC <= 5 && humidity >= 175 && realElevationM <= 300 && slopeMPerKm <= 1.0" },
  { name: "peat170_n0", mask: gate(106, 12, 0, "peat170") },
  { name: "thermo80", expr: "land && temperatureC >= -11 && temperatureC < -3 && humidity >= 80 && realElevationM <= 300 && slopeMPerKm <= 1.2" },
  { name: "thermo120", expr: "land && temperatureC >= -11 && temperatureC < -3 && humidity >= 120 && realElevationM <= 300 && slopeMPerKm <= 1.2" },
  { name: "thermo100_e200_s1", expr: "land && temperatureC >= -11 && temperatureC < -3 && humidity >= 100 && realElevationM <= 200 && slopeMPerKm <= 1.0" },
  { name: "thermo80_n0", mask: gate(106, 12, 0, "thermo80") },
  { name: "cw_n0", expr: "peat170_n0 || thermo80_n0" },
  { name: "cw_strict", expr: "peat175_e300_s1 || thermo100_e200_s1" },
];
